import gui.LoginFrame;
import utils.DataManager;
import javax.swing.*;

public class Main {
    public static void main(String[] args) {
        
        DataManager.initialize();

        SwingUtilities.invokeLater(() -> {
            try {
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            } catch (Exception e) {
                e.printStackTrace();
            }
            new LoginFrame().setVisible(true);
        });
    }
}
