package gui;

import models.*;
import utils.DataManager;
import utils.UITheme;

import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.List;
import javax.imageio.ImageIO;

/**
 * Reusable panel for Fee Challan features.
 * Mode ADMIN  -> configure fee structures + enable/disable generation
 * Mode STUDENT -> generate own challan (if admin has enabled it)
 *
 * PDF generation is done entirely in Java using Graphics2D (no Python, no external libs).
 */
public class FeeChallanPanel extends JPanel {

    public enum Mode { ADMIN, STUDENT }

    private final Mode mode;
    private final User currentUser;
    private JFrame parentFrame;

    public FeeChallanPanel(Mode mode, User user, JFrame parent) {
        this.mode        = mode;
        this.currentUser = user;
        this.parentFrame = parent;
        setLayout(new BorderLayout());
        setBackground(UITheme.CONTENT_BG);
        build();
    }

    private void build() {
        if (mode == Mode.ADMIN) buildAdminView();
        else                    buildStudentView();
    }

    // =========================================================
    //  ADMIN VIEW
    // =========================================================

    private void buildAdminView() {
        removeAll();

        // Header
        JPanel header = buildHeader(
            "Fee Challan Manager",
            "Configure fee structures and control student challan generation",
            UITheme.PRIMARY_DARK, UITheme.SECONDARY
        );
        JButton addBtn = UITheme.accentButton("+ New Fee Structure");
        addBtn.addActionListener(e -> showAddFeeStructureDialog());
        JPanel btnWrap = new JPanel(new FlowLayout(FlowLayout.RIGHT, 0, 0));
        btnWrap.setOpaque(false);
        btnWrap.add(addBtn);
        header.add(btnWrap, BorderLayout.EAST);

        // Stats
        List<FeeStructure> structures = DataManager.loadFeeStructures();
        long enabled = structures.stream().filter(FeeStructure::isFeeGenerationEnabled).count();

        JPanel statsRow = new JPanel(new GridLayout(1, 3, 14, 0));
        statsRow.setOpaque(false);
        statsRow.setBorder(BorderFactory.createEmptyBorder(18, 26, 14, 26));
        statsRow.add(UITheme.statCard(String.valueOf(structures.size()), "Fee Structures",   UITheme.TEAL,    null));
        statsRow.add(UITheme.statCard(String.valueOf(enabled),           "Generation Enabled", UITheme.SUCCESS, null));
        statsRow.add(UITheme.statCard(String.valueOf(structures.size() - enabled), "Disabled", UITheme.DANGER, null));

        // Table
        String[] cols = {"ID", "Programme", "Semester", "Tuition Fee", "Total Fee", "Generation", "Actions"};
        DefaultTableModel model = new DefaultTableModel(cols, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
            public Class<?> getColumnClass(int c) { return c == 5 ? Boolean.class : String.class; }
        };
        for (FeeStructure fs : structures) {
            model.addRow(new Object[]{
                fs.getId(), fs.getProgramme(), fs.getSemester(),
                "Rs. " + String.format("%,.0f", fs.getTuitionFee()),
                "Rs. " + String.format("%,.0f", fs.getTotal()),
                fs.isFeeGenerationEnabled() ? "ENABLED" : "DISABLED",
                "Edit | Toggle | Delete"
            });
        }
        JTable table = new JTable(model);
        UITheme.styleTable(table);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        // Status column renderer
        table.getColumnModel().getColumn(5).setCellRenderer(new DefaultTableCellRenderer() {
            @Override public Component getTableCellRendererComponent(JTable t, Object v,
                    boolean sel, boolean foc, int row, int col) {
                super.getTableCellRendererComponent(t, v, sel, foc, row, col);
                String val = v == null ? "" : v.toString();
                setForeground("ENABLED".equals(val) ? UITheme.SUCCESS : UITheme.DANGER);
                setFont(UITheme.boldFont());
                setBorder(BorderFactory.createEmptyBorder(0, 12, 0, 12));
                if (!sel) setBackground(row % 2 == 0 ? UITheme.CARD_BG : UITheme.TABLE_ALT_ROW);
                return this;
            }
        });

        // Action buttons
        JPanel btnRow = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        btnRow.setOpaque(false);

        JButton editBtn    = UITheme.ghostButton("Edit");
        JButton toggleBtn  = UITheme.accentButton("Toggle Generation");
        JButton delBtn     = UITheme.dangerButton("Delete");
        JButton previewBtn = UITheme.primaryButton("Preview Challan");

        editBtn.addActionListener(e -> {
            int r = table.getSelectedRow();
            if (r < 0) { msg("Select a fee structure first."); return; }
            FeeStructure fs = DataManager.loadFeeStructures().get(r);
            showEditFeeStructureDialog(fs);
        });

        toggleBtn.addActionListener(e -> {
            int r = table.getSelectedRow();
            if (r < 0) { msg("Select a fee structure first."); return; }
            List<FeeStructure> all = DataManager.loadFeeStructures();
            FeeStructure fs = all.get(r);
            fs.setFeeGenerationEnabled(!fs.isFeeGenerationEnabled());
            DataManager.updateFeeStructure(fs);
            String status = fs.isFeeGenerationEnabled() ? "ENABLED" : "DISABLED";
            JOptionPane.showMessageDialog(parentFrame,
                "Fee generation for " + fs + " is now " + status + ".\n"
                + (fs.isFeeGenerationEnabled()
                   ? "Students can now generate their fee challans."
                   : "Students cannot generate challans for this structure."),
                "Permission Updated", JOptionPane.INFORMATION_MESSAGE);
            buildAdminView();
        });

        delBtn.addActionListener(e -> {
            int r = table.getSelectedRow();
            if (r < 0) { msg("Select a fee structure first."); return; }
            FeeStructure fs = DataManager.loadFeeStructures().get(r);
            if (JOptionPane.showConfirmDialog(parentFrame,
                    "Delete fee structure for " + fs + "?",
                    "Confirm Delete", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
                DataManager.deleteFeeStructure(fs.getId());
                buildAdminView();
            }
        });

        previewBtn.addActionListener(e -> {
            int r = table.getSelectedRow();
            if (r < 0) { msg("Select a fee structure first."); return; }
            FeeStructure fs = DataManager.loadFeeStructures().get(r);
            Map<String, Object> sampleData = new HashMap<>();
            sampleData.put("student_name",  "Sample Student");
            sampleData.put("father_name",   "Sample Father");
            sampleData.put("roll_no",       "L-SE0000000");
            sampleData.put("programme",     fs.getProgramme());
            sampleData.put("semester",      fs.getSemester());
            sampleData.put("shift",         "Morning");
            populateFeeData(sampleData, fs);
            generateAndOpenChallan(sampleData, "Preview_Challan");
        });

        btnRow.add(previewBtn); btnRow.add(editBtn);
        btnRow.add(toggleBtn); btnRow.add(delBtn);

        JPanel content = new JPanel(new BorderLayout(0, 10));
        content.setOpaque(false);
        content.setBorder(BorderFactory.createEmptyBorder(4, 26, 18, 26));
        content.add(UITheme.sectionHeader("Fee Structures"), BorderLayout.NORTH);
        content.add(UITheme.scrollPane(table), BorderLayout.CENTER);
        content.add(btnRow, BorderLayout.SOUTH);

        JPanel main = new JPanel(new BorderLayout());
        main.setOpaque(false);
        main.add(statsRow, BorderLayout.NORTH);
        main.add(content, BorderLayout.CENTER);

        add(header, BorderLayout.NORTH);
        add(main, BorderLayout.CENTER);
        revalidate(); repaint();
    }

    // =========================================================
    //  STUDENT VIEW
    // =========================================================

    private void buildStudentView() {
        removeAll();

        Student student = (Student) currentUser;

        JPanel header = buildHeader(
            "Fee Challan Generator",
            "Generate your official fee payment challan",
            new Color(5, 95, 150), new Color(13, 148, 136)
        );

        JPanel content = new JPanel(new BorderLayout(0, 20));
        content.setOpaque(false);
        content.setBorder(BorderFactory.createEmptyBorder(20, 60, 20, 60));

        // Form card
        JPanel infoCard = buildCard();
        infoCard.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 12, 10, 12);
        gbc.anchor = GridBagConstraints.WEST;
        gbc.fill   = GridBagConstraints.HORIZONTAL;

        JTextField nameField = UITheme.styledField();
        nameField.setText(student.getName());
        JTextField fatherField = UITheme.styledField();
        fatherField.setText("Muhammad " + student.getName().split(" ")[0]);

        JTextField progField = UITheme.styledField();
        progField.setText(student.getMajor());

        List<FeeStructure> structures = DataManager.loadFeeStructures();
        List<String> semOptions = new ArrayList<>();
        for (FeeStructure fs : structures) {
            if (fs.isFeeGenerationEnabled()) {
                semOptions.add(fs.getProgramme() + " - Semester " + fs.getSemester());
            }
        }
        JComboBox<String> semCombo = UITheme.styledCombo(
            semOptions.isEmpty()
                ? new String[]{"No enabled fee structures - contact Admin"}
                : semOptions.toArray(new String[0])
        );

        JTextField shiftField = UITheme.styledField();
        shiftField.setText("Morning");

        Object[][] fields = {
            {"Student Name *", nameField},
            {"Father Name *",  fatherField},
            {"Programme *",    progField},
            {"Semester *",     semCombo},
            {"Shift",          shiftField},
        };
        int row = 0;
        for (Object[] fl : fields) {
            gbc.gridx = 0; gbc.gridy = row; gbc.weightx = 0;
            infoCard.add(UITheme.label((String)fl[0] + ":", UITheme.boldFont(), UITheme.TEXT_DARK), gbc);
            gbc.gridx = 1; gbc.weightx = 1;
            infoCard.add((Component)fl[1], gbc);
            row++;
        }

        JLabel statusLbl = UITheme.label("", UITheme.boldFont(), UITheme.TEXT_MUTED);
        gbc.gridx = 0; gbc.gridy = row; gbc.gridwidth = 2;
        infoCard.add(statusLbl, gbc);

        // Notice if no structures enabled
        if (semOptions.isEmpty()) {
            JPanel noticePanel = new JPanel(new BorderLayout(10, 0)) {
                @Override protected void paintComponent(Graphics g) {
                    super.paintComponent(g);
                    Graphics2D g2 = (Graphics2D) g.create();
                    g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                    g2.setColor(UITheme.WARNING_LIGHT);
                    g2.fillRoundRect(0, 0, getWidth(), getHeight(), 10, 10);
                    g2.setColor(UITheme.WARNING);
                    g2.drawRoundRect(0, 0, getWidth()-1, getHeight()-1, 10, 10);
                    g2.dispose();
                }
            };
            noticePanel.setOpaque(false);
            noticePanel.setBorder(BorderFactory.createEmptyBorder(12, 16, 12, 16));
            JLabel noticeLbl = UITheme.label(
                "Fee challan generation is currently disabled. " +
                "Please contact the administration to enable it for your programme and semester.",
                UITheme.boldFont(), UITheme.WARNING);
            noticeLbl.setHorizontalAlignment(SwingConstants.CENTER);
            noticePanel.add(noticeLbl, BorderLayout.CENTER);
            content.add(noticePanel, BorderLayout.NORTH);
        }

        // Generate button
        JPanel btnRow = new JPanel(new FlowLayout(FlowLayout.CENTER, 14, 0));
        btnRow.setOpaque(false);

        JButton generateBtn = new JButton("Generate & Download Challan") {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                GradientPaint gp = getModel().isRollover()
                    ? new GradientPaint(0,0,UITheme.SUCCESS,getWidth(),0,new Color(4,120,87))
                    : new GradientPaint(0,0,new Color(4,120,87),getWidth(),0,UITheme.SUCCESS);
                g2.setPaint(gp);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 10, 10);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        generateBtn.setFont(UITheme.font(Font.BOLD, 14));
        generateBtn.setForeground(Color.WHITE);
        generateBtn.setContentAreaFilled(false);
        generateBtn.setBorderPainted(false);
        generateBtn.setFocusPainted(false);
        generateBtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        generateBtn.setBorder(BorderFactory.createEmptyBorder(12, 32, 12, 32));
        generateBtn.setEnabled(!semOptions.isEmpty());

        generateBtn.addActionListener(e -> {
            String sName   = nameField.getText().trim();
            String sFather = fatherField.getText().trim();
            String sProg   = progField.getText().trim();
            if (sName.isEmpty() || sFather.isEmpty() || sProg.isEmpty()) {
                statusLbl.setForeground(UITheme.DANGER);
                statusLbl.setText("Please fill in all required fields.");
                return;
            }
            if (semCombo.getSelectedIndex() < 0 || semOptions.isEmpty()) {
                statusLbl.setForeground(UITheme.DANGER);
                statusLbl.setText("No enabled fee structure available.");
                return;
            }
            FeeStructure selected = null;
            for (FeeStructure fs : DataManager.loadFeeStructures()) {
                String label = fs.getProgramme() + " - Semester " + fs.getSemester();
                if (label.equals(semCombo.getSelectedItem())) {
                    selected = fs; break;
                }
            }
            if (selected == null || !selected.isFeeGenerationEnabled()) {
                statusLbl.setForeground(UITheme.DANGER);
                statusLbl.setText("Fee generation not enabled for this selection.");
                return;
            }
            statusLbl.setForeground(UITheme.TEXT_MUTED);
            statusLbl.setText("Generating challan...");
            generateBtn.setEnabled(false);

            final FeeStructure fsFinal = selected;
            final String nm = sName, fa = sFather, pr = sProg;
            new Thread(() -> {
                try {
                    Map<String, Object> data = new HashMap<>();
                    data.put("student_name", nm);
                    data.put("father_name",  fa);
                    data.put("roll_no",      student.getId());
                    data.put("programme",    fsFinal.getProgramme());
                    data.put("semester",     fsFinal.getSemester());
                    data.put("shift",        shiftField.getText().trim());
                    populateFeeData(data, fsFinal);
                    String outName = "Challan_" + student.getId() + "_" + fsFinal.getSemester().replaceAll("\\s+","_");
                    generateAndOpenChallan(data, outName);
                    SwingUtilities.invokeLater(() -> {
                        statusLbl.setForeground(UITheme.SUCCESS);
                        statusLbl.setText("Challan generated successfully!");
                        generateBtn.setEnabled(true);
                    });
                } catch (Exception ex) {
                    SwingUtilities.invokeLater(() -> {
                        statusLbl.setForeground(UITheme.DANGER);
                        statusLbl.setText("Error: " + ex.getMessage());
                        generateBtn.setEnabled(true);
                    });
                }
            }).start();
        });

        btnRow.add(generateBtn);
        content.add(infoCard, BorderLayout.CENTER);
        content.add(btnRow, BorderLayout.SOUTH);

        add(header, BorderLayout.NORTH);
        add(content, BorderLayout.CENTER);
        revalidate(); repaint();
    }

    // =========================================================
    //  DIALOGS
    // =========================================================

    private void showAddFeeStructureDialog()              { showFeeStructureDialog(null); }
    private void showEditFeeStructureDialog(FeeStructure e) { showFeeStructureDialog(e); }

    private void showFeeStructureDialog(FeeStructure existing) {
        boolean isNew = (existing == null);
        JDialog dlg = new JDialog(parentFrame, isNew ? "New Fee Structure" : "Edit Fee Structure", true);
        dlg.setSize(580, 680);
        dlg.setLocationRelativeTo(parentFrame);
        dlg.setLayout(new BorderLayout(0, 0));
        dlg.getContentPane().setBackground(UITheme.CARD_BG);

        JPanel title = new JPanel(new BorderLayout()) {
            @Override protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g.create();
                GradientPaint gp = new GradientPaint(0,0,UITheme.PRIMARY_DARK,getWidth(),0,UITheme.SECONDARY);
                g2.setPaint(gp); g2.fillRect(0,0,getWidth(),getHeight()); g2.dispose();
            }
        };
        title.setPreferredSize(new Dimension(0, 56));
        title.setBorder(BorderFactory.createEmptyBorder(12, 20, 12, 20));
        title.add(UITheme.label(
            isNew ? "New Fee Structure" : "Edit: " + existing,
            UITheme.headingFont(), Color.WHITE), BorderLayout.WEST);

        JPanel form = new JPanel(new GridBagLayout());
        form.setBackground(UITheme.CARD_BG);
        form.setBorder(BorderFactory.createEmptyBorder(14, 22, 14, 22));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(7, 8, 7, 8);
        gbc.anchor = GridBagConstraints.WEST;
        gbc.fill   = GridBagConstraints.HORIZONTAL;

        gbc.gridx = 0; gbc.gridy = 0; gbc.weightx = 0; gbc.gridwidth = 1;
        form.add(UITheme.label("Programme *:", UITheme.boldFont(), UITheme.TEXT_DARK), gbc);
        JTextField progF = UITheme.styledField();
        progF.setText(existing != null ? existing.getProgramme() : "BSSE");
        gbc.gridx = 1; gbc.weightx = 0.5;
        form.add(progF, gbc);

        gbc.gridx = 2; gbc.weightx = 0;
        form.add(UITheme.label("Semester *:", UITheme.boldFont(), UITheme.TEXT_DARK), gbc);
        JTextField semF = UITheme.styledField();
        semF.setText(existing != null ? existing.getSemester() : "1st");
        gbc.gridx = 3; gbc.weightx = 0.5;
        form.add(semF, gbc);

        String[][] feeFields = {
            {"Admission Fee",        existing != null ? String.valueOf(existing.getAdmissionFee())        : "0"},
            {"Registration Fee",     existing != null ? String.valueOf(existing.getRegistrationFee())     : "0"},
            {"Library Security",     existing != null ? String.valueOf(existing.getLibrarySecurityFee())  : "0"},
            {"Tuition Fee *",        existing != null ? String.valueOf(existing.getTuitionFee())          : "63000"},
            {"Examination Fee",      existing != null ? String.valueOf(existing.getExaminationFee())      : "3300"},
            {"Maintenance Charges",  existing != null ? String.valueOf(existing.getMaintenanceCharges())  : "3300"},
            {"Audio/Video (AVS)",    existing != null ? String.valueOf(existing.getAudioVideoFee())       : "0"},
            {"Library Subscription", existing != null ? String.valueOf(existing.getLibrarySubscription()) : "880"},
            {"Computer Lab",         existing != null ? String.valueOf(existing.getComputerLabFee())      : "3300"},
            {"Sports Fund",          existing != null ? String.valueOf(existing.getSportsFund())          : "100"},
            {"Magazine Fund",        existing != null ? String.valueOf(existing.getMagazineFund())        : "220"},
            {"IT Services",          existing != null ? String.valueOf(existing.getItServicesFee())       : "1110"},
            {"Research Fund",        existing != null ? String.valueOf(existing.getResearchFund())        : "0"},
            {"Study Material",       existing != null ? String.valueOf(existing.getStudyMaterial())       : "0"},
        };

        Map<String, JTextField> fieldMap = new LinkedHashMap<>();
        for (int i = 0; i < feeFields.length; i++) {
            int col = (i % 2) * 2;
            int rowIdx = 1 + i / 2;
            gbc.gridx = col; gbc.gridy = rowIdx; gbc.weightx = 0; gbc.gridwidth = 1;
            form.add(UITheme.label(feeFields[i][0] + ":", UITheme.boldFont(), UITheme.TEXT_DARK), gbc);
            JTextField tf = UITheme.styledField();
            tf.setText(feeFields[i][1]);
            gbc.gridx = col + 1; gbc.weightx = 0.5;
            form.add(tf, gbc);
            fieldMap.put(feeFields[i][0], tf);
        }

        JCheckBox enableCb = new JCheckBox("Enable Fee Generation for Students");
        enableCb.setFont(UITheme.boldFont());
        enableCb.setForeground(UITheme.SUCCESS);
        enableCb.setBackground(UITheme.CARD_BG);
        enableCb.setSelected(existing != null && existing.isFeeGenerationEnabled());
        gbc.gridx = 0; gbc.gridy = 1 + feeFields.length / 2 + 1;
        gbc.gridwidth = 4; gbc.weightx = 1;
        form.add(enableCb, gbc);

        JPanel btnRow = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 10));
        btnRow.setBackground(UITheme.CARD_BG);
        JButton save   = UITheme.accentButton(isNew ? "Save Structure" : "Update Structure");
        JButton cancel = UITheme.ghostButton("Cancel");
        cancel.addActionListener(e -> dlg.dispose());
        save.addActionListener(e -> {
            try {
                FeeStructure fs = isNew
                    ? new FeeStructure(DataManager.generateFeeStructureId(), progF.getText().trim(), semF.getText().trim())
                    : existing;
                if (!isNew) {
                    fs.setProgramme(progF.getText().trim());
                    fs.setSemester(semF.getText().trim());
                }
                fs.setAdmissionFee(     parse(fieldMap, "Admission Fee"));
                fs.setRegistrationFee(  parse(fieldMap, "Registration Fee"));
                fs.setLibrarySecurityFee(parse(fieldMap, "Library Security"));
                fs.setTuitionFee(       parse(fieldMap, "Tuition Fee *"));
                fs.setExaminationFee(   parse(fieldMap, "Examination Fee"));
                fs.setMaintenanceCharges(parse(fieldMap, "Maintenance Charges"));
                fs.setAudioVideoFee(    parse(fieldMap, "Audio/Video (AVS)"));
                fs.setLibrarySubscription(parse(fieldMap, "Library Subscription"));
                fs.setComputerLabFee(   parse(fieldMap, "Computer Lab"));
                fs.setSportsFund(       parse(fieldMap, "Sports Fund"));
                fs.setMagazineFund(     parse(fieldMap, "Magazine Fund"));
                fs.setItServicesFee(    parse(fieldMap, "IT Services"));
                fs.setResearchFund(     parse(fieldMap, "Research Fund"));
                fs.setStudyMaterial(    parse(fieldMap, "Study Material"));
                fs.setFeeGenerationEnabled(enableCb.isSelected());

                if (isNew) DataManager.addFeeStructure(fs);
                else        DataManager.updateFeeStructure(fs);

                dlg.dispose();
                buildAdminView();
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(dlg, "All fee amounts must be valid numbers.", "Validation Error", JOptionPane.ERROR_MESSAGE);
            }
        });
        btnRow.add(cancel); btnRow.add(save);

        JScrollPane scrollForm = new JScrollPane(form);
        scrollForm.setBorder(null);
        scrollForm.getViewport().setBackground(UITheme.CARD_BG);

        dlg.add(title, BorderLayout.NORTH);
        dlg.add(scrollForm, BorderLayout.CENTER);
        dlg.add(btnRow, BorderLayout.SOUTH);
        dlg.setVisible(true);
    }

    // =========================================================
    //  DATA HELPERS
    // =========================================================

    private void populateFeeData(Map<String, Object> data, FeeStructure fs) {
        int challanNo = DataManager.getNextChallanNumber();
        data.put("challan_no",    challanNo);
        data.put("issue_date",    new SimpleDateFormat("d/MMM/yy").format(new Date()));
        Date due = new Date(System.currentTimeMillis() + 30L * 24 * 60 * 60 * 1000);
        data.put("due_date",      new SimpleDateFormat("d/MMM/yy").format(due));
        data.put("university_name",    "NUML");
        data.put("campus_name",        "Lahore Campus");
        data.put("university_address", "1st Floor, 3rd Block Aiwan-e-Iqbal Complex, Lahore | Tel: 042-99204588");
        data.put("admission_fee",       fs.getAdmissionFee());
        data.put("registration_fee",    fs.getRegistrationFee());
        data.put("library_security_fee",fs.getLibrarySecurityFee());
        data.put("tuition_fee",         fs.getTuitionFee());
        data.put("examination_fee",     fs.getExaminationFee());
        data.put("maintenance_charges", fs.getMaintenanceCharges());
        data.put("audio_video_fee",     fs.getAudioVideoFee());
        data.put("library_subscription",fs.getLibrarySubscription());
        data.put("computer_lab_fee",    fs.getComputerLabFee());
        data.put("sports_fund",         fs.getSportsFund());
        data.put("magazine_fund",       fs.getMagazineFund());
        data.put("it_services_fee",     fs.getItServicesFee());
        data.put("research_fund",       fs.getResearchFund());
        data.put("study_material",      fs.getStudyMaterial());
        data.put("total",               fs.getTotal());
    }

    // =========================================================
    //  PURE-JAVA PDF GENERATION  (replaces generate_challan.py)
    // =========================================================

    /**
     * Generates a fee-challan PDF using only Java standard libraries
     * (java.awt, javax.imageio, javax.print).  The PDF is hand-written
     * as a minimal single-page document; no third-party library is needed.
     */
    private void generateAndOpenChallan(Map<String, Object> data, String baseName) {
        try {
            File outDir = new File("challans");
            outDir.mkdirs();
            File pdfFile = new File(outDir, baseName + ".pdf");

            // ---- render the challan to a BufferedImage first ----
            int PAGE_W = 794;   // A4 @ 96 dpi
            int PAGE_H = 1123;
            BufferedImage img = new BufferedImage(PAGE_W, PAGE_H, BufferedImage.TYPE_INT_RGB);
            Graphics2D g = img.createGraphics();
            g.setRenderingHint(RenderingHints.KEY_ANTIALIASING,  RenderingHints.VALUE_ANTIALIAS_ON);
            g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);

            drawChallanPage(g, PAGE_W, PAGE_H, data);
            g.dispose();

            // ---- encode image as PDF ----
            writeSingleImagePdf(pdfFile, img);

            // ---- open file ----
            if (Desktop.isDesktopSupported() && Desktop.getDesktop().isSupported(Desktop.Action.OPEN)) {
                Desktop.getDesktop().open(pdfFile);
            } else {
                JOptionPane.showMessageDialog(parentFrame,
                    "Challan saved to: " + pdfFile.getAbsolutePath(),
                    "Challan Generated", JOptionPane.INFORMATION_MESSAGE);
            }

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(parentFrame,
                "Could not generate challan:\n" + ex.getMessage(),
                "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    /** Draws the full challan page onto a Graphics2D context. */
    private void drawChallanPage(Graphics2D g, int W, int H, Map<String, Object> data) {
        // Background
        g.setColor(Color.WHITE);
        g.fillRect(0, 0, W, H);

        String uniName   = str(data, "university_name");
        String campus    = str(data, "campus_name");
        String address   = str(data, "university_address");
        String studentName = str(data, "student_name");
        String fatherName  = str(data, "father_name");
        String rollNo      = str(data, "roll_no");
        String programme   = str(data, "programme");
        String semester    = str(data, "semester");
        String shift       = str(data, "shift");
        String issueDate   = str(data, "issue_date");
        String dueDate     = str(data, "due_date");
        int    challanNo   = num(data, "challan_no");

        // ---- HEADER BANNER ----
        GradientPaint headerGrad = new GradientPaint(0, 0, new Color(5, 55, 120), W, 0, new Color(13, 110, 160));
        g.setPaint(headerGrad);
        g.fillRect(0, 0, W, 90);

        // Try to draw logo
        try {
            File logoFile = new File("icon/university_logo.png");
            if (logoFile.exists()) {
                BufferedImage logo = ImageIO.read(logoFile);
                int lh = 70, lw = (int)(logo.getWidth() * (70.0 / logo.getHeight()));
                g.drawImage(logo, 18, 10, lw, lh, null);
            }
        } catch (Exception ignored) {}

        g.setColor(Color.WHITE);
        g.setFont(new Font("SansSerif", Font.BOLD, 22));
        g.drawString(uniName + " - " + campus, 110, 42);
        g.setFont(new Font("SansSerif", Font.PLAIN, 11));
        g.drawString(address, 110, 62);

        g.setFont(new Font("SansSerif", Font.BOLD, 13));
        g.drawString("FEE CHALLAN", W - 160, 42);
        g.setFont(new Font("SansSerif", Font.PLAIN, 11));
        g.drawString("Challan No: " + challanNo,  W - 160, 60);
        g.drawString("Issue Date:  " + issueDate, W - 160, 75);

        // ---- CHALLAN META ROW ----
        g.setColor(new Color(230, 240, 255));
        g.fillRect(0, 90, W, 32);
        g.setColor(new Color(5, 55, 120));
        g.setFont(new Font("SansSerif", Font.BOLD, 12));
        g.drawString("Due Date: " + dueDate, 20, 112);
        g.drawString("Please pay before the due date to avoid late fee charges.", W / 2 - 150, 112);

        // ---- STUDENT INFO CARD ----
        int cardY = 140;
        drawCard(g, 20, cardY, W - 40, 130, "Student Information");
        int infoY = cardY + 38;
        String[][] infoLeft = {
            {"Student Name",  studentName},
            {"Father's Name", fatherName},
            {"Roll Number",   rollNo},
        };
        String[][] infoRight = {
            {"Programme", programme},
            {"Semester",  semester},
            {"Shift",     shift},
        };
        drawInfoGrid(g, 40, infoY, (W - 80) / 2 - 10, infoLeft);
        drawInfoGrid(g, 40 + (W - 80) / 2, infoY, (W - 80) / 2 - 10, infoRight);

        // ---- FEE BREAKDOWN TABLE ----
        int tableY = cardY + 150;
        drawCard(g, 20, tableY, W - 40, 380, "Fee Breakdown");

        String[][] fees = {
            {"Admission Fee",        fmt(data, "admission_fee")},
            {"Registration Fee",     fmt(data, "registration_fee")},
            {"Library Security Deposit", fmt(data, "library_security_fee")},
            {"Tuition Fee",          fmt(data, "tuition_fee")},
            {"Examination Fee",      fmt(data, "examination_fee")},
            {"Maintenance Charges",  fmt(data, "maintenance_charges")},
            {"Audio / Video (AVS)",  fmt(data, "audio_video_fee")},
            {"Library Subscription", fmt(data, "library_subscription")},
            {"Computer Lab Fee",     fmt(data, "computer_lab_fee")},
            {"Sports Fund",          fmt(data, "sports_fund")},
            {"Magazine Fund",        fmt(data, "magazine_fund")},
            {"IT Services Fee",      fmt(data, "it_services_fee")},
            {"Research Fund",        fmt(data, "research_fund")},
            {"Study Material",       fmt(data, "study_material")},
        };

        int tX = 40, tY = tableY + 38, rowH = 24, colW = (W - 80) / 2 - 10;
        // Table header
        g.setColor(new Color(5, 55, 120));
        g.fillRoundRect(tX, tY, W - 80, rowH, 4, 4);
        g.setColor(Color.WHITE);
        g.setFont(new Font("SansSerif", Font.BOLD, 12));
        g.drawString("Description", tX + 10, tY + 17);
        g.drawString("Amount (Rs.)", tX + colW + 20, tY + 17);

        for (int i = 0; i < fees.length; i++) {
            int fy = tY + (i + 1) * rowH;
            g.setColor(i % 2 == 0 ? new Color(245, 248, 255) : Color.WHITE);
            g.fillRect(tX, fy, W - 80, rowH);
            g.setColor(new Color(200, 210, 230));
            g.drawLine(tX, fy + rowH, tX + W - 80, fy + rowH);
            g.setColor(new Color(40, 40, 60));
            g.setFont(new Font("SansSerif", Font.PLAIN, 12));
            g.drawString(fees[i][0], tX + 10, fy + 17);
            g.setFont(new Font("SansSerif", Font.BOLD, 12));
            g.drawString(fees[i][1], tX + colW + 20, fy + 17);
        }

        // Total row
        int totalY = tY + (fees.length + 1) * rowH;
        GradientPaint totalGrad = new GradientPaint(tX, 0, new Color(5, 55, 120), tX + W - 80, 0, new Color(13, 110, 160));
        g.setPaint(totalGrad);
        g.fillRoundRect(tX, totalY, W - 80, 30, 4, 4);
        g.setColor(Color.WHITE);
        g.setFont(new Font("SansSerif", Font.BOLD, 14));
        g.drawString("TOTAL PAYABLE", tX + 10, totalY + 21);
        g.drawString("Rs. " + fmt(data, "total"), tX + colW + 20, totalY + 21);

        // ---- BANK COPY / UNIVERSITY COPY DIVIDER ----
        int divY = totalY + 50;
        g.setColor(new Color(180, 180, 200));
        float[] dash = {10f, 6f};
        g.setStroke(new BasicStroke(1.5f, BasicStroke.CAP_BUTT, BasicStroke.JOIN_MITER, 10f, dash, 0f));
        g.drawLine(20, divY, W - 20, divY);
        g.setStroke(new BasicStroke(1f));
        g.setColor(new Color(120, 120, 150));
        g.setFont(new Font("SansSerif", Font.ITALIC, 11));
        g.drawString("✂  Bank Copy", 30, divY - 4);
        g.drawString("University Copy  ✂", W - 155, divY - 4);

        // ---- FOOTER ----
        int footerY = H - 54;
        g.setColor(new Color(240, 245, 255));
        g.fillRect(0, footerY, W, 54);
        g.setColor(new Color(5, 55, 120));
        g.setStroke(new BasicStroke(1.5f));
        g.drawLine(0, footerY, W, footerY);
        g.setFont(new Font("SansSerif", Font.PLAIN, 10));
        g.setColor(new Color(80, 80, 120));
        g.drawString("This is a computer-generated fee challan. No signature required.", 20, footerY + 18);
        g.drawString("For queries: accounts@numl.edu.pk  |  " + address, 20, footerY + 34);
        g.drawString("Generated: " + new SimpleDateFormat("dd-MMM-yyyy HH:mm").format(new Date()), W - 220, footerY + 18);
    }

    /** Draws a titled card (rounded rect with heading bar). */
    private void drawCard(Graphics2D g, int x, int y, int w, int h, String title) {
        // Shadow
        g.setColor(new Color(0, 0, 0, 18));
        g.fillRoundRect(x + 3, y + 3, w, h, 12, 12);
        // Card background
        g.setColor(Color.WHITE);
        g.fillRoundRect(x, y, w, h, 12, 12);
        // Border
        g.setColor(new Color(210, 220, 240));
        g.setStroke(new BasicStroke(1f));
        g.drawRoundRect(x, y, w, h, 12, 12);
        // Title bar
        GradientPaint gp = new GradientPaint(x, y, new Color(5, 55, 120), x + w, y, new Color(30, 100, 160));
        g.setPaint(gp);
        g.fillRoundRect(x, y, w, 28, 12, 12);
        g.fillRect(x, y + 14, w, 14);
        g.setColor(Color.WHITE);
        g.setFont(new Font("SansSerif", Font.BOLD, 12));
        g.drawString(title, x + 12, y + 19);
    }

    /** Draws a 2-column label/value grid. */
    private void drawInfoGrid(Graphics2D g, int x, int y, int w, String[][] rows) {
        int rh = 26;
        for (int i = 0; i < rows.length; i++) {
            int ry = y + i * rh;
            g.setColor(new Color(90, 110, 160));
            g.setFont(new Font("SansSerif", Font.BOLD, 11));
            g.drawString(rows[i][0] + ":", x, ry + 14);
            g.setColor(new Color(20, 20, 50));
            g.setFont(new Font("SansSerif", Font.PLAIN, 12));
            g.drawString(rows[i][1], x + 130, ry + 14);
            g.setColor(new Color(220, 228, 245));
            g.drawLine(x, ry + rh - 2, x + w, ry + rh - 2);
        }
    }

    // =========================================================
    //  MINIMAL PDF WRITER  (hand-coded PDF 1.4, single image page)
    // =========================================================

    /**
     * Writes a minimal, standards-compliant PDF containing one A4 page
     * with the challan rendered as a JPEG image.  No external library needed.
     *
     * Structure: header → image XObject → page tree → content stream → xref → trailer
     */
    private void writeSingleImagePdf(File outFile, BufferedImage img) throws IOException {
        // Encode the image as JPEG into a byte array
        ByteArrayOutputStream jpegBuf = new ByteArrayOutputStream();
        javax.imageio.ImageIO.write(img, "jpeg", jpegBuf);
        byte[] jpegBytes = jpegBuf.toByteArray();

        int imgW = img.getWidth();
        int imgH = img.getHeight();

        ByteArrayOutputStream pdfBuf = new ByteArrayOutputStream();
        // We'll track byte offsets for xref
        List<Long> offsets = new ArrayList<>();

        // Helper: write bytes and return running position
        // We use a wrapper that counts bytes
        CountingOutputStream cos = new CountingOutputStream(pdfBuf);
        PrintStream ps = new PrintStream(cos, false, "ISO-8859-1");

        // PDF header
        ps.print("%PDF-1.4\n");
        ps.print("%\u00e2\u00e3\u00cf\u00d3\n"); // binary comment (marks as binary file)

        // Object 1: Catalog
        offsets.add(cos.count());
        ps.print("1 0 obj\n<< /Type /Catalog /Pages 2 0 R >>\nendobj\n");

        // Object 2: Pages
        offsets.add(cos.count());
        ps.print("2 0 obj\n<< /Type /Pages /Kids [4 0 R] /Count 1 >>\nendobj\n");

        // Object 3: Image XObject (JPEG)
        offsets.add(cos.count());
        ps.print("3 0 obj\n");
        ps.print("<< /Type /XObject /Subtype /Image\n");
        ps.print("   /Width " + imgW + " /Height " + imgH + "\n");
        ps.print("   /ColorSpace /DeviceRGB /BitsPerComponent 8\n");
        ps.print("   /Filter /DCTDecode /Length " + jpegBytes.length + "\n");
        ps.print(">>\n");
        ps.print("stream\n");
        ps.flush();
        cos.write(jpegBytes);
        ps.print("\nendstream\nendobj\n");

        // Object 4: Page  (A4: 595 x 842 pt)
        // Scale image to fill A4 page
        offsets.add(cos.count());
        ps.print("4 0 obj\n");
        ps.print("<< /Type /Page /Parent 2 0 R\n");
        ps.print("   /MediaBox [0 0 595 842]\n");
        ps.print("   /Contents 5 0 R\n");
        ps.print("   /Resources << /XObject << /Im1 3 0 R >> >>\n");
        ps.print(">>\nendobj\n");

        // Object 5: Content stream – draw the image at full page size
        String contentStr = "q 595 0 0 842 0 0 cm /Im1 Do Q\n";
        byte[] contentBytes = contentStr.getBytes("ISO-8859-1");
        offsets.add(cos.count());
        ps.print("5 0 obj\n<< /Length " + contentBytes.length + " >>\nstream\n");
        ps.flush();
        cos.write(contentBytes);
        ps.print("\nendstream\nendobj\n");

        // Cross-reference table
        long xrefOffset = cos.count();
        ps.print("xref\n");
        ps.print("0 6\n");
        ps.printf("%010d 65535 f \n", 0);
        for (Long off : offsets) {
            ps.printf("%010d 00000 n \n", off);
        }

        // Trailer
        ps.print("trailer\n<< /Size 6 /Root 1 0 R >>\n");
        ps.print("startxref\n" + xrefOffset + "\n%%EOF\n");
        ps.flush();

        try (FileOutputStream fos = new FileOutputStream(outFile)) {
            pdfBuf.writeTo(fos);
        }
    }

    /** Simple OutputStream wrapper that counts bytes written. */
    private static class CountingOutputStream extends OutputStream {
        private final OutputStream wrapped;
        private long bytesWritten = 0;

        CountingOutputStream(OutputStream wrapped) { this.wrapped = wrapped; }

        @Override public void write(int b) throws IOException {
            wrapped.write(b); bytesWritten++;
        }
        @Override public void write(byte[] b, int off, int len) throws IOException {
            wrapped.write(b, off, len); bytesWritten += len;
        }
        @Override public void flush() throws IOException { wrapped.flush(); }

        long count() { return bytesWritten; }
    }

    // =========================================================
    //  UTILITY HELPERS
    // =========================================================

    private String str(Map<String, Object> d, String k) {
        Object v = d.get(k);
        return v == null ? "" : v.toString();
    }

    private int num(Map<String, Object> d, String k) {
        Object v = d.get(k);
        if (v == null) return 0;
        try { return Integer.parseInt(v.toString()); } catch (Exception e) { return 0; }
    }

    private String fmt(Map<String, Object> d, String k) {
        Object v = d.get(k);
        if (v == null) return "0";
        try { return String.format("%,.0f", Double.parseDouble(v.toString())); }
        catch (Exception e) { return v.toString(); }
    }

    private double parse(Map<String, JTextField> m, String key) {
        String v = m.get(key).getText().trim();
        if (v.isEmpty()) return 0;
        return Double.parseDouble(v);
    }

    private void msg(String text) {
        JOptionPane.showMessageDialog(parentFrame, text);
    }

    private JPanel buildHeader(String title, String subtitle, Color c1, Color c2) {
        JPanel banner = new JPanel(new BorderLayout()) {
            @Override protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g.create();
                GradientPaint gp = new GradientPaint(0,0,c1,getWidth(),0,c2);
                g2.setPaint(gp); g2.fillRect(0,0,getWidth(),getHeight());
                g2.setColor(new Color(255,255,255,10));
                g2.fillOval(getWidth()-150,-40,200,200);
                g2.dispose();
            }
        };
        banner.setPreferredSize(new Dimension(0, 80));
        banner.setBorder(BorderFactory.createEmptyBorder(14, 28, 14, 28));
        JPanel texts = new JPanel(new GridLayout(2,1,0,3)); texts.setOpaque(false);
        texts.add(UITheme.label(title,    UITheme.font(Font.BOLD, 20), Color.WHITE));
        texts.add(UITheme.label(subtitle, UITheme.font(Font.PLAIN, 12), new Color(200,225,255)));
        banner.add(texts, BorderLayout.WEST);
        return banner;
    }

    private JPanel buildCard() {
        JPanel p = new JPanel() {
            @Override protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(new Color(0,0,0,7));
                g2.fillRoundRect(2,2,getWidth()-2,getHeight()-2,14,14);
                g2.setColor(Color.WHITE);
                g2.fillRoundRect(0,0,getWidth()-2,getHeight()-2,14,14);
                g2.dispose();
            }
        };
        p.setOpaque(false);
        p.setBorder(BorderFactory.createEmptyBorder(20, 24, 20, 24));
        return p;
    }
}
