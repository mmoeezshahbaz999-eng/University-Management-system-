package gui;

import models.*;
import utils.DataManager;
import utils.UITheme;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;
import java.awt.*;
import java.util.*;
import java.util.List;
import java.util.stream.Collectors;

public class StudentDashboard extends BaseDashboard {

    private Student student;

    public StudentDashboard(Student student) {
        super(student, "Student Portal - " + student.getName());
        this.student = student;
        showDefaultPanel();
    }

    @Override
    protected void addNavigationItems() {
        addNavButton("home",        "Dashboard",    this::showDashboard);
        addNavButton("courses",     "Courses",      this::showCourseCatalog);
        addNavButton("assignments", "Assignments",  this::showAssignments);
        addNavButton("grades",      "Results",      this::showResults);
        addNavButton("calendar",    "Calendar",     this::showCalendar);
        addNavButton("notices",     "Notices",      this::showNotices);
        addNavButton("fee",         "Fee Challan",  this::showFeeChallan);
        addNavButton("profile",     "Profile",      this::showProfile);
    }

    @Override
    protected void showDefaultPanel() { showDashboard(); }

    // ─────────────────────────────────────────────────────────────────
    //  DASHBOARD
    // ─────────────────────────────────────────────────────────────────
    private void showDashboard() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(UITheme.CONTENT_BG);

        JPanel headerBanner = new JPanel(new BorderLayout()) {
            @Override protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                GradientPaint gp = new GradientPaint(0, 0, new Color(5, 95, 150), getWidth(), 0, new Color(13, 148, 136));
                g2.setPaint(gp); g2.fillRect(0, 0, getWidth(), getHeight());
                g2.setColor(new Color(255,255,255,10));
                g2.fillOval(getWidth()-160,-40,190,190);
                g2.fillOval(getWidth()-80,15,100,100);
                g2.dispose();
            }
        };
        headerBanner.setPreferredSize(new Dimension(0, 92));
        headerBanner.setBorder(BorderFactory.createEmptyBorder(18, 30, 18, 30));
        JPanel hTexts = new JPanel(new GridLayout(2,1,0,5)); hTexts.setOpaque(false);
        hTexts.add(UITheme.label("Welcome back, " + student.getName().split(" ")[0] + "!", UITheme.font(Font.BOLD, 24), Color.WHITE));
        hTexts.add(UITheme.label(student.getSemester() + "  \u2022  " + student.getMajor() + "  \u2022  Year " + student.getYear(),
                UITheme.font(Font.PLAIN, 13), new Color(200,235,230)));
        headerBanner.add(hTexts, BorderLayout.WEST);

        List<String> enrolled = DataManager.getEnrolledCourseIds(student.getId());
        List<Grade> grades    = DataManager.getGradesForStudent(student.getId());
        double cgpa = DataManager.calculateCGPA(student.getId());

        JPanel statsRow = new JPanel(new GridLayout(1, 4, 16, 0));
        statsRow.setOpaque(false);
        statsRow.setBorder(BorderFactory.createEmptyBorder(20, 26, 16, 26));
        statsRow.add(UITheme.statCard(String.valueOf(enrolled.size()), "Enrolled Courses", UITheme.TEAL, "#"));
        statsRow.add(UITheme.statCard(String.valueOf(grades.size()),   "Completed Courses", UITheme.SECONDARY, ""));
        statsRow.add(UITheme.statCard(String.format("%.2f", cgpa),     "CGPA", UITheme.SUCCESS, "*"));
        statsRow.add(UITheme.statCard("Sem " + student.getYear(),      "Academic Year",    UITheme.ACCENT, ""));

        JPanel midRow = new JPanel(new GridLayout(1, 2, 16, 0));
        midRow.setOpaque(false);
        midRow.setBorder(BorderFactory.createEmptyBorder(4, 26, 0, 26));

        // Enrolled courses quick list
        JPanel schedCard = buildRoundCard();
        schedCard.add(UITheme.label("  Current Enrollments", UITheme.subheadFont(), UITheme.TEXT_DARK), BorderLayout.NORTH);
        JPanel schedList = new JPanel(); schedList.setLayout(new BoxLayout(schedList, BoxLayout.Y_AXIS)); schedList.setOpaque(false);
        Color[] clrs = {UITheme.TEAL, UITheme.INFO, UITheme.PRIMARY, UITheme.WARNING, UITheme.SUCCESS, UITheme.PURPLE};
        int ci = 0;
        for (String cid : enrolled) {
            if (ci >= 5) break;
            Course c = DataManager.findCourseById(cid);
            if (c != null) schedList.add(UITheme.scheduleRow(c.getCourseId(), c.getCourseName(), clrs[ci % clrs.length]));
            ci++;
        }
        if (enrolled.isEmpty()) schedList.add(UITheme.label("No courses enrolled yet.", UITheme.bodyFont(), UITheme.TEXT_MUTED));
        schedCard.add(schedList, BorderLayout.CENTER);

        // Recent notices
        JPanel actCard = buildRoundCard();
        actCard.add(UITheme.label("*  Recent Notices", UITheme.subheadFont(), UITheme.TEXT_DARK), BorderLayout.NORTH);
        JPanel actList = new JPanel(); actList.setLayout(new BoxLayout(actList, BoxLayout.Y_AXIS)); actList.setOpaque(false);
        List<Announcement> anns = DataManager.loadAnnouncements();
        int cnt = 0;
        for (Announcement a : anns) {
            if (cnt >= 4) break;
            Color dot = a.getPriority().equals("HIGH") ? UITheme.DANGER : a.getPriority().equals("MEDIUM") ? UITheme.WARNING : UITheme.SUCCESS;
            actList.add(UITheme.announcementRow(a.getTitle(), a.getAuthorName() + " - " + a.getDateTime(), dot));
            cnt++;
        }
        if (cnt == 0) actList.add(UITheme.label("No recent notices.", UITheme.bodyFont(), UITheme.TEXT_MUTED));
        actCard.add(actList, BorderLayout.CENTER);

        midRow.add(schedCard);
        midRow.add(actCard);

        // Quick actions row
        JPanel botRow = new JPanel(new GridLayout(1, 2, 16, 0));
        botRow.setOpaque(false);
        botRow.setBorder(BorderFactory.createEmptyBorder(16, 26, 26, 26));

        // Semester GPA summary
        JPanel gpaCard = buildRoundCard();
        gpaCard.add(UITheme.label("  Semester GPA Summary", UITheme.subheadFont(), UITheme.TEXT_DARK), BorderLayout.NORTH);
        JPanel gpaList = new JPanel(); gpaList.setLayout(new BoxLayout(gpaList, BoxLayout.Y_AXIS)); gpaList.setOpaque(false);
        Set<String> semesters = new LinkedHashSet<>();
        for (Grade g : grades) semesters.add(g.getSemester());
        for (String sem : semesters) {
            double sgpa = DataManager.calculateSemesterGPA(student.getId(), sem);
            JPanel row = new JPanel(new BorderLayout()); row.setOpaque(false); row.setMaximumSize(new Dimension(Integer.MAX_VALUE, 28));
            row.add(UITheme.label(sem, UITheme.bodyFont(), UITheme.TEXT_MEDIUM), BorderLayout.WEST);
            JLabel gpaLbl = UITheme.label(String.format("GPA: %.2f", sgpa), UITheme.boldFont(), UITheme.TEAL);
            row.add(gpaLbl, BorderLayout.EAST);
            gpaList.add(row);
            gpaList.add(Box.createVerticalStrut(4));
        }
        if (semesters.isEmpty()) gpaList.add(UITheme.label("No results available yet.", UITheme.bodyFont(), UITheme.TEXT_MUTED));
        gpaCard.add(gpaList, BorderLayout.CENTER);

        // Quick access buttons
        JPanel qaCard = buildRoundCard();
        qaCard.add(UITheme.label("  Quick Access", UITheme.subheadFont(), UITheme.TEXT_DARK), BorderLayout.NORTH);
        JPanel qaGrid = new JPanel(new GridLayout(2, 2, 10, 10)); qaGrid.setOpaque(false);
        String[] qaLabels  = {"+ Enroll Course", "View Results", "Course Catalog", "My Profile"};
        Runnable[] qaActs  = {this::showEnrollDialog, this::showResults, this::showCourseCatalog, this::showProfile};
        Color[]    qaClrs  = {UITheme.TEAL, UITheme.SUCCESS, UITheme.INFO, UITheme.ACCENT};
        for (int i = 0; i < qaLabels.length; i++) {
            final Runnable act = qaActs[i]; final Color clr = qaClrs[i]; final String lbl = qaLabels[i];
            JButton btn = new JButton(lbl) {
                @Override protected void paintComponent(Graphics g) {
                    Graphics2D g2 = (Graphics2D) g.create();
                    g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                    g2.setColor(clr); g2.fillRoundRect(0, 0, getWidth(), getHeight(), 10, 10); g2.dispose();
                    super.paintComponent(g);
                }
            };
            btn.setForeground(Color.WHITE); btn.setFont(UITheme.boldFont());
            btn.setContentAreaFilled(false); btn.setOpaque(false); btn.setBorderPainted(false);
            btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
            btn.addActionListener(e -> act.run());
            qaGrid.add(btn);
        }
        qaCard.add(qaGrid, BorderLayout.CENTER);

        botRow.add(gpaCard);
        botRow.add(qaCard);

        JPanel body = new JPanel(new BorderLayout());
        body.setOpaque(false);
        body.add(statsRow, BorderLayout.NORTH);
        JPanel rows = new JPanel();
        rows.setLayout(new BoxLayout(rows, BoxLayout.Y_AXIS));
        rows.setOpaque(false);
        rows.add(midRow);
        rows.add(botRow);
        body.add(rows, BorderLayout.CENTER);

        panel.add(headerBanner, BorderLayout.NORTH);
        panel.add(body, BorderLayout.CENTER);
        showContent(panel);
    }

    // ─────────────────────────────────────────────────────────────────
    //  COURSE CATALOG (Semester-wise view with Enroll/Drop & Outline)
    // ─────────────────────────────────────────────────────────────────
    private void showCourseCatalog() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(UITheme.CONTENT_BG);

        JPanel headerBanner = buildSectionHeader("\uD83D\uDCDA  Course Catalog", "Browse all BSCS courses semester-wise | Enroll or drop anytime",
                new Color(5, 95, 150), new Color(13, 148, 136));

        // Top buttons
        JButton myCoursesBtn = UITheme.ghostButton("My Enrolled Courses");
        JButton enrollBtn    = UITheme.accentButton("+ Quick Enroll");
        myCoursesBtn.addActionListener(e -> showMyCourses());
        enrollBtn.addActionListener(e -> showEnrollDialog());
        JPanel btnWrap = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0)); btnWrap.setOpaque(false);
        btnWrap.add(myCoursesBtn); btnWrap.add(enrollBtn);
        headerBanner.add(btnWrap, BorderLayout.EAST);

        // Tabbed semester view
        JTabbedPane tabs = new JTabbedPane(JTabbedPane.TOP);
        tabs.setFont(UITheme.boldFont());
        tabs.setBackground(UITheme.CONTENT_BG);
        tabs.setForeground(UITheme.TEXT_DARK);

        // First tab: My enrolled courses
        tabs.addTab("My Courses", buildMyCoursesTab());

        // Semester tabs 1-8
        Map<Integer, List<Course>> bySem = DataManager.getCoursesBySemesterNumber();
        String[] semNames = {"", "Semester I", "Semester II", "Semester III", "Semester IV",
                             "Semester V", "Semester VI", "Semester VII", "Semester VIII"};
        for (int s = 1; s <= 8; s++) {
            List<Course> semCourses = bySem.getOrDefault(s, new ArrayList<>());
            tabs.addTab(semNames[s], buildSemesterTab(semCourses, s));
        }

        JPanel content = new JPanel(new BorderLayout());
        content.setOpaque(false);
        content.setBorder(BorderFactory.createEmptyBorder(12, 20, 20, 20));
        content.add(tabs, BorderLayout.CENTER);

        panel.add(headerBanner, BorderLayout.NORTH);
        panel.add(content, BorderLayout.CENTER);
        showContent(panel);
    }

    private JPanel buildMyCoursesTab() {
        JPanel tab = new JPanel(new BorderLayout());
        tab.setBackground(UITheme.CONTENT_BG);
        tab.setBorder(BorderFactory.createEmptyBorder(10, 0, 0, 0));

        List<String> enrolledIds = DataManager.getEnrolledCourseIds(student.getId());

        JPanel grid = new JPanel(new GridLayout(0, 2, 16, 16));
        grid.setOpaque(false);
        Color[] cardColors = {UITheme.TEAL, UITheme.SECONDARY, UITheme.SUCCESS, UITheme.PURPLE, UITheme.ACCENT, UITheme.INFO};
        int ci = 0;
        for (String cid : enrolledIds) {
            Course c = DataManager.findCourseById(cid);
            if (c != null) grid.add(buildCourseCard(c, cardColors[ci++ % cardColors.length], true));
        }
        if (enrolledIds.isEmpty()) {
            JLabel empty = UITheme.label("You are not enrolled in any course. Use 'My Courses' tab or '+ Quick Enroll'.", UITheme.bodyFont(), UITheme.TEXT_MUTED);
            grid.add(empty);
        }

        JScrollPane sp = new JScrollPane(grid);
        sp.setBorder(null);
        sp.getViewport().setBackground(UITheme.CONTENT_BG);
        tab.add(sp, BorderLayout.CENTER);
        return tab;
    }

    private JPanel buildSemesterTab(List<Course> courses, int semNum) {
        JPanel tab = new JPanel(new BorderLayout());
        tab.setBackground(UITheme.CONTENT_BG);
        tab.setBorder(BorderFactory.createEmptyBorder(10, 0, 0, 0));

        if (courses.isEmpty()) {
            tab.add(UITheme.label("No courses defined for this semester yet.", UITheme.bodyFont(), UITheme.TEXT_MUTED), BorderLayout.NORTH);
            return tab;
        }

        // Summary strip
        int totalCr = courses.stream().mapToInt(Course::getCreditHours).sum();
        JPanel strip = new JPanel(new FlowLayout(FlowLayout.LEFT, 16, 6));
        strip.setOpaque(false);
        strip.add(UITheme.label("Courses: " + courses.size(), UITheme.boldFont(), UITheme.TEXT_DARK));
        strip.add(UITheme.label("|", UITheme.bodyFont(), UITheme.TEXT_MUTED));
        strip.add(UITheme.label("Total Credit Hours: " + totalCr, UITheme.boldFont(), UITheme.TEAL));

        // Course cards
        JPanel grid = new JPanel(new GridLayout(0, 2, 16, 16));
        grid.setOpaque(false);
        Color[] cardColors = {UITheme.TEAL, UITheme.SECONDARY, UITheme.SUCCESS, UITheme.PURPLE, UITheme.ACCENT, UITheme.INFO};
        List<String> enrolledIds = DataManager.getEnrolledCourseIds(student.getId());
        int ci = 0;
        for (Course c : courses) {
            boolean isEnrolled = enrolledIds.contains(c.getCourseId());
            grid.add(buildCourseCard(c, cardColors[ci++ % cardColors.length], isEnrolled));
        }

        JScrollPane sp = new JScrollPane(grid);
        sp.setBorder(null);
        sp.getViewport().setBackground(UITheme.CONTENT_BG);

        tab.add(strip, BorderLayout.NORTH);
        tab.add(sp, BorderLayout.CENTER);
        return tab;
    }

    private JPanel buildCourseCard(Course c, Color accent, boolean isEnrolled) {
        JPanel card = new JPanel(new BorderLayout(0, 8)) {
            @Override protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(new Color(0,0,0,8)); g2.fillRoundRect(2,2,getWidth()-2,getHeight()-2,14,14);
                g2.setColor(Color.WHITE);        g2.fillRoundRect(0,0,getWidth()-2,getHeight()-2,14,14);
                g2.setColor(accent);             g2.fillRoundRect(0,0,getWidth()-2,5,4,4);
                g2.dispose();
            }
        };
        card.setOpaque(false);
        card.setBorder(BorderFactory.createEmptyBorder(16, 16, 12, 16));
        card.setPreferredSize(new Dimension(0, 200));

        // Header
        JPanel header = new JPanel(new BorderLayout()); header.setOpaque(false);
        JLabel idLbl   = UITheme.label(c.getCourseId(), UITheme.font(Font.BOLD, 10), accent);
        JLabel credLbl = UITheme.label(c.getCreditHours() + " Cr", UITheme.smallFont(), accent);
        header.add(idLbl, BorderLayout.WEST);
        header.add(credLbl, BorderLayout.EAST);

        JLabel nameLbl    = UITheme.label(c.getCourseName(), UITheme.subheadFont(), UITheme.TEXT_DARK);
        nameLbl.setBorder(BorderFactory.createEmptyBorder(4,0,2,0));
        JLabel teacherLbl = UITheme.label("  " + c.getTeacherName(), UITheme.bodyFont(), UITheme.TEXT_MEDIUM);
        JLabel metaLbl    = UITheme.label(" " + c.getRoom() + "   " + c.getSchedule(), UITheme.smallFont(), UITheme.TEXT_MUTED);
        JLabel semNumLbl  = UITheme.label(" " + c.getSemester(), UITheme.smallFont(), accent);

        JPanel body = new JPanel(); body.setLayout(new BoxLayout(body, BoxLayout.Y_AXIS)); body.setOpaque(false);
        body.add(header);
        body.add(nameLbl);
        body.add(teacherLbl);
        body.add(Box.createVerticalStrut(4));
        body.add(metaLbl);
        body.add(Box.createVerticalStrut(2));
        body.add(semNumLbl);

        // Action buttons
        JPanel btnRow = new JPanel(new FlowLayout(FlowLayout.RIGHT, 6, 0)); btnRow.setOpaque(false);

        JButton outlineBtn = UITheme.ghostButton("Outline");
        outlineBtn.setFont(UITheme.smallFont());
        outlineBtn.addActionListener(e -> showCourseOutlineDialog(c));

        if (isEnrolled) {
            JButton dropBtn = UITheme.dangerButton("Drop");
            dropBtn.setFont(UITheme.smallFont());
            dropBtn.addActionListener(e -> {
                int ok = JOptionPane.showConfirmDialog(this, "Drop " + c.getCourseName() + "?", "Drop Course", JOptionPane.YES_NO_OPTION);
                if (ok == JOptionPane.YES_OPTION) {
                    DataManager.dropEnrollment(student.getId(), c.getCourseId());
                    showCourseCatalog();
                }
            });
            JLabel enrolledBadge = UITheme.label(" Enrolled", UITheme.smallFont(), UITheme.SUCCESS);
            btnRow.add(enrolledBadge);
            btnRow.add(outlineBtn);
            btnRow.add(dropBtn);
        } else {
            JButton enrollBtn = UITheme.accentButton("Enroll");
            enrollBtn.setFont(UITheme.smallFont());
            if (c.isFull()) {
                enrollBtn.setEnabled(false);
                enrollBtn.setText("Full");
            }
            enrollBtn.addActionListener(e -> {
                boolean ok = DataManager.enrollStudent(student.getId(), c.getCourseId());
                if (ok) { JOptionPane.showMessageDialog(this, "Enrolled in " + c.getCourseName() + " successfully!"); showCourseCatalog(); }
                else     JOptionPane.showMessageDialog(this, "Enrollment failed.");
            });
            JLabel spotsLbl = UITheme.label(c.getSpotsLeft() + " spots", UITheme.smallFont(), UITheme.TEXT_MUTED);
            btnRow.add(spotsLbl);
            btnRow.add(outlineBtn);
            btnRow.add(enrollBtn);
        }

        card.add(body, BorderLayout.CENTER);
        card.add(btnRow, BorderLayout.SOUTH);
        return card;
    }

    private void showCourseOutlineDialog(Course c) {
        JDialog dlg = new JDialog(this, "Course Outline - " + c.getCourseId(), true);
        dlg.setSize(620, 560);
        dlg.setLocationRelativeTo(this);
        dlg.setLayout(new BorderLayout(10, 10));
        dlg.getRootPane().setBorder(BorderFactory.createEmptyBorder(16, 20, 16, 20));
        dlg.getContentPane().setBackground(UITheme.CARD_BG);

        // Header
        JPanel hdr = new JPanel(new GridLayout(3, 1, 0, 3)); hdr.setOpaque(false);
        hdr.add(UITheme.label(c.getCourseId() + " - " + c.getCourseName(), UITheme.headingFont(), UITheme.PRIMARY));
        hdr.add(UITheme.label("  " + c.getTeacherName() + "   |   " + c.getCreditHours() + " Credit Hours   |   " + c.getSemester(), UITheme.bodyFont(), UITheme.TEXT_MEDIUM));
        hdr.add(UITheme.label(c.getDescription(), UITheme.smallFont(), UITheme.TEXT_MUTED));
        hdr.setBorder(BorderFactory.createEmptyBorder(0, 0, 10, 0));

        // Outline content
        JTextArea outlineArea = new JTextArea();
        outlineArea.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 13));
        outlineArea.setEditable(false);
        outlineArea.setLineWrap(true);
        outlineArea.setWrapStyleWord(true);
        outlineArea.setBackground(new Color(248, 250, 252));
        outlineArea.setForeground(UITheme.TEXT_DARK);
        outlineArea.setBorder(BorderFactory.createEmptyBorder(12, 14, 12, 14));
        String outline = c.getCourseOutline();
        outlineArea.setText(outline.isEmpty() ? "No detailed outline available for this course." : outline);

        JScrollPane sp = new JScrollPane(outlineArea);
        sp.setBorder(BorderFactory.createLineBorder(UITheme.BORDER_COLOR));

        JPanel btnRow = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        btnRow.setBackground(UITheme.CARD_BG);
        JButton close = UITheme.accentButton("Close");
        close.addActionListener(e -> dlg.dispose());
        btnRow.add(close);

        dlg.add(hdr, BorderLayout.NORTH);
        dlg.add(sp, BorderLayout.CENTER);
        dlg.add(btnRow, BorderLayout.SOUTH);
        dlg.setVisible(true);
    }

    private void showMyCourses() {
        // Switch to "My Courses" tab in catalog
        showCourseCatalog();
    }

    // Quick enroll dialog (flat table)
    private void showEnrollDialog() {
        List<Course> allCourses  = DataManager.loadCourses();
        List<String> enrolled    = DataManager.getEnrolledCourseIds(student.getId());

        JDialog dialog = new JDialog(this, "Enroll in Course", true);
        dialog.setSize(780, 560);
        dialog.setLocationRelativeTo(this);
        dialog.setLayout(new BorderLayout(10, 10));
        dialog.getRootPane().setBorder(BorderFactory.createEmptyBorder(16, 20, 16, 20));
        dialog.getContentPane().setBackground(UITheme.CARD_BG);

        JLabel title = UITheme.label("#  Available Courses", UITheme.headingFont(), UITheme.PRIMARY);
        title.setBorder(BorderFactory.createEmptyBorder(0, 0, 10, 0));

        String[] cols = {"Course ID", "Name", "Teacher", "Sem #", "Schedule", "Credits", "Spots Left"};
        DefaultTableModel model = new DefaultTableModel(cols, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };
        for (Course c : allCourses) {
            if (!enrolled.contains(c.getCourseId()))
                model.addRow(new Object[]{c.getCourseId(), c.getCourseName(), c.getTeacherName(),
                        "Sem " + c.getSemesterNumber(), c.getSchedule(), c.getCreditHours(), c.getSpotsLeft()});
        }
        JTable table = new JTable(model);
        UITheme.styleTable(table);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        JPanel btnRow = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        btnRow.setBackground(UITheme.CARD_BG);
        JButton outline = UITheme.ghostButton("View Outline");
        JButton enroll  = UITheme.accentButton("Enroll");
        JButton cancel  = UITheme.ghostButton("Cancel");

        outline.addActionListener(e -> {
            int row = table.getSelectedRow();
            if (row < 0) { JOptionPane.showMessageDialog(dialog, "Select a course first."); return; }
            Course c = DataManager.findCourseById((String)model.getValueAt(row, 0));
            if (c != null) showCourseOutlineDialog(c);
        });
        enroll.addActionListener(e -> {
            int row = table.getSelectedRow();
            if (row < 0) { JOptionPane.showMessageDialog(dialog, "Select a course first."); return; }
            String cid = (String)model.getValueAt(row, 0);
            boolean ok = DataManager.enrollStudent(student.getId(), cid);
            if (ok) { JOptionPane.showMessageDialog(dialog, "Enrolled successfully!"); dialog.dispose(); showCourseCatalog(); }
            else      JOptionPane.showMessageDialog(dialog, "Enrollment failed (already enrolled or course full).");
        });
        cancel.addActionListener(e -> dialog.dispose());
        btnRow.add(cancel); btnRow.add(outline); btnRow.add(enroll);

        dialog.add(title, BorderLayout.NORTH);
        dialog.add(UITheme.scrollPane(table), BorderLayout.CENTER);
        dialog.add(btnRow, BorderLayout.SOUTH);
        dialog.setVisible(true);
    }

    // ─────────────────────────────────────────────────────────────────
    //  ASSIGNMENTS
    // ─────────────────────────────────────────────────────────────────
    private void showAssignments() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(UITheme.CONTENT_BG);
        JPanel headerBanner = buildSectionHeader("\uD83D\uDCCB  Assignments", "Track your coursework and submissions", new Color(109, 40, 217), new Color(79, 70, 229));

        JPanel content = new JPanel(new BorderLayout(0, 0));
        content.setOpaque(false);
        content.setBorder(BorderFactory.createEmptyBorder(20, 26, 20, 26));

        String[] cols = {"Course ID", "Assignment Title", "Due Date", "Total Marks", "Status", "Marks Obtained"};
        List<Assignment> asnList = DataManager.getAssignmentsForStudent(student.getId());
        DefaultTableModel model = new DefaultTableModel(cols, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };

        if (asnList.isEmpty()) {
            model.addRow(new Object[]{"—", "No assignments posted yet.", "—", "—", "—", "—"});
        } else {
            for (Assignment a : asnList) {
                AssignmentSubmission sub = DataManager.getSubmission(student.getId(), a.getAssignmentId());
                String status = (sub == null) ? "Not Submitted" : sub.getStatus();
                String marks  = (sub == null || sub.getMarksObtained() < 0) ? "—" :
                                sub.getMarksObtained() + " / " + a.getTotalMarks();
                model.addRow(new Object[]{a.getCourseId(), a.getTitle(), a.getDueDate(),
                                          a.getTotalMarks() + " pts", status, marks});
            }
        }

        JTable table = new JTable(model);
        UITheme.styleTable(table);

        // Color-code the Status column
        table.getColumnModel().getColumn(4).setCellRenderer(new DefaultTableCellRenderer() {
            @Override public Component getTableCellRendererComponent(
                    JTable t, Object v, boolean sel, boolean foc, int row, int col) {
                super.getTableCellRendererComponent(t, v, sel, foc, row, col);
                String val = v == null ? "" : v.toString();
                if (!sel) {
                    if (val.equals("Submitted") || val.equals("Graded")) {
                        setForeground(new Color(4, 120, 87));
                    } else if (val.equals("Late")) {
                        setForeground(new Color(180, 80, 0));
                    } else {
                        setForeground(new Color(180, 30, 30));
                    }
                    setBackground(row % 2 == 0 ? UITheme.CARD_BG : UITheme.TABLE_ALT_ROW);
                } else {
                    setForeground(UITheme.TEXT_DARK);
                }
                setFont(UITheme.boldFont());
                setBorder(BorderFactory.createEmptyBorder(0, 14, 0, 14));
                return this;
            }
        });

        // ── Button bar ──────────────────────────────────────────────────────
        JPanel btnBar = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        btnBar.setOpaque(false);
        btnBar.setBorder(BorderFactory.createEmptyBorder(12, 0, 0, 0));

        JButton submitBtn = UITheme.primaryButton("✎  Submit Assignment");
        JButton viewBtn   = UITheme.ghostButton("View My Submission");

        submitBtn.addActionListener(e -> {
            int row = table.getSelectedRow();
            if (row < 0 || asnList.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please select an assignment first.", "No Selection", JOptionPane.WARNING_MESSAGE);
                return;
            }
            Assignment selected = asnList.get(row);
            AssignmentSubmission existing = DataManager.getSubmission(student.getId(), selected.getAssignmentId());
            showSubmitAssignmentDialog(selected, existing);
            showAssignments(); // refresh
        });

        viewBtn.addActionListener(e -> {
            int row = table.getSelectedRow();
            if (row < 0 || asnList.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please select an assignment first.", "No Selection", JOptionPane.WARNING_MESSAGE);
                return;
            }
            Assignment selected = asnList.get(row);
            AssignmentSubmission sub = DataManager.getSubmission(student.getId(), selected.getAssignmentId());
            if (sub == null) {
                JOptionPane.showMessageDialog(this, "You have not submitted this assignment yet.", "No Submission", JOptionPane.INFORMATION_MESSAGE);
            } else {
                showViewSubmissionDialog(selected, sub);
            }
        });

        btnBar.add(viewBtn);
        btnBar.add(submitBtn);

        content.add(UITheme.scrollPane(table), BorderLayout.CENTER);
        content.add(btnBar, BorderLayout.SOUTH);
        panel.add(headerBanner, BorderLayout.NORTH);
        panel.add(content, BorderLayout.CENTER);
        showContent(panel);
    }

    private void showSubmitAssignmentDialog(Assignment asn, AssignmentSubmission existing) {
        boolean isEdit = existing != null;
        JDialog dlg = new JDialog(this, isEdit ? "Update Submission" : "Submit Assignment", true);
        dlg.setSize(580, 480);
        dlg.setLocationRelativeTo(this);
        dlg.getContentPane().setBackground(UITheme.CARD_BG);
        dlg.setLayout(new BorderLayout(0, 0));

        // Header
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(new Color(109, 40, 217));
        header.setBorder(BorderFactory.createEmptyBorder(16, 22, 16, 22));
        JLabel title = new JLabel(asn.getTitle());
        title.setFont(UITheme.font(Font.BOLD, 16));
        title.setForeground(Color.WHITE);
        JLabel sub = new JLabel("Course: " + asn.getCourseId() + "   |   Due: " + asn.getDueDate() + "   |   Marks: " + asn.getTotalMarks());
        sub.setFont(UITheme.font(Font.PLAIN, 12));
        sub.setForeground(new Color(210, 190, 255));
        JPanel hTexts = new JPanel(new GridLayout(2, 1, 0, 4));
        hTexts.setOpaque(false);
        hTexts.add(title);
        hTexts.add(sub);
        header.add(hTexts, BorderLayout.CENTER);

        // Form
        JPanel form = new JPanel();
        form.setLayout(new BoxLayout(form, BoxLayout.Y_AXIS));
        form.setBackground(UITheme.CARD_BG);
        form.setBorder(BorderFactory.createEmptyBorder(18, 22, 10, 22));

        // Description reminder
        JPanel descCard = new JPanel(new BorderLayout());
        descCard.setBackground(new Color(245, 240, 255));
        descCard.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(200, 180, 255)),
            BorderFactory.createEmptyBorder(10, 14, 10, 14)
        ));
        JLabel descTitle = new JLabel("Assignment Details");
        descTitle.setFont(UITheme.font(Font.BOLD, 12));
        descTitle.setForeground(new Color(109, 40, 217));
        JLabel descText = new JLabel("<html><body style='width:460px'>" +
            asn.getDescription().replace("<", "&lt;") + "</body></html>");
        descText.setFont(UITheme.font(Font.PLAIN, 12));
        descText.setForeground(UITheme.TEXT_MEDIUM);
        descCard.add(descTitle, BorderLayout.NORTH);
        descCard.add(descText, BorderLayout.CENTER);
        descCard.setAlignmentX(Component.LEFT_ALIGNMENT);
        descCard.setMaximumSize(new Dimension(Integer.MAX_VALUE, 80));

        form.add(descCard);
        form.add(Box.createVerticalStrut(16));

        // Answer text area
        JLabel ansLabel = new JLabel("Your Answer / Submission");
        ansLabel.setFont(UITheme.font(Font.BOLD, 13));
        ansLabel.setForeground(UITheme.TEXT_DARK);
        ansLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

        JTextArea answerArea = new JTextArea(isEdit ? existing.getSubmittedText() : "", 8, 40);
        answerArea.setFont(UITheme.font(Font.PLAIN, 13));
        answerArea.setLineWrap(true);
        answerArea.setWrapStyleWord(true);
        answerArea.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(200, 180, 255)),
            BorderFactory.createEmptyBorder(8, 10, 8, 10)
        ));
        JScrollPane ansScroll = new JScrollPane(answerArea);
        ansScroll.setAlignmentX(Component.LEFT_ALIGNMENT);
        ansScroll.setMaximumSize(new Dimension(Integer.MAX_VALUE, 180));
        ansScroll.setBorder(null);

        // File name field
        JLabel fileLabel = new JLabel("Attachment Name (optional — e.g. mywork.pdf)");
        fileLabel.setFont(UITheme.font(Font.BOLD, 13));
        fileLabel.setForeground(UITheme.TEXT_DARK);
        fileLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

        JTextField fileField = new JTextField(isEdit && existing.getFileName() != null ? existing.getFileName() : "");
        fileField.setFont(UITheme.font(Font.PLAIN, 13));
        fileField.setMaximumSize(new Dimension(Integer.MAX_VALUE, 36));
        fileField.setAlignmentX(Component.LEFT_ALIGNMENT);
        fileField.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(200, 180, 255)),
            BorderFactory.createEmptyBorder(6, 10, 6, 10)
        ));

        form.add(ansLabel);
        form.add(Box.createVerticalStrut(6));
        form.add(ansScroll);
        form.add(Box.createVerticalStrut(14));
        form.add(fileLabel);
        form.add(Box.createVerticalStrut(6));
        form.add(fileField);

        // Buttons
        JPanel btnRow = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        btnRow.setBackground(UITheme.CARD_BG);
        btnRow.setBorder(BorderFactory.createEmptyBorder(10, 22, 16, 22));

        JButton cancelBtn = UITheme.ghostButton("Cancel");
        JButton saveBtn   = UITheme.primaryButton(isEdit ? "Update Submission" : "Submit");

        cancelBtn.addActionListener(e -> dlg.dispose());

        saveBtn.addActionListener(e -> {
            String text = answerArea.getText().trim();
            if (text.isEmpty()) {
                JOptionPane.showMessageDialog(dlg, "Please write your answer before submitting.", "Empty Submission", JOptionPane.WARNING_MESSAGE);
                return;
            }
            String today = new java.text.SimpleDateFormat("yyyy-MM-dd").format(new java.util.Date());
            String status = "Submitted";
            // Simple late check: compare today vs due date lexicographically (works for yyyy-MM-dd)
            try {
                if (today.compareTo(asn.getDueDate()) > 0) status = "Late";
            } catch (Exception ignored) {}

            if (isEdit) {
                existing.setSubmittedText(text);
                existing.setFileName(fileField.getText().trim());
                existing.setStatus(status);
                DataManager.updateSubmission(existing);
            } else {
                AssignmentSubmission newSub = new AssignmentSubmission(
                    DataManager.generateSubmissionId(),
                    asn.getAssignmentId(), student.getId(), student.getName(),
                    asn.getCourseId(), text, fileField.getText().trim(),
                    today, status, -1
                );
                DataManager.addSubmission(newSub);
            }
            JOptionPane.showMessageDialog(dlg,
                isEdit ? "Submission updated successfully!" : "Assignment submitted successfully!",
                "Success", JOptionPane.INFORMATION_MESSAGE);
            dlg.dispose();
        });

        btnRow.add(cancelBtn);
        btnRow.add(saveBtn);

        JScrollPane formScroll = new JScrollPane(form);
        formScroll.setBorder(null);
        formScroll.getViewport().setBackground(UITheme.CARD_BG);

        dlg.add(header, BorderLayout.NORTH);
        dlg.add(formScroll, BorderLayout.CENTER);
        dlg.add(btnRow, BorderLayout.SOUTH);
        dlg.setVisible(true);
    }

    private void showViewSubmissionDialog(Assignment asn, AssignmentSubmission sub) {
        JDialog dlg = new JDialog(this, "My Submission — " + asn.getTitle(), true);
        dlg.setSize(520, 400);
        dlg.setLocationRelativeTo(this);
        dlg.getContentPane().setBackground(UITheme.CARD_BG);
        dlg.setLayout(new BorderLayout());

        // Header
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(new Color(109, 40, 217));
        header.setBorder(BorderFactory.createEmptyBorder(14, 22, 14, 22));
        JLabel title = new JLabel(asn.getTitle());
        title.setFont(UITheme.font(Font.BOLD, 16));
        title.setForeground(Color.WHITE);

        Color statusColor = sub.getStatus().equals("Graded") ? new Color(160, 255, 200) :
                            sub.getStatus().equals("Late")   ? new Color(255, 220, 130) :
                                                               new Color(180, 220, 255);
        JLabel statusLbl = new JLabel("Status: " + sub.getStatus() +
            (sub.getMarksObtained() >= 0 ? "   |   Marks: " + sub.getMarksObtained() + " / " + asn.getTotalMarks() : ""));
        statusLbl.setFont(UITheme.font(Font.BOLD, 12));
        statusLbl.setForeground(statusColor);
        JPanel hTexts = new JPanel(new GridLayout(2, 1, 0, 4));
        hTexts.setOpaque(false);
        hTexts.add(title);
        hTexts.add(statusLbl);
        header.add(hTexts);

        // Content
        JPanel body = new JPanel();
        body.setLayout(new BoxLayout(body, BoxLayout.Y_AXIS));
        body.setBackground(UITheme.CARD_BG);
        body.setBorder(BorderFactory.createEmptyBorder(18, 22, 18, 22));

        JLabel submittedLbl = new JLabel("Submitted on: " + sub.getSubmittedOn() +
            (sub.getFileName() != null && !sub.getFileName().isEmpty() ? "   |   Attachment: " + sub.getFileName() : ""));
        submittedLbl.setFont(UITheme.font(Font.PLAIN, 12));
        submittedLbl.setForeground(UITheme.TEXT_MUTED);
        submittedLbl.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel ansLbl = new JLabel("Your Answer:");
        ansLbl.setFont(UITheme.font(Font.BOLD, 13));
        ansLbl.setForeground(UITheme.TEXT_DARK);
        ansLbl.setAlignmentX(Component.LEFT_ALIGNMENT);

        JTextArea ansArea = new JTextArea(sub.getSubmittedText());
        ansArea.setEditable(false);
        ansArea.setLineWrap(true);
        ansArea.setWrapStyleWord(true);
        ansArea.setFont(UITheme.font(Font.PLAIN, 13));
        ansArea.setBackground(new Color(248, 246, 255));
        ansArea.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(200, 180, 255)),
            BorderFactory.createEmptyBorder(10, 12, 10, 12)
        ));
        JScrollPane ansScroll = new JScrollPane(ansArea);
        ansScroll.setAlignmentX(Component.LEFT_ALIGNMENT);
        ansScroll.setMaximumSize(new Dimension(Integer.MAX_VALUE, 200));
        ansScroll.setBorder(null);

        body.add(submittedLbl);
        body.add(Box.createVerticalStrut(14));
        body.add(ansLbl);
        body.add(Box.createVerticalStrut(6));
        body.add(ansScroll);

        JPanel btnRow = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        btnRow.setBackground(UITheme.CARD_BG);
        JButton closeBtn = UITheme.ghostButton("Close");
        closeBtn.addActionListener(e -> dlg.dispose());
        btnRow.add(closeBtn);

        JScrollPane bodyScroll = new JScrollPane(body);
        bodyScroll.setBorder(null);
        bodyScroll.getViewport().setBackground(UITheme.CARD_BG);

        dlg.add(header, BorderLayout.NORTH);
        dlg.add(bodyScroll, BorderLayout.CENTER);
        dlg.add(btnRow, BorderLayout.SOUTH);
        dlg.setVisible(true);
    }

    // ─────────────────────────────────────────────────────────────────
    //  RESULTS (Semester-wise results with CGPA update)
    // ─────────────────────────────────────────────────────────────────
    private void showResults() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(UITheme.CONTENT_BG);

        JPanel headerBanner = buildSectionHeader("\uD83C\uDFC6  Results & CGPA", "Your semester-wise academic performance",
                new Color(2, 132, 199), new Color(14, 165, 233));

        List<Grade> allGrades = DataManager.getGradesForStudent(student.getId());
        double cgpa = DataManager.calculateCGPA(student.getId());

        JPanel content = new JPanel(new BorderLayout(0, 16));
        content.setOpaque(false);
        content.setBorder(BorderFactory.createEmptyBorder(20, 26, 20, 26));

        // Top summary cards
        int totalCrCompleted = 0;
        for (Grade g : allGrades) {
            Course c = DataManager.findCourseById(g.getCourseId());
            if (c != null) totalCrCompleted += c.getCreditHours();
        }
        JPanel summary = new JPanel(new GridLayout(1, 4, 16, 0));
        summary.setOpaque(false);
        summary.add(UITheme.statCard(String.format("%.2f", cgpa), "Cumulative CGPA", UITheme.ACCENT, "*"));
        summary.add(UITheme.statCard(String.valueOf(allGrades.size()), "Courses Completed", UITheme.INFO, ""));
        summary.add(UITheme.statCard(String.valueOf(totalCrCompleted), "Total Credit Hours", UITheme.SUCCESS, ""));
        summary.add(UITheme.statCard(student.getSemester(), "Current Semester", UITheme.GOLD, "-"));

        // Build tabbed semester results
        JTabbedPane resultTabs = new JTabbedPane();
        resultTabs.setFont(UITheme.boldFont());

        // All Results tab
        resultTabs.addTab("All Results", buildResultTable(allGrades));

        // Per-semester tabs
        Set<String> semesterNames = new LinkedHashSet<>();
        for (Grade g : allGrades) semesterNames.add(g.getSemester());
        for (String sem : semesterNames) {
            List<Grade> semGrades = DataManager.getGradesForStudentBySemester(student.getId(), sem);
            double semGPA = DataManager.calculateSemesterGPA(student.getId(), sem);
            JPanel semPanel = new JPanel(new BorderLayout(0, 8));
            semPanel.setOpaque(false);

            // Semester GPA strip
            JPanel semInfo = new JPanel(new FlowLayout(FlowLayout.LEFT, 16, 6));
            semInfo.setOpaque(false);
            semInfo.add(UITheme.label(sem, UITheme.boldFont(), UITheme.TEXT_DARK));
            semInfo.add(UITheme.label(" | ", UITheme.bodyFont(), UITheme.TEXT_MUTED));
            semInfo.add(UITheme.label("Semester GPA: " + String.format("%.2f", semGPA), UITheme.boldFont(), UITheme.TEAL));
            semInfo.add(UITheme.label(" | ", UITheme.bodyFont(), UITheme.TEXT_MUTED));
            semInfo.add(UITheme.label("Courses: " + semGrades.size(), UITheme.bodyFont(), UITheme.TEXT_MEDIUM));
            semPanel.add(semInfo, BorderLayout.NORTH);
            semPanel.add(buildResultTable(semGrades), BorderLayout.CENTER);
            resultTabs.addTab(sem, semPanel);
        }

        content.add(summary, BorderLayout.NORTH);
        content.add(resultTabs, BorderLayout.CENTER);
        panel.add(headerBanner, BorderLayout.NORTH);
        panel.add(content, BorderLayout.CENTER);
        showContent(panel);
    }

    private JScrollPane buildResultTable(List<Grade> grades) {
        String[] cols = {"Course ID", "Course Name", "Assignment (20%)", "Midterm (30%)", "Final (50%)", "Total", "Grade", "GPA Pts", "Semester"};
        DefaultTableModel model = new DefaultTableModel(cols, 0) { public boolean isCellEditable(int r, int c) { return false; } };
        for (Grade g : grades) {
            Course c = DataManager.findCourseById(g.getCourseId());
            int cr = (c != null) ? c.getCreditHours() : 3;
            model.addRow(new Object[]{
                g.getCourseId(), g.getCourseName(),
                g.getAssignment1() + "/100", g.getMidterm() + "/100", g.getFinalProject() + "/100",
                String.format("%.1f", g.getTotal()), g.getLetterGrade(),
                String.format("%.1f", g.getGpaPoints()) + " (x" + cr + "cr)",
                g.getSemester()
            });
        }
        JTable table = new JTable(model);
        UITheme.styleTable(table);
        // Color-code grade column
        table.getColumnModel().getColumn(6).setCellRenderer(new DefaultTableCellRenderer() {
            @Override public Component getTableCellRendererComponent(JTable t, Object v, boolean sel, boolean foc, int row, int col) {
                super.getTableCellRendererComponent(t, v, sel, foc, row, col);
                String grade = v != null ? v.toString() : "";
                if (!sel) {
                    if (grade.startsWith("A"))      { setBackground(new Color(220, 252, 231)); setForeground(new Color(22, 101, 52)); }
                    else if (grade.startsWith("B")) { setBackground(new Color(219, 234, 254)); setForeground(new Color(29, 78, 216)); }
                    else if (grade.startsWith("C")) { setBackground(new Color(254, 249, 195)); setForeground(new Color(133, 77, 14)); }
                    else if (grade.equals("F"))     { setBackground(new Color(254, 226, 226)); setForeground(new Color(153, 27, 27)); }
                    else                            { setBackground(Color.WHITE); setForeground(UITheme.TEXT_DARK); }
                }
                setHorizontalAlignment(CENTER);
                setBorder(BorderFactory.createEmptyBorder(0, 10, 0, 10));
                return this;
            }
        });
        return UITheme.scrollPane(table);
    }

    // ─────────────────────────────────────────────────────────────────
    //  CALENDAR
    // ─────────────────────────────────────────────────────────────────
    private void showCalendar() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(UITheme.CONTENT_BG);
        JPanel headerBanner = buildSectionHeader("\uD83D\uDCC5  Academic Calendar", "Important dates and events", UITheme.PRIMARY_DARK, UITheme.PRIMARY);
        JPanel content = new JPanel(new BorderLayout(0,0));
        content.setOpaque(false);
        content.setBorder(BorderFactory.createEmptyBorder(20, 26, 20, 26));

        String[] cols = {"Event", "Date", "Description"};
        Object[][] data = {
            {"Semester I Start",         "01 Sep 2024",  "Academic year begins"},
            {"Add/Drop Deadline",         "07 Sep 2024",  "Last day to add or drop courses"},
            {"Mid-Term Exams",            "14-18 Oct 2024","Mid-term examinations week"},
            {"Semester I End",            "20 Dec 2024",  "Semester I classes end"},
            {"Final Exams (Sem I)",       "23 Dec - 04 Jan","Final examination period"},
            {"Result Declaration (Sem I)","15 Jan 2025",  "Semester I results announced"},
            {"Semester II Start",         "01 Feb 2025",  "Semester II begins"},
            {"Add/Drop Deadline (Sem II)","07 Feb 2025",  "Last day to modify Sem II enrollment"},
            {"Mid-Term Exams (Sem II)",   "17-21 Mar 2025","Semester II mid-terms"},
            {"Semester II End",           "30 May 2025",  "Semester II classes end"},
            {"Final Exams (Sem II)",      "02-13 Jun 2025","Final examinations"},
        };
        JTable table = new JTable(data, cols) { public boolean isCellEditable(int r, int c) { return false; } };
        UITheme.styleTable(table);
        content.add(UITheme.scrollPane(table), BorderLayout.CENTER);
        panel.add(headerBanner, BorderLayout.NORTH);
        panel.add(content, BorderLayout.CENTER);
        showContent(panel);
    }

    // ─────────────────────────────────────────────────────────────────
    //  NOTICES
    // ─────────────────────────────────────────────────────────────────
    private void showNotices() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(UITheme.CONTENT_BG);
        JPanel headerBanner = buildSectionHeader("\uD83D\uDCE2  Notices & Announcements", "Important information from admin and faculty", new Color(109,40,217), new Color(79,70,229));
        JPanel content = new JPanel(new BorderLayout(0,0));
        content.setOpaque(false);
        content.setBorder(BorderFactory.createEmptyBorder(20, 26, 20, 26));

        String[] cols = {"Title", "Author", "Course", "Priority", "Date"};
        DefaultTableModel model = new DefaultTableModel(cols, 0) { public boolean isCellEditable(int r, int c) { return false; } };
        for (Announcement a : DataManager.loadAnnouncements())
            model.addRow(new Object[]{a.getTitle(), a.getAuthorName(), a.getCourseId(), a.getPriority(), a.getDateTime()});

        JTable table = new JTable(model);
        UITheme.styleTable(table);
        table.getColumnModel().getColumn(3).setCellRenderer(new DefaultTableCellRenderer() {
            @Override public Component getTableCellRendererComponent(JTable t, Object v, boolean sel, boolean foc, int row, int col) {
                super.getTableCellRendererComponent(t, v, sel, foc, row, col);
                String p = v != null ? v.toString() : "";
                if (!sel) {
                    if (p.equals("HIGH"))        { setBackground(new Color(254,226,226)); setForeground(new Color(153,27,27)); }
                    else if (p.equals("MEDIUM")) { setBackground(new Color(254,243,199)); setForeground(new Color(120,53,15)); }
                    else                         { setBackground(new Color(220,252,231)); setForeground(new Color(22,101,52)); }
                }
                setBorder(BorderFactory.createEmptyBorder(0,10,0,10));
                return this;
            }
        });
        // Show content on row click
        JTextArea contentArea = new JTextArea(3, 40);
        contentArea.setEditable(false); contentArea.setLineWrap(true); contentArea.setWrapStyleWord(true);
        contentArea.setFont(UITheme.bodyFont()); contentArea.setBackground(new Color(248,250,252));
        contentArea.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(UITheme.BORDER_COLOR),
            BorderFactory.createEmptyBorder(8,10,8,10)));
        contentArea.setText("Click a notice to read its content.");

        table.getSelectionModel().addListSelectionListener(e -> {
            int row = table.getSelectedRow();
            if (row < 0) return;
            String title = (String)model.getValueAt(row, 0);
            for (Announcement a : DataManager.loadAnnouncements()) {
                if (a.getTitle().equals(title)) { contentArea.setText(a.getContent()); break; }
            }
        });

        content.add(UITheme.scrollPane(table), BorderLayout.CENTER);
        content.add(contentArea, BorderLayout.SOUTH);
        panel.add(headerBanner, BorderLayout.NORTH);
        panel.add(content, BorderLayout.CENTER);
        showContent(panel);
    }

    // ─────────────────────────────────────────────────────────────────
    //  FEE CHALLAN
    // ─────────────────────────────────────────────────────────────────
    private void showFeeChallan() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(UITheme.CONTENT_BG);
        panel.add(new FeeChallanPanel(FeeChallanPanel.Mode.STUDENT, currentUser, this), BorderLayout.CENTER);
        showContent(panel);
    }

    // ─────────────────────────────────────────────────────────────────
    //  PROFILE
    // ─────────────────────────────────────────────────────────────────
    private void showProfile() {
        JPanel panel = new JPanel(new BorderLayout(0,0));
        panel.setBackground(UITheme.CONTENT_BG);

        JPanel headerBanner = new JPanel(new BorderLayout()) {
            @Override protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g.create();
                GradientPaint gp = new GradientPaint(0, 0, new Color(5,95,150), getWidth(), 0, new Color(13,148,136));
                g2.setPaint(gp); g2.fillRect(0,0,getWidth(),getHeight()); g2.dispose();
            }
        };
        headerBanner.setPreferredSize(new Dimension(0, 80));
        headerBanner.setBorder(BorderFactory.createEmptyBorder(16,28,16,28));
        JPanel hTexts = new JPanel(new GridLayout(2,1,0,3)); hTexts.setOpaque(false);
        hTexts.add(UITheme.label("o  My Profile", UITheme.font(Font.BOLD, 22), Color.WHITE));
        hTexts.add(UITheme.label("Manage your account information", UITheme.font(Font.PLAIN, 12), new Color(200,235,230)));
        headerBanner.add(hTexts, BorderLayout.WEST);

        JPanel content = new JPanel(new BorderLayout(0,20));
        content.setOpaque(false);
        content.setBorder(BorderFactory.createEmptyBorder(24, 50, 24, 50));

        Student fresh = DataManager.findStudentById(student.getId());
        if (fresh != null) student = fresh;

        JPanel twoCol = new JPanel(new GridBagLayout()); twoCol.setOpaque(false);
        GridBagConstraints tc = new GridBagConstraints();
        tc.anchor = GridBagConstraints.NORTH; tc.fill = GridBagConstraints.BOTH;
        tc.insets = new Insets(0,0,0,16);

        tc.gridx = 0; tc.gridy = 0; tc.weightx = 0.28;
        twoCol.add(buildProfilePicturePanel(() -> DataManager.updateStudent(student)), tc);

        tc.gridx = 1; tc.weightx = 0.72; tc.insets = new Insets(0,0,0,0);
        JPanel formCard = new JPanel(new GridBagLayout()) {
            @Override protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(new Color(0,0,0,6)); g2.fillRoundRect(2,2,getWidth()-2,getHeight()-2,14,14);
                g2.setColor(Color.WHITE);        g2.fillRoundRect(0,0,getWidth()-2,getHeight()-2,14,14);
                g2.dispose();
            }
        };
        formCard.setOpaque(false);
        formCard.setBorder(BorderFactory.createEmptyBorder(28,32,28,32));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10,10,10,10); gbc.anchor = GridBagConstraints.WEST; gbc.fill = GridBagConstraints.HORIZONTAL;

        String[][] fields = {
            {"Full Name", student.getName()}, {"Student ID", student.getId()},
            {"Email", student.getEmail()},    {"Phone", student.getPhone()},
            {"Major", student.getMajor()},    {"Year", String.valueOf(student.getYear())},
            {"Semester", student.getSemester()}
        };
        Map<String, JTextField> fm = new LinkedHashMap<>();
        for (int i = 0; i < fields.length; i++) {
            gbc.gridx = 0; gbc.gridy = i; gbc.weightx = 0;
            formCard.add(UITheme.label(fields[i][0] + ":", UITheme.boldFont(), UITheme.TEXT_DARK), gbc);
            gbc.gridx = 1; gbc.weightx = 1;
            JTextField tf = UITheme.styledField(); tf.setText(fields[i][1]);
            boolean editable = !fields[i][0].equals("Student ID");
            tf.setEditable(editable);
            if (!editable) { tf.setBackground(UITheme.CONTENT_BG); tf.setForeground(UITheme.TEXT_MUTED); }
            fm.put(fields[i][0], tf);
            formCard.add(tf, gbc);
        }

        gbc.gridx = 0; gbc.gridy = fields.length; gbc.weightx = 0;
        formCard.add(UITheme.label("Password:", UITheme.boldFont(), UITheme.TEXT_DARK), gbc);
        gbc.gridx = 1; gbc.weightx = 1;
        JButton changePwdBtn = UITheme.ghostButton("Change Password");
        changePwdBtn.addActionListener(e -> showChangePasswordDialog());
        formCard.add(changePwdBtn, gbc);
        twoCol.add(formCard, tc);

        JPanel btnRow = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0)); btnRow.setOpaque(false);
        JButton save = UITheme.primaryButton("Save Changes");
        save.addActionListener(e -> {
            student.setName(fm.get("Full Name").getText().trim());
            student.setEmail(fm.get("Email").getText().trim());
            student.setPhone(fm.get("Phone").getText().trim());
            student.setMajor(fm.get("Major").getText().trim());
            try { student.setYear(Integer.parseInt(fm.get("Year").getText().trim())); } catch (Exception ex) {}
            student.setSemester(fm.get("Semester").getText().trim());
            DataManager.updateStudent(student);
            userNameLbl.setText(student.getName().split(" ")[0]);
            JOptionPane.showMessageDialog(this, "Profile updated successfully!");
        });
        btnRow.add(save);
        content.add(twoCol, BorderLayout.CENTER);
        content.add(btnRow, BorderLayout.SOUTH);

        JScrollPane profileScroll = new JScrollPane(content);
        profileScroll.setBorder(null); profileScroll.setOpaque(false);
        profileScroll.getViewport().setOpaque(false);
        profileScroll.getViewport().setBackground(UITheme.CONTENT_BG);
        profileScroll.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        profileScroll.getVerticalScrollBar().setUnitIncrement(16);

        panel.add(headerBanner, BorderLayout.NORTH);
        panel.add(profileScroll, BorderLayout.CENTER);
        showContent(panel);
    }

    private void showChangePasswordDialog() {
        JDialog dlg = new JDialog(this, "Change Password", true);
        dlg.setSize(400, 280); dlg.setLocationRelativeTo(this);
        dlg.setLayout(new BorderLayout(10,10));
        dlg.getRootPane().setBorder(BorderFactory.createEmptyBorder(20,24,20,24));
        dlg.getContentPane().setBackground(UITheme.CARD_BG);

        JPasswordField currentF = UITheme.styledPasswordField();
        JPasswordField newF     = UITheme.styledPasswordField();
        JPasswordField confirmF = UITheme.styledPasswordField();

        JPanel form = new JPanel(new GridLayout(3, 2, 10, 14)); form.setBackground(UITheme.CARD_BG);
        form.add(UITheme.label("Current Password:", UITheme.boldFont(), UITheme.TEXT_DARK)); form.add(currentF);
        form.add(UITheme.label("New Password:",     UITheme.boldFont(), UITheme.TEXT_DARK)); form.add(newF);
        form.add(UITheme.label("Confirm New:",      UITheme.boldFont(), UITheme.TEXT_DARK)); form.add(confirmF);

        JPanel btnRow = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0)); btnRow.setBackground(UITheme.CARD_BG);
        JButton change = UITheme.primaryButton("Change Password");
        JButton cancel = UITheme.ghostButton("Cancel");
        change.addActionListener(e -> {
            String curr    = new String(currentF.getPassword());
            String newPwd  = new String(newF.getPassword());
            String confirm = new String(confirmF.getPassword());
            if (!newPwd.equals(confirm))    { JOptionPane.showMessageDialog(dlg, "New passwords do not match."); return; }
            if (newPwd.length() < 6)         { JOptionPane.showMessageDialog(dlg, "Password must be at least 6 characters."); return; }
            Student s = DataManager.findStudentById(student.getId());
            if (s == null || !s.getPassword().equals(curr)) { JOptionPane.showMessageDialog(dlg, "Current password is incorrect."); return; }
            s.setPassword(newPwd);
            DataManager.updateStudent(s);
            student = s;
            JOptionPane.showMessageDialog(dlg, "Password changed successfully!");
            dlg.dispose();
        });
        cancel.addActionListener(e -> dlg.dispose());
        btnRow.add(cancel); btnRow.add(change);

        JLabel title = UITheme.label("Change Password", UITheme.headingFont(), UITheme.PRIMARY);
        title.setBorder(BorderFactory.createEmptyBorder(0,0,8,0));
        dlg.add(title, BorderLayout.NORTH);
        dlg.add(form,  BorderLayout.CENTER);
        dlg.add(btnRow, BorderLayout.SOUTH);
        dlg.setVisible(true);
    }

    // ─────────────────────────────────────────────────────────────────
    //  HELPERS
    // ─────────────────────────────────────────────────────────────────
    private JPanel buildRoundCard() {
        JPanel card = new JPanel(new BorderLayout(0, 10)) {
            @Override protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(new Color(0,0,0,7)); g2.fillRoundRect(2,2,getWidth()-2,getHeight()-2,14,14);
                g2.setColor(Color.WHITE);        g2.fillRoundRect(0,0,getWidth()-2,getHeight()-2,14,14);
                g2.dispose();
            }
        };
        card.setOpaque(false);
        card.setBorder(BorderFactory.createEmptyBorder(16,16,16,16));
        return card;
    }
    private JPanel buildSectionHeader(String title, String subtitle, Color c1, Color c2) {
        // Extract emoji/symbol from title (first char or multi-codepoint emoji before spaces)
        String sym = "";
        String dispTitle = title;
        int spIdx = title.indexOf("  ");
        if (spIdx > 0) { sym = title.substring(0, spIdx).trim(); dispTitle = title.substring(spIdx).trim(); }

        final String finalSym = sym;
        final String finalTitle = dispTitle;

        JPanel banner = new JPanel(new BorderLayout()) {
            @Override protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                GradientPaint gp = new GradientPaint(0, 0, c1, getWidth(), getHeight(), c2);
                g2.setPaint(gp); g2.fillRect(0, 0, getWidth(), getHeight());
                g2.setColor(new Color(255,255,255,18));
                g2.fillOval(getWidth()-160,-40,200,200);
                g2.setColor(new Color(255,255,255,10));
                g2.fillOval(getWidth()-60,10,100,100);
                g2.dispose();
            }
        };
        banner.setPreferredSize(new Dimension(0, 84));
        banner.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 0));

        // Icon circle
        JPanel iconCircle = new JPanel() {
            @Override protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(new Color(255, 255, 255, 45));
                g2.fillOval(6, 6, 52, 52);
                if (!finalSym.isEmpty()) {
                    g2.setColor(Color.WHITE);
                    Font sf = UITheme.getSymbolFontPublic(finalSym, 22);
                    g2.setFont(sf);
                    FontMetrics fm = g2.getFontMetrics();
                    g2.drawString(finalSym, (64 - fm.stringWidth(finalSym)) / 2,
                            (64 - fm.getHeight()) / 2 + fm.getAscent());
                }
                g2.dispose();
            }
            @Override public Dimension getPreferredSize() { return new Dimension(64, 84); }
        };
        iconCircle.setOpaque(false);

        JPanel texts = new JPanel(new GridLayout(2,1,0,4)); texts.setOpaque(false);
        texts.setBorder(BorderFactory.createEmptyBorder(18, 16, 18, 28));
        texts.add(UITheme.label(finalTitle, UITheme.font(Font.BOLD, 22), Color.WHITE));
        texts.add(UITheme.label(subtitle, UITheme.font(Font.PLAIN, 12), new Color(210, 240, 255)));

        JPanel left = new JPanel(new BorderLayout()); left.setOpaque(false);
        left.add(iconCircle, BorderLayout.WEST);
        left.add(texts, BorderLayout.CENTER);
        banner.add(left, BorderLayout.WEST);
        return banner;
    }
}
