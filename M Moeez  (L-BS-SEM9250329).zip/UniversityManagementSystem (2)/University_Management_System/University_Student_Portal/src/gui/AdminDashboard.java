package gui;

import models.*;
import utils.DataManager;
import utils.UITheme;

import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;
import java.util.*;
import java.util.List;
import java.util.stream.*;

public class AdminDashboard extends BaseDashboard {

    private Admin admin;

    public AdminDashboard(Admin admin) {
        super(admin, "Admin Portal - " + admin.getName());
        this.admin = admin;
        showDefaultPanel();
    }

    @Override
    protected void addNavigationItems() {
        addNavButton("home", "Dashboard",     this::showDashboard);
        addNavButton("students",    "Students",      this::showStudents);
        addNavButton("teachers",    "Teachers",    this::showTeachers);
        addNavButton("courses", "Courses",       this::showCourses);
        addNavButton("grades", "Grades",        this::showGrades);
        addNavButton("announcements", "Announcements", this::showAnnouncements);
        addNavButton("admins", "Admins",        this::showAdmins);
        addNavButton("fee", "Fee Challans",  this::showFeeChallan);
        addNavButton("applications", "Applications", this::showApplications);
        addNavButton("profile", "Profile",       this::showProfile);
    }

    @Override
    protected void showDefaultPanel() { showDashboard(); }

    
    
    
    private void showDashboard() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(UITheme.CONTENT_BG);

        
        JPanel header = UITheme.dashboardHeader(
            "Admin Control Panel",
            "-  System Overview  -  " + admin.getAdminLevel() + " Access  -  Welcome back, " + admin.getName().split(" ")[0] + "!",
            UITheme.PRIMARY_DARK, UITheme.SECONDARY
        );
        
        JPanel headerWithDeco = new JPanel(new BorderLayout()) {
            @Override protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                GradientPaint gp = new GradientPaint(0, 0, UITheme.PRIMARY_DARK, getWidth(), 0, UITheme.SECONDARY);
                g2.setPaint(gp);
                g2.fillRect(0, 0, getWidth(), getHeight());
                
                g2.setColor(new Color(255, 255, 255, 10));
                g2.fillOval(getWidth() - 180, -50, 200, 200);
                g2.fillOval(getWidth() - 80, 10, 100, 100);
                g2.setColor(new Color(245, 158, 11, 15));
                g2.fillOval(-40, -30, 140, 140);
                
                g2.setColor(new Color(255, 255, 255, 7));
                g2.fillRoundRect(getWidth()-240, 14, 45, 60, 4, 4);
                g2.fillRoundRect(getWidth()-188, 10, 45, 60, 4, 4);
                g2.fillRect(getWidth()-300, 52, 55, 8);
                g2.fillRoundRect(getWidth()-290, 38, 35, 18, 4, 4);
                g2.dispose();
            }
        };
        headerWithDeco.setPreferredSize(new Dimension(0, 90));
        JPanel hText = new JPanel(new GridLayout(2, 1, 0, 4));
        hText.setOpaque(false);
        hText.setBorder(BorderFactory.createEmptyBorder(18, 30, 18, 30));
        hText.add(UITheme.label("Admin Control Panel", UITheme.font(Font.BOLD, 24), Color.WHITE));
        hText.add(UITheme.label("-  System Overview  -  " + admin.getAdminLevel() + " Access  -  Welcome back, " + admin.getName().split(" ")[0] + "!", UITheme.font(Font.PLAIN, 13), new Color(200, 220, 255)));
        headerWithDeco.add(hText, BorderLayout.WEST);

        
        int students      = DataManager.loadStudents().size();
        int teachers      = DataManager.loadTeachers().size();
        int courses       = DataManager.loadCourses().size();
        int announcements = DataManager.loadAnnouncements().size();

        JPanel statsRow = new JPanel(new GridLayout(1, 4, 16, 0));
        statsRow.setOpaque(false);
        statsRow.setBorder(BorderFactory.createEmptyBorder(20, 26, 16, 26));
        statsRow.add(UITheme.statCard(String.valueOf(students),      "Total Students",  UITheme.TEAL,    ""));
        statsRow.add(UITheme.statCard(String.valueOf(teachers),      "Faculty Staff",   UITheme.SECONDARY, ""));
        statsRow.add(UITheme.statCard(String.valueOf(courses),       "Active Courses",  UITheme.SUCCESS, "#"));
        statsRow.add(UITheme.statCard(String.valueOf(announcements), "Announcements",   UITheme.ACCENT,  "*"));

        
        JPanel quickSection = new JPanel(new BorderLayout(0, 12));
        quickSection.setOpaque(false);
        quickSection.setBorder(BorderFactory.createEmptyBorder(4, 26, 16, 26));
        quickSection.add(UITheme.sectionHeader("Quick Actions"), BorderLayout.NORTH);

        JPanel quickGrid = new JPanel(new GridLayout(2, 4, 14, 14));
        quickGrid.setOpaque(false);
        String[]   qIcons   = {"\uD83D\uDC64", "\uD83D\uDC68\u200D\uD83C\uDFEB", "\uD83D\uDCDA", "\uD83D\uDCE2", "\uD83D\uDC65", "\uD83D\uDCCB", "\uD83D\uDCCA", "\u2B50"};
        String[]   qLabels  = {"Add Student", "Add Teacher", "Add Course", "Announcement",
                               "All Students", "All Teachers", "All Courses", "View Grades"};
        Color[]    qColors  = {UITheme.TEAL, UITheme.SECONDARY, UITheme.SUCCESS, UITheme.ACCENT,
                               UITheme.TEAL, UITheme.SECONDARY, UITheme.SUCCESS, UITheme.PURPLE};
        Runnable[] qActions = {
            this::showAddStudentDialog, this::showAddTeacherDialog,
            this::showAddCourseDialog,  this::showAddAnnDialog,
            this::showStudents,         this::showTeachers,
            this::showCourses,          this::showGrades
        };
        for (int i = 0; i < qLabels.length; i++) {
            JButton btn = UITheme.quickButton(qIcons[i], qLabels[i], qColors[i]);
            Runnable r = qActions[i];
            btn.addActionListener(e -> r.run());
            quickGrid.add(btn);
        }
        quickSection.add(quickGrid, BorderLayout.CENTER);

        
        JPanel tableSection = new JPanel(new BorderLayout(0, 10));
        tableSection.setOpaque(false);
        tableSection.setBorder(BorderFactory.createEmptyBorder(4, 26, 26, 26));
        tableSection.add(UITheme.sectionHeader("Recent Students"), BorderLayout.NORTH);

        String[] cols = {"ID", "Name", "Email", "Major", "Year", "Semester"};
        DefaultTableModel model = new DefaultTableModel(cols, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };
        List<Student> stuList = DataManager.loadStudents();
        int cnt = 0;
        for (int i = stuList.size() - 1; i >= 0 && cnt < 6; i--, cnt++) {
            Student stu = stuList.get(i);
            model.addRow(new Object[]{stu.getId(), stu.getName(), stu.getEmail(),
                    stu.getMajor(), stu.getYear(), stu.getSemester()});
        }
        JTable table = new JTable(model);
        UITheme.styleTable(table);
        JScrollPane sp = UITheme.scrollPane(table);
        sp.setPreferredSize(new Dimension(0, 220));
        tableSection.add(sp, BorderLayout.CENTER);

        JPanel main = new JPanel();
        main.setLayout(new BoxLayout(main, BoxLayout.Y_AXIS));
        main.setOpaque(false);
        main.add(statsRow);
        main.add(quickSection);
        main.add(tableSection);

        JScrollPane scrollMain = new JScrollPane(main);
        scrollMain.setBorder(null);
        scrollMain.getViewport().setBackground(UITheme.CONTENT_BG);

        panel.add(headerWithDeco, BorderLayout.NORTH);
        panel.add(scrollMain, BorderLayout.CENTER);
        showContent(panel);
    }

    
    
    
    private void showStudents() {
        String[] cols = {"ID", "Name", "Email", "Phone", "Major", "Year", "Semester"};
        JPanel panel = buildManagementPanel("Students Management", "\uD83D\uDC65  Manage all enrolled students", cols);
        JTable table = extractTable(panel);
        DefaultTableModel model = (DefaultTableModel) table.getModel();

        for (Student s : DataManager.loadStudents())
            model.addRow(new Object[]{s.getId(), s.getName(), s.getEmail(),
                    s.getPhone(), s.getMajor(), s.getYear(), s.getSemester()});

        JPanel btnRow = extractBtnRow(panel);
        JButton add  = UITheme.accentButton("+ Add Student");
        JButton edit = UITheme.ghostButton("Edit");
        JButton del  = UITheme.dangerButton("Delete");

        add.addActionListener(e -> showAddStudentDialog());
        edit.addActionListener(e -> {
            int r = table.getSelectedRow();
            if (r < 0) { JOptionPane.showMessageDialog(this, "Please select a student first."); return; }
            Student s = DataManager.findStudentById((String) model.getValueAt(r, 0));
            if (s != null) showEditStudentDialog(s);
        });
        del.addActionListener(e -> {
            int r = table.getSelectedRow();
            if (r < 0) { JOptionPane.showMessageDialog(this, "Please select a student first."); return; }
            String id = (String) model.getValueAt(r, 0);
            if (JOptionPane.showConfirmDialog(this, "Delete student " + id + "?\nThis action cannot be undone.",
                    "Confirm Delete", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
                DataManager.deleteStudent(id);
                showStudents();
            }
        });
        btnRow.add(add); btnRow.add(edit); btnRow.add(del);
        showContent(panel);
    }

    private void showAddStudentDialog() {
        String[] fieldNames = {"Full Name", "Email", "Password", "Phone", "Address", "Major", "Year", "Semester"};
        Map<String, JTextField> fm = new LinkedHashMap<>();
        buildFormDialog("Add New Student", fieldNames, fm, () -> {
            String yearStr = fm.get("Year").getText().trim();
            int year = yearStr.isEmpty() ? 1 : Integer.parseInt(yearStr);
            String sem = fm.get("Semester").getText().trim();
            if (sem.isEmpty()) sem = "Spring 2024";
            Student s = new Student(DataManager.generateStudentId(),
                    fm.get("Full Name").getText().trim(),
                    fm.get("Email").getText().trim(),
                    fm.get("Password").getText().trim(),
                    fm.get("Phone").getText().trim(),
                    fm.get("Address").getText().trim(),
                    fm.get("Major").getText().trim(),
                    year, sem);
            DataManager.addStudent(s);
            showStudents();
        });
    }

    private void showEditStudentDialog(Student s) {
        String[] fieldNames = {"Full Name", "Email", "Password", "Phone", "Address", "Major", "Year", "Semester"};
        String[] defaults   = {s.getName(), s.getEmail(), s.getPassword(), s.getPhone(),
                s.getAddress(), s.getMajor(), String.valueOf(s.getYear()), s.getSemester()};
        Map<String, JTextField> fm = new LinkedHashMap<>();
        buildFormDialogPrefilled("Edit Student - " + s.getId(), fieldNames, defaults, fm, () -> {
            s.setName(fm.get("Full Name").getText().trim());
            s.setEmail(fm.get("Email").getText().trim());
            s.setPassword(fm.get("Password").getText().trim());
            s.setPhone(fm.get("Phone").getText().trim());
            s.setAddress(fm.get("Address").getText().trim());
            s.setMajor(fm.get("Major").getText().trim());
            try { s.setYear(Integer.parseInt(fm.get("Year").getText().trim())); } catch (Exception ex) {}
            s.setSemester(fm.get("Semester").getText().trim());
            DataManager.updateStudent(s);
            showStudents();
        });
    }

    
    
    
    private void showTeachers() {
        String[] cols = {"ID", "Name", "Email", "Phone", "Department", "Designation"};
        JPanel panel = buildManagementPanel("Teachers Management", "\uD83D\uDC68\u200D\uD83C\uDFEB  Faculty and staff management", cols);
        JTable table = extractTable(panel);
        DefaultTableModel model = (DefaultTableModel) table.getModel();

        for (Teacher t : DataManager.loadTeachers())
            model.addRow(new Object[]{t.getId(), t.getName(), t.getEmail(),
                    t.getPhone(), t.getDepartment(), t.getDesignation()});

        JPanel btnRow = extractBtnRow(panel);
        JButton add  = UITheme.accentButton("+ Add Teacher");
        JButton edit = UITheme.ghostButton("Edit");
        JButton del  = UITheme.dangerButton("Delete");

        add.addActionListener(e -> showAddTeacherDialog());
        edit.addActionListener(e -> {
            int r = table.getSelectedRow();
            if (r < 0) { JOptionPane.showMessageDialog(this, "Select a teacher first."); return; }
            Teacher t = DataManager.findTeacherById((String) model.getValueAt(r, 0));
            if (t != null) showEditTeacherDialog(t);
        });
        del.addActionListener(e -> {
            int r = table.getSelectedRow();
            if (r < 0) { JOptionPane.showMessageDialog(this, "Select a teacher first."); return; }
            String id = (String) model.getValueAt(r, 0);
            if (JOptionPane.showConfirmDialog(this, "Delete teacher " + id + "?",
                    "Confirm Delete", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
                DataManager.deleteTeacher(id);
                showTeachers();
            }
        });
        btnRow.add(add); btnRow.add(edit); btnRow.add(del);
        showContent(panel);
    }

    private void showAddTeacherDialog() {
        String[] fieldNames = {"Full Name", "Email", "Password", "Phone", "Address", "Department", "Designation"};
        Map<String, JTextField> fm = new LinkedHashMap<>();
        buildFormDialog("Add New Teacher", fieldNames, fm, () -> {
            Teacher t = new Teacher(DataManager.generateTeacherId(),
                    fm.get("Full Name").getText().trim(),
                    fm.get("Email").getText().trim(),
                    fm.get("Password").getText().trim(),
                    fm.get("Phone").getText().trim(),
                    fm.get("Address").getText().trim(),
                    fm.get("Department").getText().trim(),
                    fm.get("Designation").getText().trim());
            DataManager.addTeacher(t);
            showTeachers();
        });
    }

    private void showEditTeacherDialog(Teacher t) {
        String[] fieldNames = {"Full Name", "Email", "Password", "Phone", "Address", "Department", "Designation"};
        String[] defaults   = {t.getName(), t.getEmail(), t.getPassword(), t.getPhone(),
                t.getAddress(), t.getDepartment(), t.getDesignation()};
        Map<String, JTextField> fm = new LinkedHashMap<>();
        buildFormDialogPrefilled("Edit Teacher - " + t.getId(), fieldNames, defaults, fm, () -> {
            t.setName(fm.get("Full Name").getText().trim());
            t.setEmail(fm.get("Email").getText().trim());
            t.setPassword(fm.get("Password").getText().trim());
            t.setPhone(fm.get("Phone").getText().trim());
            t.setAddress(fm.get("Address").getText().trim());
            t.setDepartment(fm.get("Department").getText().trim());
            t.setDesignation(fm.get("Designation").getText().trim());
            DataManager.updateTeacher(t);
            showTeachers();
        });
    }

    
    
    
    private void showCourses() {
        String[] cols = {"Course ID", "Name", "Teacher", "Sem #", "Schedule", "Credits", "Enrolled", "Capacity", "Semester"};
        JPanel panel = buildManagementPanel("Courses Management", "\uD83D\uDCDA  Academic courses and curriculum (semester-wise)", cols);
        JTable table = extractTable(panel);
        DefaultTableModel model = (DefaultTableModel) table.getModel();

        // Sort by semester number
        List<Course> sorted = DataManager.loadCourses();
        sorted.sort(Comparator.comparingInt(Course::getSemesterNumber));
        for (Course c : sorted)
            model.addRow(new Object[]{c.getCourseId(), c.getCourseName(), c.getTeacherName(),
                    c.getSemesterNumber() > 0 ? "Sem " + c.getSemesterNumber() : "-",
                    c.getSchedule(), c.getCreditHours(),
                    c.getEnrolled(), c.getCapacity(), c.getSemester()});

        JPanel btnRow = extractBtnRow(panel);
        JButton add     = UITheme.accentButton("+ Add Course");
        JButton edit    = UITheme.ghostButton("Edit Course");
        JButton outline = UITheme.ghostButton("View Outline");
        JButton del     = UITheme.dangerButton("Delete");

        add.addActionListener(e -> showAddCourseDialog());
        edit.addActionListener(e -> {
            int r = table.getSelectedRow();
            if (r < 0) { JOptionPane.showMessageDialog(this, "Select a course first."); return; }
            Course c = DataManager.findCourseById((String) model.getValueAt(r, 0));
            if (c != null) showEditCourseDialog(c);
        });
        outline.addActionListener(e -> {
            int r = table.getSelectedRow();
            if (r < 0) { JOptionPane.showMessageDialog(this, "Select a course first."); return; }
            Course c = DataManager.findCourseById((String) model.getValueAt(r, 0));
            if (c != null) showAdminCourseOutlineDialog(c);
        });
        del.addActionListener(e -> {
            int r = table.getSelectedRow();
            if (r < 0) { JOptionPane.showMessageDialog(this, "Select a course first."); return; }
            String id = (String) model.getValueAt(r, 0);
            if (JOptionPane.showConfirmDialog(this, "Delete course " + id + "?",
                    "Confirm Delete", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
                DataManager.deleteCourse(id);
                showCourses();
            }
        });
        btnRow.add(add); btnRow.add(outline); btnRow.add(edit); btnRow.add(del);
        showContent(panel);
    }

    private void showAdminCourseOutlineDialog(Course c) {
        JDialog dlg = new JDialog(this, "Course Outline - " + c.getCourseId(), true);
        dlg.setSize(680, 580); dlg.setLocationRelativeTo(this);
        dlg.setLayout(new BorderLayout(10, 10));
        dlg.getRootPane().setBorder(BorderFactory.createEmptyBorder(16, 20, 16, 20));
        dlg.getContentPane().setBackground(UITheme.CARD_BG);

        JPanel hdr = new JPanel(new GridLayout(3, 1, 0, 3)); hdr.setOpaque(false);
        hdr.add(UITheme.label(c.getCourseId() + " - " + c.getCourseName(), UITheme.headingFont(), UITheme.PRIMARY));
        hdr.add(UITheme.label("  " + c.getTeacherName() + "   |   " + c.getCreditHours() + " Credit Hrs   |   Curriculum Sem " + c.getSemesterNumber(), UITheme.bodyFont(), UITheme.TEXT_MEDIUM));
        hdr.add(UITheme.label(c.getDescription(), UITheme.smallFont(), UITheme.TEXT_MUTED));
        hdr.setBorder(BorderFactory.createEmptyBorder(0, 0, 10, 0));

        JTextArea outlineArea = new JTextArea();
        outlineArea.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 13));
        outlineArea.setLineWrap(true); outlineArea.setWrapStyleWord(true);
        outlineArea.setBackground(new Color(248,250,252)); outlineArea.setForeground(UITheme.TEXT_DARK);
        outlineArea.setBorder(BorderFactory.createEmptyBorder(12, 14, 12, 14));
        outlineArea.setText(c.getCourseOutline().isEmpty() ? "No outline available." : c.getCourseOutline());

        JScrollPane sp = new JScrollPane(outlineArea);
        sp.setBorder(BorderFactory.createLineBorder(UITheme.BORDER_COLOR));

        JPanel btnRow = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        btnRow.setBackground(UITheme.CARD_BG);
        JButton saveOutline = UITheme.accentButton("Save Outline");
        JButton close       = UITheme.ghostButton("Close");
        saveOutline.addActionListener(e -> {
            c.setCourseOutline(outlineArea.getText());
            DataManager.updateCourse(c);
            JOptionPane.showMessageDialog(dlg, "Outline saved successfully!");
        });
        close.addActionListener(e -> dlg.dispose());
        btnRow.add(close); btnRow.add(saveOutline);

        dlg.add(hdr, BorderLayout.NORTH);
        dlg.add(sp, BorderLayout.CENTER);
        dlg.add(btnRow, BorderLayout.SOUTH);
        dlg.setVisible(true);
    }

    private void showAddCourseDialog() {
        JDialog dlg = new JDialog(this, "Add New Course", true);
        dlg.setSize(560, 700); dlg.setLocationRelativeTo(this);
        dlg.setLayout(new BorderLayout(10, 10));
        dlg.getRootPane().setBorder(BorderFactory.createEmptyBorder(16, 20, 16, 20));
        dlg.getContentPane().setBackground(UITheme.CARD_BG);

        List<Teacher> teachers = DataManager.loadTeachers();
        String[] tNames = teachers.stream().map(t -> t.getId() + " - " + t.getName()).toArray(String[]::new);
        JComboBox<String> teacherCombo = UITheme.styledCombo(tNames.length > 0 ? tNames : new String[]{"No teachers"});
        String[] semNums = {"1","2","3","4","5","6","7","8"};
        JComboBox<String> semNumCombo = UITheme.styledCombo(semNums);

        JTextField idF    = UITheme.styledField();
        JTextField nameF  = UITheme.styledField();
        JTextField credF  = UITheme.styledField(); credF.setText("3");
        JTextField semF   = UITheme.styledField(); semF.setText("Semester I");
        JTextField schedF = UITheme.styledField(); schedF.setText("Mon/Wed 10:00-11:30");
        JTextField roomF  = UITheme.styledField();
        JTextField capF   = UITheme.styledField(); capF.setText("40");
        JTextField deptF  = UITheme.styledField();
        JTextField descF  = UITheme.styledField();
        JTextArea  outlineArea = new JTextArea(6, 30);
        outlineArea.setFont(UITheme.bodyFont()); outlineArea.setLineWrap(true); outlineArea.setWrapStyleWord(true);
        outlineArea.setBackground(new Color(248,250,252));
        outlineArea.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(UITheme.BORDER_COLOR), BorderFactory.createEmptyBorder(8,10,8,10)));
        outlineArea.setText("Week 1-2: \nWeek 3-4: \nWeek 5-6: \nWeek 7-8: \nWeek 9-10: \nWeek 11-12: \nWeek 13-14: \nWeek 15-16: \nAssessment: Assignments 20% | Midterm 30% | Final 50%");

        JPanel form = new JPanel(new GridBagLayout());
        form.setBackground(UITheme.CARD_BG); form.setBorder(BorderFactory.createEmptyBorder(12,12,12,12));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(7,8,7,8); gbc.anchor = GridBagConstraints.WEST; gbc.fill = GridBagConstraints.HORIZONTAL;
        Object[][] frows = {{"Course ID *",idF},{"Course Name *",nameF},{"Teacher *",teacherCombo},
            {"Sem # (1-8)",semNumCombo},{"Credits",credF},{"Semester Label",semF},{"Schedule",schedF},
            {"Room",roomF},{"Capacity",capF},{"Department",deptF},{"Description",descF}};
        for (int i = 0; i < frows.length; i++) {
            gbc.gridx = 0; gbc.gridy = i; gbc.weightx = 0;
            form.add(UITheme.label((String)frows[i][0]+":", UITheme.boldFont(), UITheme.TEXT_DARK), gbc);
            gbc.gridx = 1; gbc.weightx = 1; form.add((Component)frows[i][1], gbc);
        }
        gbc.gridx = 0; gbc.gridy = frows.length; gbc.weightx = 0;
        form.add(UITheme.label("Course Outline:", UITheme.boldFont(), UITheme.TEXT_DARK), gbc);
        gbc.gridx = 1; gbc.weightx = 1; gbc.gridheight = 4;
        form.add(new JScrollPane(outlineArea), gbc);

        JPanel btnRow = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0)); btnRow.setBackground(UITheme.CARD_BG);
        JButton save = UITheme.accentButton("Save Course"); JButton cancel = UITheme.ghostButton("Cancel");
        save.addActionListener(e -> {
            if (idF.getText().trim().isEmpty() || nameF.getText().trim().isEmpty()) {
                JOptionPane.showMessageDialog(dlg, "Course ID and Name are required."); return; }
            try {
                int idx = teacherCombo.getSelectedIndex();
                Teacher t = (idx >= 0 && idx < teachers.size()) ? teachers.get(idx) : null;
                int sn = Integer.parseInt((String)semNumCombo.getSelectedItem());
                Course c = new Course(idF.getText().trim(), nameF.getText().trim(),
                        t != null ? t.getId() : "", t != null ? t.getName() : "",
                        credF.getText().trim().isEmpty() ? 3 : Integer.parseInt(credF.getText().trim()),
                        semF.getText().trim().isEmpty() ? "Semester I" : semF.getText().trim(),
                        schedF.getText().trim(), roomF.getText().trim(),
                        capF.getText().trim().isEmpty() ? 40 : Integer.parseInt(capF.getText().trim()),
                        descF.getText().trim(), deptF.getText().trim(), sn, outlineArea.getText().trim());
                DataManager.addCourse(c); dlg.dispose(); showCourses();
            } catch (NumberFormatException ex) { JOptionPane.showMessageDialog(dlg, "Credits and Capacity must be numbers."); }
        });
        cancel.addActionListener(e -> dlg.dispose());
        btnRow.add(cancel); btnRow.add(save);
        JLabel title = UITheme.label("  Add New Course", UITheme.headingFont(), UITheme.PRIMARY);
        title.setBorder(BorderFactory.createEmptyBorder(0,0,8,0));
        dlg.add(title, BorderLayout.NORTH); dlg.add(new JScrollPane(form), BorderLayout.CENTER);
        dlg.add(btnRow, BorderLayout.SOUTH); dlg.setVisible(true);
    }
    private void showEditCourseDialog(Course c) {
        JDialog dlg = new JDialog(this, "Edit Course - " + c.getCourseId(), true);
        dlg.setSize(560, 680); dlg.setLocationRelativeTo(this);
        dlg.setLayout(new BorderLayout(10, 10));
        dlg.getRootPane().setBorder(BorderFactory.createEmptyBorder(16, 20, 16, 20));
        dlg.getContentPane().setBackground(UITheme.CARD_BG);

        List<Teacher> teachers = DataManager.loadTeachers();
        String[] tNames = teachers.stream().map(t -> t.getId() + " - " + t.getName()).toArray(String[]::new);
        JComboBox<String> teacherCombo = UITheme.styledCombo(tNames.length > 0 ? tNames : new String[]{"No teachers"});
        for (int i = 0; i < teachers.size(); i++) {
            if (teachers.get(i).getId().equalsIgnoreCase(c.getTeacherId())) { teacherCombo.setSelectedIndex(i); break; }
        }
        String[] semNums = {"1","2","3","4","5","6","7","8"};
        JComboBox<String> semNumCombo = UITheme.styledCombo(semNums);
        semNumCombo.setSelectedItem(String.valueOf(c.getSemesterNumber()));

        JTextField nameF  = UITheme.styledField(); nameF.setText(c.getCourseName());
        JTextField credF  = UITheme.styledField(); credF.setText(String.valueOf(c.getCreditHours()));
        JTextField semF   = UITheme.styledField(); semF.setText(c.getSemester());
        JTextField schedF = UITheme.styledField(); schedF.setText(c.getSchedule());
        JTextField roomF  = UITheme.styledField(); roomF.setText(c.getRoom());
        JTextField capF   = UITheme.styledField(); capF.setText(String.valueOf(c.getCapacity()));
        JTextField deptF  = UITheme.styledField(); deptF.setText(c.getDepartment());
        JTextField descF  = UITheme.styledField(); descF.setText(c.getDescription());
        JTextArea  outlineArea = new JTextArea(6, 30);
        outlineArea.setFont(UITheme.bodyFont()); outlineArea.setLineWrap(true); outlineArea.setWrapStyleWord(true);
        outlineArea.setBackground(new Color(248,250,252));
        outlineArea.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(UITheme.BORDER_COLOR), BorderFactory.createEmptyBorder(8,10,8,10)));
        outlineArea.setText(c.getCourseOutline().isEmpty() ? "No outline yet." : c.getCourseOutline());

        JPanel form = new JPanel(new GridBagLayout());
        form.setBackground(UITheme.CARD_BG); form.setBorder(BorderFactory.createEmptyBorder(12,12,12,12));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(7,8,7,8); gbc.anchor = GridBagConstraints.WEST; gbc.fill = GridBagConstraints.HORIZONTAL;
        Object[][] frows = {{"Course Name",nameF},{"Teacher",teacherCombo},{"Sem # (1-8)",semNumCombo},
            {"Credits",credF},{"Semester Label",semF},{"Schedule",schedF},
            {"Room",roomF},{"Capacity",capF},{"Department",deptF},{"Description",descF}};
        for (int i = 0; i < frows.length; i++) {
            gbc.gridx = 0; gbc.gridy = i; gbc.weightx = 0;
            form.add(UITheme.label((String)frows[i][0]+":", UITheme.boldFont(), UITheme.TEXT_DARK), gbc);
            gbc.gridx = 1; gbc.weightx = 1; form.add((Component)frows[i][1], gbc);
        }
        gbc.gridx = 0; gbc.gridy = frows.length; gbc.weightx = 0;
        form.add(UITheme.label("Course Outline:", UITheme.boldFont(), UITheme.TEXT_DARK), gbc);
        gbc.gridx = 1; gbc.weightx = 1; gbc.gridheight = 4;
        form.add(new JScrollPane(outlineArea), gbc);

        JPanel btnRow = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0)); btnRow.setBackground(UITheme.CARD_BG);
        JButton save = UITheme.accentButton("Save Changes"); JButton cancel = UITheme.ghostButton("Cancel");
        save.addActionListener(e -> {
            try {
                int idx = teacherCombo.getSelectedIndex();
                Teacher t = (idx >= 0 && idx < teachers.size()) ? teachers.get(idx) : null;
                c.setCourseName(nameF.getText().trim());
                if (t != null) { c.setTeacherId(t.getId()); c.setTeacherName(t.getName()); }
                c.setSemesterNumber(Integer.parseInt((String)semNumCombo.getSelectedItem()));
                c.setCreditHours(Integer.parseInt(credF.getText().trim()));
                c.setSemester(semF.getText().trim());
                c.setSchedule(schedF.getText().trim()); c.setRoom(roomF.getText().trim());
                c.setCapacity(Integer.parseInt(capF.getText().trim()));
                c.setDepartment(deptF.getText().trim()); c.setDescription(descF.getText().trim());
                c.setCourseOutline(outlineArea.getText().trim());
                DataManager.updateCourse(c); dlg.dispose(); showCourses();
            } catch (NumberFormatException ex) { JOptionPane.showMessageDialog(dlg, "Credits and Capacity must be numbers."); }
        });
        cancel.addActionListener(e -> dlg.dispose());
        btnRow.add(cancel); btnRow.add(save);
        JLabel title = UITheme.label("Edit Course - " + c.getCourseId(), UITheme.headingFont(), UITheme.PRIMARY);
        title.setBorder(BorderFactory.createEmptyBorder(0,0,8,0));
        dlg.add(title, BorderLayout.NORTH); dlg.add(new JScrollPane(form), BorderLayout.CENTER);
        dlg.add(btnRow, BorderLayout.SOUTH); dlg.setVisible(true);
    }

    private JPanel buildStyledForm(Object[][] rows) {
        JPanel form = new JPanel(new GridBagLayout());
        form.setBackground(UITheme.CARD_BG);
        form.setBorder(BorderFactory.createEmptyBorder(12, 12, 12, 12));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(7, 8, 7, 8);
        gbc.anchor = GridBagConstraints.WEST;
        gbc.fill   = GridBagConstraints.HORIZONTAL;
        for (int i = 0; i < rows.length; i++) {
            gbc.gridx = 0; gbc.gridy = i; gbc.weightx = 0;
            form.add(UITheme.label((String) rows[i][0] + ":", UITheme.boldFont(), UITheme.TEXT_DARK), gbc);
            gbc.gridx = 1; gbc.weightx = 1;
            form.add((Component) rows[i][1], gbc);
        }
        return form;
    }

    
    
    
    private void showGrades() {
        String[] cols = {"Grade ID", "Student ID", "Course ID", "Course Name",
                "Assignment", "Midterm", "Final", "Total", "Letter", "Semester"};
        JPanel panel = buildManagementPanel("Grade Records", "\u2B50  Academic performance records", cols);
        JTable table = extractTable(panel);
        DefaultTableModel model = (DefaultTableModel) table.getModel();

        for (Grade g : DataManager.loadGrades())
            model.addRow(new Object[]{g.getGradeId(), g.getStudentId(), g.getCourseId(),
                    g.getCourseName(), g.getAssignment1(), g.getMidterm(),
                    g.getFinalProject(), String.format("%.1f", g.getTotal()),
                    g.getLetterGrade(), g.getSemester()});

        JPanel btnRow = extractBtnRow(panel);
        JButton filterBtn = UITheme.ghostButton("Filter by Student");
        filterBtn.addActionListener(e -> {
            String id = JOptionPane.showInputDialog(this, "Enter Student ID to filter:");
            if (id == null || id.trim().isEmpty()) { showGrades(); return; }
            model.setRowCount(0);
            for (Grade g : DataManager.getGradesForStudent(id.trim()))
                model.addRow(new Object[]{g.getGradeId(), g.getStudentId(), g.getCourseId(),
                        g.getCourseName(), g.getAssignment1(), g.getMidterm(),
                        g.getFinalProject(), String.format("%.1f", g.getTotal()),
                        g.getLetterGrade(), g.getSemester()});
        });
        JButton resetBtn = UITheme.accentButton("Show All");
        resetBtn.addActionListener(e -> showGrades());
        btnRow.add(filterBtn); btnRow.add(resetBtn);
        showContent(panel);
    }

    
    
    
    private void showAnnouncements() {
        JPanel panel = new JPanel(new BorderLayout(0, 0));
        panel.setBackground(UITheme.CONTENT_BG);

        
        JPanel headerBanner = new JPanel(new BorderLayout()) {
            @Override protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g.create();
                GradientPaint gp = new GradientPaint(0, 0, new Color(109, 40, 217), getWidth(), 0, new Color(79, 70, 229));
                g2.setPaint(gp); g2.fillRect(0, 0, getWidth(), getHeight()); g2.dispose();
            }
        };
        headerBanner.setPreferredSize(new Dimension(0, 80));
        headerBanner.setBorder(BorderFactory.createEmptyBorder(16, 28, 16, 28));
        JPanel hTexts = new JPanel(new GridLayout(2, 1, 0, 3)); hTexts.setOpaque(false);
        hTexts.add(UITheme.label("*  Announcements", UITheme.font(Font.BOLD, 22), Color.WHITE));
        hTexts.add(UITheme.label("Broadcast important information to students and staff", UITheme.font(Font.PLAIN, 12), new Color(210, 200, 255)));
        headerBanner.add(hTexts, BorderLayout.WEST);
        JButton addBtn = UITheme.accentButton("+ New Announcement");
        addBtn.addActionListener(e -> showAddAnnDialog());
        JPanel btnWrap = new JPanel(new FlowLayout(FlowLayout.RIGHT, 0, 0)); btnWrap.setOpaque(false);
        btnWrap.add(addBtn);
        headerBanner.add(btnWrap, BorderLayout.EAST);

        JPanel content = new JPanel(new BorderLayout(0, 14));
        content.setOpaque(false);
        content.setBorder(BorderFactory.createEmptyBorder(20, 26, 20, 26));

        String[] cols = {"ID", "Title", "Author", "Role", "Course", "Priority", "Date"};
        DefaultTableModel model = new DefaultTableModel(cols, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };
        for (Announcement a : DataManager.loadAnnouncements())
            model.addRow(new Object[]{a.getAnnouncementId(), a.getTitle(), a.getAuthorName(),
                    a.getAuthorRole(), a.getCourseId(), a.getPriority(), a.getDateTime()});

        JTable table = new JTable(model);
        UITheme.styleTable(table);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        JPanel btnRow = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        btnRow.setOpaque(false);
        JButton del = UITheme.dangerButton("Delete Selected");
        del.addActionListener(e -> {
            int r = table.getSelectedRow();
            if (r < 0) { JOptionPane.showMessageDialog(this, "Select an announcement."); return; }
            String id = (String) model.getValueAt(r, 0);
            if (JOptionPane.showConfirmDialog(this, "Delete this announcement?",
                    "Confirm", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
                DataManager.deleteAnnouncement(id);
                showAnnouncements();
            }
        });
        btnRow.add(del);

        content.add(UITheme.scrollPane(table), BorderLayout.CENTER);
        content.add(btnRow, BorderLayout.SOUTH);

        panel.add(headerBanner, BorderLayout.NORTH);
        panel.add(content, BorderLayout.CENTER);
        showContent(panel);
    }

    private void showAddAnnDialog() {
        JDialog dlg = new JDialog(this, "New Announcement", true);
        dlg.setSize(480, 420);
        dlg.setLocationRelativeTo(this);
        dlg.setLayout(new BorderLayout(10, 10));
        dlg.getRootPane().setBorder(BorderFactory.createEmptyBorder(16, 20, 16, 20));
        dlg.getContentPane().setBackground(UITheme.CARD_BG);

        JTextField titleF = UITheme.styledField();
        JTextArea contentF = new JTextArea(5, 30);
        contentF.setFont(UITheme.bodyFont());
        contentF.setLineWrap(true);
        contentF.setWrapStyleWord(true);
        contentF.setBackground(new Color(248, 250, 252));
        contentF.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(UITheme.BORDER_COLOR),
            BorderFactory.createEmptyBorder(8, 10, 8, 10)));

        String[] prios = {"HIGH", "MEDIUM", "LOW"};
        JComboBox<String> prioCombo = UITheme.styledCombo(prios);

        List<Course> allCourses = DataManager.loadCourses();
        String[] courseOpts = new String[allCourses.size() + 1];
        courseOpts[0] = "GLOBAL - All Users";
        for (int i = 0; i < allCourses.size(); i++)
            courseOpts[i + 1] = allCourses.get(i).getCourseId() + " - " + allCourses.get(i).getCourseName();
        JComboBox<String> courseCombo = UITheme.styledCombo(courseOpts);

        JPanel form = new JPanel(new GridBagLayout());
        form.setBackground(UITheme.CARD_BG);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 6, 8, 6);
        gbc.anchor = GridBagConstraints.WEST;
        gbc.fill = GridBagConstraints.HORIZONTAL;

        String[] labels = {"Title *", "Course Target", "Priority"};
        Component[] comps = {titleF, courseCombo, prioCombo};
        for (int i = 0; i < labels.length; i++) {
            gbc.gridx = 0; gbc.gridy = i; gbc.weightx = 0;
            form.add(UITheme.label(labels[i] + ":", UITheme.boldFont(), UITheme.TEXT_DARK), gbc);
            gbc.gridx = 1; gbc.weightx = 1;
            form.add(comps[i], gbc);
        }
        gbc.gridx = 0; gbc.gridy = labels.length; gbc.weightx = 0;
        form.add(UITheme.label("Content *:", UITheme.boldFont(), UITheme.TEXT_DARK), gbc);
        gbc.gridx = 1; gbc.weightx = 1; gbc.gridheight = 3;
        form.add(new JScrollPane(contentF), gbc);

        JPanel btnRow = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        btnRow.setBackground(UITheme.CARD_BG);
        JButton post   = UITheme.accentButton("* Post Announcement");
        JButton cancel = UITheme.ghostButton("Cancel");
        post.addActionListener(e -> {
            String ttl = titleF.getText().trim();
            String cnt = contentF.getText().trim();
            if (ttl.isEmpty() || cnt.isEmpty()) {
                JOptionPane.showMessageDialog(dlg, "Title and Content are required."); return;
            }
            String cid = courseCombo.getSelectedIndex() == 0 ? "GLOBAL"
                    : allCourses.get(courseCombo.getSelectedIndex() - 1).getCourseId();
            Announcement ann = new Announcement(
                    DataManager.generateAnnouncementId(), ttl, cnt,
                    admin.getId(), admin.getName(), "ADMIN",
                    cid, (String) prioCombo.getSelectedItem());
            DataManager.addAnnouncement(ann);
            dlg.dispose();
            showAnnouncements();
        });
        cancel.addActionListener(e -> dlg.dispose());
        btnRow.add(cancel); btnRow.add(post);

        JLabel title = UITheme.label("\uD83D\uDCE2  New Announcement", UITheme.headingFont(), UITheme.PRIMARY);
        title.setBorder(BorderFactory.createEmptyBorder(0, 0, 8, 0));
        dlg.add(title, BorderLayout.NORTH);
        dlg.add(form, BorderLayout.CENTER);
        dlg.add(btnRow, BorderLayout.SOUTH);
        dlg.setVisible(true);
    }

    
    
    
    private void showAdmins() {
        String[] cols = {"ID", "Name", "Email", "Phone", "Level"};
        JPanel panel = buildManagementPanel("Admin Accounts", "\u2699  System administrator management", cols);
        JTable table = extractTable(panel);
        DefaultTableModel model = (DefaultTableModel) table.getModel();

        for (Admin a : DataManager.loadAdmins())
            model.addRow(new Object[]{a.getId(), a.getName(), a.getEmail(), a.getPhone(), a.getAdminLevel()});

        JPanel btnRow = extractBtnRow(panel);
        JButton add  = UITheme.accentButton("+ Add Admin");
        JButton edit = UITheme.ghostButton("Edit");
        JButton del  = UITheme.dangerButton("Delete");

        add.addActionListener(e -> {
            String[] fieldNames = {"Full Name", "Email", "Password", "Phone", "Level (SUPER/REGULAR)"};
            Map<String, JTextField> fm = new LinkedHashMap<>();
            buildFormDialog("Add Admin Account", fieldNames, fm, () -> {
                String level = fm.get("Level (SUPER/REGULAR)").getText().trim().toUpperCase();
                if (level.isEmpty()) level = "REGULAR";
                Admin a = new Admin(DataManager.generateAdminId(),
                        fm.get("Full Name").getText().trim(),
                        fm.get("Email").getText().trim(),
                        fm.get("Password").getText().trim(),
                        fm.get("Phone").getText().trim(), "", level);
                DataManager.addAdmin(a);
                showAdmins();
            });
        });
        edit.addActionListener(e -> {
            int r = table.getSelectedRow();
            if (r < 0) { JOptionPane.showMessageDialog(this, "Select an admin first."); return; }
            Admin a = DataManager.findAdminById((String) model.getValueAt(r, 0));
            if (a == null) return;
            String[] fieldNames = {"Full Name", "Email", "Password", "Phone"};
            String[] defaults   = {a.getName(), a.getEmail(), a.getPassword(), a.getPhone()};
            Map<String, JTextField> fm = new LinkedHashMap<>();
            buildFormDialogPrefilled("Edit Admin - " + a.getId(), fieldNames, defaults, fm, () -> {
                a.setName(fm.get("Full Name").getText().trim());
                a.setEmail(fm.get("Email").getText().trim());
                a.setPassword(fm.get("Password").getText().trim());
                a.setPhone(fm.get("Phone").getText().trim());
                DataManager.updateAdmin(a);
                showAdmins();
            });
        });
        del.addActionListener(e -> {
            int r = table.getSelectedRow();
            if (r < 0) { JOptionPane.showMessageDialog(this, "Select an admin first."); return; }
            String id = (String) model.getValueAt(r, 0);
            if (id.equalsIgnoreCase(admin.getId())) {
                JOptionPane.showMessageDialog(this, "Cannot delete your own account."); return;
            }
            if (JOptionPane.showConfirmDialog(this, "Delete admin " + id + "?",
                    "Confirm", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
                DataManager.deleteAdmin(id);
                showAdmins();
            }
        });
        btnRow.add(add); btnRow.add(edit); btnRow.add(del);
        showContent(panel);
    }

    
    
    
    private void showFeeChallan() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(utils.UITheme.CONTENT_BG);
        panel.add(new gui.FeeChallanPanel(gui.FeeChallanPanel.Mode.ADMIN, currentUser, this), BorderLayout.CENTER);
        showContent(panel);
    }

    private void showApplications() {
        // Use a single BoxLayout column so every section gets its natural height
        // and nothing clips the action bar at the bottom.
        JPanel root = new JPanel();
        root.setLayout(new javax.swing.BoxLayout(root, javax.swing.BoxLayout.Y_AXIS));
        root.setBackground(utils.UITheme.CONTENT_BG);
        root.setBorder(javax.swing.BorderFactory.createEmptyBorder(24, 28, 16, 28));

        // ── Header ────────────────────────────────────────────────────────────
        JLabel title = new JLabel("Student Admission Applications");
        title.setFont(utils.UITheme.font(java.awt.Font.BOLD, 22));
        title.setForeground(utils.UITheme.PRIMARY);
        title.setAlignmentX(java.awt.Component.LEFT_ALIGNMENT);

        JLabel sub = new JLabel("Review and approve or reject new student sign-up requests");
        sub.setFont(utils.UITheme.font(java.awt.Font.PLAIN, 13));
        sub.setForeground(utils.UITheme.TEXT_MUTED);
        sub.setAlignmentX(java.awt.Component.LEFT_ALIGNMENT);

        root.add(title);
        root.add(javax.swing.Box.createVerticalStrut(4));
        root.add(sub);
        root.add(javax.swing.Box.createVerticalStrut(18));

        // ── Load data ─────────────────────────────────────────────────────────
        java.util.List<String[]> apps = utils.DataManager.loadPendingApplications();

        // ── Empty state ───────────────────────────────────────────────────────
        if (apps.isEmpty()) {
            JPanel empty = new JPanel(new java.awt.GridBagLayout());
            empty.setBackground(java.awt.Color.WHITE);
            empty.setAlignmentX(java.awt.Component.LEFT_ALIGNMENT);
            empty.setMaximumSize(new java.awt.Dimension(Integer.MAX_VALUE, Integer.MAX_VALUE));
            empty.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(210, 225, 245)));
            JPanel inner = new JPanel();
            inner.setOpaque(false);
            inner.setLayout(new javax.swing.BoxLayout(inner, javax.swing.BoxLayout.Y_AXIS));
            JLabel icon = new JLabel("📋");
            icon.setFont(utils.UITheme.font(java.awt.Font.PLAIN, 40));
            icon.setAlignmentX(java.awt.Component.CENTER_ALIGNMENT);
            JLabel msg = new JLabel("No pending applications");
            msg.setFont(utils.UITheme.font(java.awt.Font.BOLD, 16));
            msg.setForeground(utils.UITheme.TEXT_MUTED);
            msg.setAlignmentX(java.awt.Component.CENTER_ALIGNMENT);
            JLabel hint = new JLabel("When students sign up, their applications will appear here.");
            hint.setFont(utils.UITheme.font(java.awt.Font.PLAIN, 13));
            hint.setForeground(utils.UITheme.TEXT_MUTED);
            hint.setAlignmentX(java.awt.Component.CENTER_ALIGNMENT);
            inner.add(icon);
            inner.add(javax.swing.Box.createVerticalStrut(10));
            inner.add(msg);
            inner.add(javax.swing.Box.createVerticalStrut(6));
            inner.add(hint);
            empty.add(inner);
            root.add(empty);
            showContent(root);
            return;
        }

        // ── Table ─────────────────────────────────────────────────────────────
        String[] cols = {"App ID", "Full Name", "Email", "Phone", "Major", "Applied On"};
        javax.swing.table.DefaultTableModel model = new javax.swing.table.DefaultTableModel(cols, 0) {
            @Override public boolean isCellEditable(int row, int col) { return false; }
        };
        for (String[] r : apps)
            model.addRow(new Object[]{r[0], r[1], r[2], r[4], r[6], r[7]});

        JTable table = new JTable(model);
        utils.UITheme.styleTable(table);
        table.getTableHeader().setReorderingAllowed(false);
        table.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        table.getColumnModel().getColumn(0).setPreferredWidth(70);
        table.getColumnModel().getColumn(1).setPreferredWidth(160);
        table.getColumnModel().getColumn(2).setPreferredWidth(195);
        table.getColumnModel().getColumn(3).setPreferredWidth(110);
        table.getColumnModel().getColumn(4).setPreferredWidth(170);
        table.getColumnModel().getColumn(5).setPreferredWidth(135);

        JScrollPane scroll = new JScrollPane(table);
        scroll.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(210, 225, 245)));
        scroll.setAlignmentX(java.awt.Component.LEFT_ALIGNMENT);
        // Give the scroll pane a preferred size so it doesn't collapse
        scroll.setPreferredSize(new java.awt.Dimension(840, 300));
        scroll.setMaximumSize(new java.awt.Dimension(Integer.MAX_VALUE, Integer.MAX_VALUE));
        root.add(scroll);

        root.add(javax.swing.Box.createVerticalStrut(14));

        // ── Action bar (count left, buttons right) ────────────────────────────
        JPanel actionBar = new JPanel(new BorderLayout());
        actionBar.setOpaque(false);
        actionBar.setAlignmentX(java.awt.Component.LEFT_ALIGNMENT);
        actionBar.setMaximumSize(new java.awt.Dimension(Integer.MAX_VALUE, 52));

        JLabel countLbl = new JLabel(apps.size() + " pending application(s)  —  select a row then click Approve or Reject");
        countLbl.setFont(utils.UITheme.font(java.awt.Font.PLAIN, 12));
        countLbl.setForeground(utils.UITheme.TEXT_MUTED);

        JPanel btnPanel = new JPanel(new java.awt.FlowLayout(java.awt.FlowLayout.RIGHT, 10, 0));
        btnPanel.setOpaque(false);

        JButton rejectBtn = new JButton("✘  Reject Selected") {
            @Override protected void paintComponent(java.awt.Graphics g) {
                java.awt.Graphics2D g2 = (java.awt.Graphics2D) g.create();
                g2.setRenderingHint(java.awt.RenderingHints.KEY_ANTIALIASING, java.awt.RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(getModel().isRollover() ? new java.awt.Color(185, 28, 28) : utils.UITheme.DANGER);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 8, 8);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        rejectBtn.setFont(utils.UITheme.font(java.awt.Font.BOLD, 13));
        rejectBtn.setForeground(java.awt.Color.WHITE);
        rejectBtn.setContentAreaFilled(false);
        rejectBtn.setBorderPainted(false);
        rejectBtn.setFocusPainted(false);
        rejectBtn.setCursor(java.awt.Cursor.getPredefinedCursor(java.awt.Cursor.HAND_CURSOR));
        rejectBtn.setBorder(javax.swing.BorderFactory.createEmptyBorder(10, 22, 10, 22));

        JButton approveBtn = new JButton("✔  Approve Selected") {
            @Override protected void paintComponent(java.awt.Graphics g) {
                java.awt.Graphics2D g2 = (java.awt.Graphics2D) g.create();
                g2.setRenderingHint(java.awt.RenderingHints.KEY_ANTIALIASING, java.awt.RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(getModel().isRollover() ? new java.awt.Color(21, 128, 61) : new java.awt.Color(22, 163, 74));
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 8, 8);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        approveBtn.setFont(utils.UITheme.font(java.awt.Font.BOLD, 13));
        approveBtn.setForeground(java.awt.Color.WHITE);
        approveBtn.setContentAreaFilled(false);
        approveBtn.setBorderPainted(false);
        approveBtn.setFocusPainted(false);
        approveBtn.setCursor(java.awt.Cursor.getPredefinedCursor(java.awt.Cursor.HAND_CURSOR));
        approveBtn.setBorder(javax.swing.BorderFactory.createEmptyBorder(10, 22, 10, 22));

        approveBtn.addActionListener(e -> {
            int row = table.getSelectedRow();
            if (row < 0) {
                JOptionPane.showMessageDialog(this, "Please select an application from the table first.",
                        "No Selection", JOptionPane.WARNING_MESSAGE);
                return;
            }
            String appId = (String) model.getValueAt(row, 0);
            String name  = (String) model.getValueAt(row, 1);
            int confirm = JOptionPane.showConfirmDialog(this,
                "<html>Approve application for <b>" + name + "</b>?<br>"
                + "A student account will be created and they can log in immediately.</html>",
                "Confirm Approval", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
            if (confirm == JOptionPane.YES_OPTION) {
                utils.DataManager.approveApplication(appId);
                JOptionPane.showMessageDialog(this,
                    "<html>✔ Application <b>approved</b>!<br>" + name + " is now a registered student.</html>",
                    "Approved", JOptionPane.INFORMATION_MESSAGE);
                showApplications();
            }
        });

        rejectBtn.addActionListener(e -> {
            int row = table.getSelectedRow();
            if (row < 0) {
                JOptionPane.showMessageDialog(this, "Please select an application from the table first.",
                        "No Selection", JOptionPane.WARNING_MESSAGE);
                return;
            }
            String appId = (String) model.getValueAt(row, 0);
            String name  = (String) model.getValueAt(row, 1);
            int confirm = JOptionPane.showConfirmDialog(this,
                "<html>Reject application for <b>" + name + "</b>?<br>"
                + "This will permanently remove the application.</html>",
                "Confirm Rejection", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
            if (confirm == JOptionPane.YES_OPTION) {
                utils.DataManager.rejectApplication(appId);
                JOptionPane.showMessageDialog(this,
                    "<html>Application for <b>" + name + "</b> has been rejected.</html>",
                    "Rejected", JOptionPane.INFORMATION_MESSAGE);
                showApplications();
            }
        });

        btnPanel.add(rejectBtn);
        btnPanel.add(approveBtn);

        actionBar.add(countLbl, BorderLayout.WEST);
        actionBar.add(btnPanel, BorderLayout.EAST);

        root.add(actionBar);
        showContent(root);
    }

    private void showProfile() {
        JPanel panel = new JPanel(new BorderLayout(0, 0));
        panel.setBackground(UITheme.CONTENT_BG);

        JPanel headerBanner = new JPanel(new BorderLayout()) {
            @Override protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g.create();
                GradientPaint gp = new GradientPaint(0, 0, UITheme.PRIMARY_DARK, getWidth(), 0, UITheme.PRIMARY);
                g2.setPaint(gp); g2.fillRect(0, 0, getWidth(), getHeight()); g2.dispose();
            }
        };
        headerBanner.setPreferredSize(new Dimension(0, 80));
        headerBanner.setBorder(BorderFactory.createEmptyBorder(16, 28, 16, 28));
        JPanel hTexts = new JPanel(new GridLayout(2, 1, 0, 3)); hTexts.setOpaque(false);
        hTexts.add(UITheme.label("o  My Profile", UITheme.font(Font.BOLD, 22), Color.WHITE));
        hTexts.add(UITheme.label("Manage your account information and settings", UITheme.font(Font.PLAIN, 12), new Color(190, 210, 245)));
        headerBanner.add(hTexts, BorderLayout.WEST);

        JPanel content = new JPanel(new BorderLayout(0, 20));
        content.setOpaque(false);
        content.setBorder(BorderFactory.createEmptyBorder(24, 50, 24, 50));

        Admin fresh = DataManager.findAdminById(admin.getId());
        if (fresh != null) admin = fresh;

        
        JPanel twoCol = new JPanel(new GridBagLayout());
        twoCol.setOpaque(false);
        GridBagConstraints tc = new GridBagConstraints();
        tc.anchor = GridBagConstraints.NORTH;
        tc.fill   = GridBagConstraints.BOTH;
        tc.insets = new Insets(0, 0, 0, 16);

        tc.gridx = 0; tc.gridy = 0; tc.weightx = 0.28;
        JPanel picCard = buildProfilePicturePanel(() -> DataManager.updateAdmin(admin));
        twoCol.add(picCard, tc);

        tc.gridx = 1; tc.weightx = 0.72; tc.insets = new Insets(0, 0, 0, 0);
        JPanel formCard = new JPanel(new GridBagLayout()) {
            @Override protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(new Color(0, 0, 0, 6));
                g2.fillRoundRect(2, 2, getWidth() - 2, getHeight() - 2, 14, 14);
                g2.setColor(Color.WHITE);
                g2.fillRoundRect(0, 0, getWidth() - 2, getHeight() - 2, 14, 14);
                g2.dispose();
            }
        };
        formCard.setOpaque(false);
        formCard.setBorder(BorderFactory.createEmptyBorder(28, 32, 28, 32));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets  = new Insets(10, 10, 10, 10);
        gbc.anchor  = GridBagConstraints.WEST;
        gbc.fill    = GridBagConstraints.HORIZONTAL;

        String[][] fields = {
            {"Full Name", admin.getName()}, {"Admin ID", admin.getId()},
            {"Email", admin.getEmail()},    {"Phone", admin.getPhone()},
            {"Level", admin.getAdminLevel()}
        };
        Map<String, JTextField> fm = new LinkedHashMap<>();
        for (int i = 0; i < fields.length; i++) {
            gbc.gridx = 0; gbc.gridy = i; gbc.weightx = 0;
            formCard.add(UITheme.label(fields[i][0] + ":", UITheme.boldFont(), UITheme.TEXT_DARK), gbc);
            gbc.gridx = 1; gbc.weightx = 1;
            JTextField tf = UITheme.styledField();
            tf.setText(fields[i][1]);
            boolean editable = !fields[i][0].equals("Admin ID") && !fields[i][0].equals("Level");
            tf.setEditable(editable);
            if (!editable) { tf.setBackground(UITheme.CONTENT_BG); tf.setForeground(UITheme.TEXT_MUTED); }
            fm.put(fields[i][0], tf);
            formCard.add(tf, gbc);
        }

        gbc.gridx = 0; gbc.gridy = fields.length; gbc.weightx = 0;
        formCard.add(UITheme.label("Password:", UITheme.boldFont(), UITheme.TEXT_DARK), gbc);
        gbc.gridx = 1; gbc.weightx = 1;
        JButton changePwdBtn = UITheme.ghostButton("Change Password");
        changePwdBtn.addActionListener(e -> showChangePasswordDialog("admin", admin.getId()));
        formCard.add(changePwdBtn, gbc);

        twoCol.add(formCard, tc);

        JPanel btnRow = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        btnRow.setOpaque(false);
        JButton save = UITheme.primaryButton("Save Changes");
        save.addActionListener(e -> {
            admin.setName(fm.get("Full Name").getText().trim());
            admin.setEmail(fm.get("Email").getText().trim());
            admin.setPhone(fm.get("Phone").getText().trim());
            DataManager.updateAdmin(admin);
            userNameLbl.setText(admin.getName().split(" ")[0]);
            JOptionPane.showMessageDialog(this, "Profile updated successfully!");
        });
        btnRow.add(save);

        content.add(twoCol, BorderLayout.CENTER);
        content.add(btnRow, BorderLayout.SOUTH);

        JScrollPane profileScroll = new JScrollPane(content);
        profileScroll.setBorder(null);
        profileScroll.setOpaque(false);
        profileScroll.getViewport().setOpaque(false);
        profileScroll.getViewport().setBackground(UITheme.CONTENT_BG);
        profileScroll.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        profileScroll.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        profileScroll.getVerticalScrollBar().setUnitIncrement(16);

        panel.add(headerBanner, BorderLayout.NORTH);
        panel.add(profileScroll, BorderLayout.CENTER);
        showContent(panel);
    }
    private void showChangePasswordDialog(String role, String userId) {
        JDialog dlg = new JDialog(this, "Change Password", true);
        dlg.setSize(400, 280);
        dlg.setLocationRelativeTo(this);
        dlg.setLayout(new BorderLayout(10, 10));
        dlg.getRootPane().setBorder(BorderFactory.createEmptyBorder(20, 24, 20, 24));
        dlg.getContentPane().setBackground(UITheme.CARD_BG);

        JPasswordField currentF = UITheme.styledPasswordField();
        JPasswordField newF     = UITheme.styledPasswordField();
        JPasswordField confirmF = UITheme.styledPasswordField();

        JPanel form = new JPanel(new GridLayout(3, 2, 10, 14));
        form.setBackground(UITheme.CARD_BG);
        form.add(UITheme.label("Current Password:", UITheme.boldFont(), UITheme.TEXT_DARK)); form.add(currentF);
        form.add(UITheme.label("New Password:",     UITheme.boldFont(), UITheme.TEXT_DARK)); form.add(newF);
        form.add(UITheme.label("Confirm New:",      UITheme.boldFont(), UITheme.TEXT_DARK)); form.add(confirmF);

        JPanel btnRow = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        btnRow.setBackground(UITheme.CARD_BG);
        JButton change = UITheme.primaryButton("Change Password");
        JButton cancel = UITheme.ghostButton("Cancel");
        change.addActionListener(e -> {
            String curr    = new String(currentF.getPassword());
            String newPwd  = new String(newF.getPassword());
            String confirm = new String(confirmF.getPassword());
            if (!newPwd.equals(confirm)) {
                JOptionPane.showMessageDialog(dlg, "New passwords do not match."); return;
            }
            if (newPwd.length() < 6) {
                JOptionPane.showMessageDialog(dlg, "Password must be at least 6 characters."); return;
            }
            Admin a = DataManager.findAdminById(userId);
            if (a == null || !a.getPassword().equals(curr)) {
                JOptionPane.showMessageDialog(dlg, "Current password is incorrect."); return;
            }
            a.setPassword(newPwd);
            DataManager.updateAdmin(a);
            JOptionPane.showMessageDialog(dlg, "Password changed successfully!");
            dlg.dispose();
        });
        cancel.addActionListener(e -> dlg.dispose());
        btnRow.add(cancel); btnRow.add(change);

        JLabel title = UITheme.label("Change Password", UITheme.headingFont(), UITheme.PRIMARY);
        title.setBorder(BorderFactory.createEmptyBorder(0, 0, 8, 0));
        dlg.add(title, BorderLayout.NORTH);
        dlg.add(form, BorderLayout.CENTER);
        dlg.add(btnRow, BorderLayout.SOUTH);
        dlg.setVisible(true);
    }

    
    
    
    private JPanel buildManagementPanel(String title, String subtitle, String[] cols) {
        JPanel panel = new JPanel(new BorderLayout(0, 0));
        panel.setBackground(UITheme.CONTENT_BG);

        // Sky-blue gradient header with emoji symbol
        JPanel headerBanner = new JPanel(new BorderLayout()) {
            @Override protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                GradientPaint gp = new GradientPaint(0, 0, new Color(2, 132, 199),
                        getWidth(), getHeight(), new Color(14, 165, 233));
                g2.setPaint(gp); g2.fillRect(0, 0, getWidth(), getHeight());
                // Decorative circles
                g2.setColor(new Color(255, 255, 255, 18));
                g2.fillOval(getWidth() - 160, -40, 200, 200);
                g2.setColor(new Color(255, 255, 255, 10));
                g2.fillOval(getWidth() - 60, 10, 100, 100);
                g2.dispose();
            }
        };
        headerBanner.setPreferredSize(new Dimension(0, 84));
        headerBanner.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 0));

        // Icon circle on left
        String sym = getMgmtSymbol(title);
        JPanel iconCircle = new JPanel() {
            @Override protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(new Color(255, 255, 255, 45));
                g2.fillOval(6, 6, 52, 52);
                g2.setColor(Color.WHITE);
                Font sf = UITheme.getSymbolFontPublic(sym, 22);
                g2.setFont(sf);
                FontMetrics fm = g2.getFontMetrics();
                g2.drawString(sym, (64 - fm.stringWidth(sym)) / 2, (64 - fm.getHeight()) / 2 + fm.getAscent());
                g2.dispose();
            }
            @Override public Dimension getPreferredSize() { return new Dimension(64, 84); }
        };
        iconCircle.setOpaque(false);

        JPanel hTexts = new JPanel(new GridLayout(2, 1, 0, 4)); hTexts.setOpaque(false);
        hTexts.setBorder(BorderFactory.createEmptyBorder(18, 16, 18, 28));
        JLabel titleLbl = UITheme.label(title, UITheme.font(Font.BOLD, 22), Color.WHITE);
        JLabel subLbl = UITheme.label(subtitle, UITheme.font(Font.PLAIN, 12), new Color(186, 230, 253));
        hTexts.add(titleLbl);
        hTexts.add(subLbl);

        JPanel leftSide = new JPanel(new BorderLayout());
        leftSide.setOpaque(false);
        leftSide.add(iconCircle, BorderLayout.WEST);
        leftSide.add(hTexts, BorderLayout.CENTER);
        headerBanner.add(leftSide, BorderLayout.WEST);

        // Content area with sky-blue tinted background
        JPanel content = new JPanel(new BorderLayout(0, 14));
        content.setBackground(new Color(240, 249, 255));
        content.setBorder(BorderFactory.createEmptyBorder(20, 28, 20, 28));

        DefaultTableModel model = new DefaultTableModel(cols, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };
        JTable table = new JTable(model);
        UITheme.styleTable(table);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        JScrollPane sp = UITheme.scrollPane(table);
        sp.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(186, 230, 253), 1),
            BorderFactory.createEmptyBorder(0, 0, 0, 0)));
        sp.getViewport().setBackground(Color.WHITE);

        JPanel btnRow = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        btnRow.setOpaque(false);

        content.add(sp, BorderLayout.CENTER);
        content.add(btnRow, BorderLayout.SOUTH);

        panel.add(headerBanner, BorderLayout.NORTH);
        panel.add(content, BorderLayout.CENTER);
        return panel;
    }

    private String getMgmtSymbol(String title) {
        if (title == null) return "\u25CF";
        String t = title.toLowerCase();
        if (t.contains("student"))    return "\uD83D\uDC64"; // 👤
        if (t.contains("teacher") || t.contains("faculty")) return "\uD83D\uDC68\u200D\uD83C\uDFEB"; // 👨‍🏫
        if (t.contains("course"))     return "\uD83D\uDCDA"; // 📚
        if (t.contains("grade"))      return "\u2B50"; // ⭐
        if (t.contains("fee"))        return "\uD83D\uDCB0"; // 💰
        if (t.contains("admin"))      return "\u2699"; // ⚙
        if (t.contains("announce"))   return "\uD83D\uDCE2"; // 📢
        if (t.contains("assign"))     return "\uD83D\uDCCB"; // 📋
        if (t.contains("report"))     return "\uD83D\uDCCA"; // 📊
        return "\uD83D\uDCCA"; // 📊
    }

    private JTable extractTable(JPanel panel) {
        JPanel content = (JPanel)((BorderLayout)panel.getLayout()).getLayoutComponent(BorderLayout.CENTER);
        JScrollPane sp = (JScrollPane)((BorderLayout)content.getLayout()).getLayoutComponent(BorderLayout.CENTER);
        return (JTable) sp.getViewport().getView();
    }

    private JPanel extractBtnRow(JPanel panel) {
        JPanel content = (JPanel)((BorderLayout)panel.getLayout()).getLayoutComponent(BorderLayout.CENTER);
        return (JPanel)((BorderLayout)content.getLayout()).getLayoutComponent(BorderLayout.SOUTH);
    }

    private void buildFormDialog(String title, String[] fieldNames,
                                 Map<String, JTextField> fieldMap, Runnable onSave) {
        buildFormDialogPrefilled(title, fieldNames, null, fieldMap, onSave);
    }

    private void buildFormDialogPrefilled(String title, String[] fieldNames,
                                          String[] defaults,
                                          Map<String, JTextField> fieldMap,
                                          Runnable onSave) {
        JDialog dlg = new JDialog(this, title, true);
        dlg.setSize(460, Math.min(fieldNames.length * 60 + 150, 600));
        dlg.setLocationRelativeTo(this);
        dlg.setLayout(new BorderLayout(10, 10));
        dlg.getRootPane().setBorder(BorderFactory.createEmptyBorder(16, 20, 16, 20));
        dlg.getContentPane().setBackground(UITheme.CARD_BG);

        JPanel form = new JPanel(new GridBagLayout());
        form.setBackground(UITheme.CARD_BG);
        form.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets  = new Insets(8, 8, 8, 8);
        gbc.anchor  = GridBagConstraints.WEST;
        gbc.fill    = GridBagConstraints.HORIZONTAL;

        for (int i = 0; i < fieldNames.length; i++) {
            gbc.gridx = 0; gbc.gridy = i; gbc.weightx = 0;
            form.add(UITheme.label(fieldNames[i] + ":", UITheme.boldFont(), UITheme.TEXT_DARK), gbc);
            gbc.gridx = 1; gbc.weightx = 1;
            JTextField tf = UITheme.styledField();
            if (defaults != null && i < defaults.length) tf.setText(defaults[i]);
            fieldMap.put(fieldNames[i], tf);
            form.add(tf, gbc);
        }

        JPanel btnRow = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        btnRow.setBackground(UITheme.CARD_BG);
        JButton save   = UITheme.accentButton("Save");
        JButton cancel = UITheme.ghostButton("Cancel");

        save.addActionListener(e -> {
            for (String name : fieldNames) {
                String lower = name.toLowerCase();
                boolean optional = lower.contains("phone") || lower.contains("address")
                        || lower.contains("(or") || lower.contains("optional");
                if (!optional && fieldMap.get(name).getText().trim().isEmpty()) {
                    JOptionPane.showMessageDialog(dlg, "Please fill in: " + name);
                    return;
                }
            }
            dlg.dispose();
            onSave.run();
        });
        cancel.addActionListener(e -> dlg.dispose());
        btnRow.add(cancel); btnRow.add(save);

        JLabel titleLbl = UITheme.label(title, UITheme.headingFont(), UITheme.PRIMARY);
        titleLbl.setBorder(BorderFactory.createEmptyBorder(0, 0, 8, 0));
        dlg.add(titleLbl, BorderLayout.NORTH);
        dlg.add(new JScrollPane(form), BorderLayout.CENTER);
        dlg.add(btnRow, BorderLayout.SOUTH);
        dlg.setVisible(true);
    }
}
