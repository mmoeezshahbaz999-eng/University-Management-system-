package gui;

import models.*;
import utils.DataManager;
import utils.UITheme;

import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;
import java.util.*;
import java.util.List;

public class TeacherDashboard extends BaseDashboard {

    private Teacher teacher;

    public TeacherDashboard(Teacher teacher) {
        super(teacher, "Teacher Portal - " + teacher.getName());
        this.teacher = teacher;
        showDefaultPanel();
    }

    @Override
    protected void addNavigationItems() {
        addNavButton("home", "Dashboard",    this::showDashboard);
        addNavButton("courses", "My Courses",   this::showMyCourses);
        addNavButton("students",    "Students",     this::showStudents);
        addNavButton("gradeentry",  "Grade Entry",  this::showGradeEntry);
        addNavButton("assignments", "Assignments",  this::showAssignments);
        addNavButton("announcements", "Announcements",this::showAnnouncements);
        addNavButton("profile", "Profile",      this::showProfile);
    }

    @Override
    protected void showDefaultPanel() { showDashboard(); }

    
    
    
    private void showDashboard() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(UITheme.CONTENT_BG);

        
        JPanel headerBanner = new JPanel(new BorderLayout()) {
            @Override protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                GradientPaint gp = new GradientPaint(0, 0, new Color(4, 90, 75), getWidth(), 0, new Color(5, 140, 115));
                g2.setPaint(gp); g2.fillRect(0, 0, getWidth(), getHeight());
                g2.setColor(new Color(255,255,255,10));
                g2.fillOval(getWidth()-160,-40,190,190);
                g2.fillOval(getWidth()-80,15,100,100);
                
                g2.setColor(new Color(255,255,255,7));
                g2.fillRoundRect(getWidth()-250, 14, 42, 56, 4, 4);
                g2.fillRoundRect(getWidth()-200, 10, 42, 56, 4, 4);
                g2.fillRect(getWidth()-310, 50, 52, 7);
                g2.fillRoundRect(getWidth()-300, 36, 32, 18, 4, 4);
                g2.dispose();
            }
        };
        headerBanner.setPreferredSize(new Dimension(0, 92));
        headerBanner.setBorder(BorderFactory.createEmptyBorder(18, 30, 18, 30));
        JPanel hTexts = new JPanel(new GridLayout(2,1,0,5)); hTexts.setOpaque(false);
        hTexts.add(UITheme.label("Welcome, " + teacher.getName() + "!", UITheme.font(Font.BOLD, 24), Color.WHITE));
        hTexts.add(UITheme.label(teacher.getDesignation() + "  \u2022  " + teacher.getDepartment(), UITheme.font(Font.PLAIN, 13), new Color(190, 235, 225)));
        headerBanner.add(hTexts, BorderLayout.WEST);

        
        List<Course> myCourses = new ArrayList<>();
        for (Course c : DataManager.loadCourses())
            if (c.getTeacherId().equalsIgnoreCase(teacher.getId())) myCourses.add(c);
        int totalStudents = 0;
        for (Course c : myCourses) totalStudents += DataManager.getStudentsInCourse(c.getCourseId()).size();

        JPanel statsRow = new JPanel(new GridLayout(1, 3, 16, 0));
        statsRow.setOpaque(false);
        statsRow.setBorder(BorderFactory.createEmptyBorder(20, 26, 16, 26));
        statsRow.add(UITheme.statCard(String.valueOf(myCourses.size()), "My Courses",    UITheme.TEAL,      "#"));
        statsRow.add(UITheme.statCard(String.valueOf(totalStudents),     "Total Students", UITheme.SECONDARY, ">>"));
        statsRow.add(UITheme.statCard(teacher.getDepartment(),           "Department",    UITheme.ACCENT,    ""));

        
        JPanel courseSection = new JPanel(new BorderLayout(0, 12));
        courseSection.setOpaque(false);
        courseSection.setBorder(BorderFactory.createEmptyBorder(4, 26, 14, 26));
        courseSection.add(UITheme.sectionHeader("My Assigned Courses"), BorderLayout.NORTH);

        JPanel courseList = new JPanel(new GridLayout(0, 2, 16, 16));
        courseList.setOpaque(false);
        Color[] cardColors = {UITheme.TEAL, UITheme.SECONDARY, UITheme.SUCCESS, UITheme.PURPLE, UITheme.ACCENT};
        int ci = 0;
        for (Course c : myCourses) courseList.add(buildTeacherCourseCard(c, cardColors[ci++ % cardColors.length]));
        if (myCourses.isEmpty()) courseList.add(UITheme.label("No courses assigned yet.", UITheme.bodyFont(), UITheme.TEXT_MUTED));
        courseSection.add(courseList, BorderLayout.CENTER);

        
        JPanel annSection = new JPanel(new BorderLayout(0, 12));
        annSection.setOpaque(false);
        annSection.setBorder(BorderFactory.createEmptyBorder(4, 26, 26, 26));
        annSection.add(UITheme.sectionHeader("My Recent Announcements"), BorderLayout.NORTH);

        JPanel annList = new JPanel();
        annList.setLayout(new BoxLayout(annList, BoxLayout.Y_AXIS));
        annList.setOpaque(false);
        int cnt = 0;
        for (Announcement a : DataManager.loadAnnouncements()) {
            if (a.getAuthorId().equalsIgnoreCase(teacher.getId()) && cnt < 3) {
                annList.add(buildAnnCard(a)); annList.add(Box.createVerticalStrut(8)); cnt++;
            }
        }
        if (cnt == 0) annList.add(UITheme.label("No announcements yet.", UITheme.bodyFont(), UITheme.TEXT_MUTED));
        annSection.add(annList, BorderLayout.CENTER);

        JPanel main = new JPanel();
        main.setLayout(new BoxLayout(main, BoxLayout.Y_AXIS));
        main.setOpaque(false);
        main.add(statsRow);
        main.add(courseSection);
        main.add(annSection);

        JScrollPane sp = new JScrollPane(main);
        sp.setBorder(null);
        sp.getViewport().setBackground(UITheme.CONTENT_BG);

        panel.add(headerBanner, BorderLayout.NORTH);
        panel.add(sp, BorderLayout.CENTER);
        showContent(panel);
    }

    private JPanel buildTeacherCourseCard(Course c, Color accent) {
        JPanel card = new JPanel(new BorderLayout(0, 8)) {
            @Override protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(new Color(0,0,0,8));
                g2.fillRoundRect(2,2,getWidth()-2,getHeight()-2,14,14);
                g2.setColor(Color.WHITE);
                g2.fillRoundRect(0,0,getWidth()-2,getHeight()-2,14,14);
                g2.setColor(accent);
                g2.fillRoundRect(0,0,getWidth()-2,5,4,4);
                g2.dispose();
            }
        };
        card.setOpaque(false);
        card.setBorder(BorderFactory.createEmptyBorder(16, 16, 14, 16));

        int stuCount = DataManager.getStudentsInCourse(c.getCourseId()).size();

        JLabel idLbl   = UITheme.label(c.getCourseId(), UITheme.font(Font.BOLD, 10), accent);
        JLabel nameLbl = UITheme.label(c.getCourseName(), UITheme.subheadFont(), UITheme.TEXT_DARK);
        nameLbl.setBorder(BorderFactory.createEmptyBorder(4,0,4,0));
        JLabel schedLbl = UITheme.label(" " + c.getSchedule() + "    " + c.getRoom(), UITheme.smallFont(), UITheme.TEXT_MUTED);
        JLabel stuLbl  = UITheme.label(">> " + stuCount + " / " + c.getCapacity() + " students", UITheme.font(Font.BOLD, 11), accent);

        JPanel body = new JPanel();
        body.setLayout(new BoxLayout(body, BoxLayout.Y_AXIS));
        body.setOpaque(false);
        body.add(idLbl); body.add(nameLbl); body.add(schedLbl);
        body.add(Box.createVerticalStrut(6)); body.add(stuLbl);

        card.add(body, BorderLayout.CENTER);
        return card;
    }

    private JPanel buildAnnCard(Announcement a) {
        Color pc = a.getPriority().equals("HIGH") ? UITheme.DANGER :
                   a.getPriority().equals("MEDIUM") ? UITheme.WARNING : UITheme.SUCCESS;
        JPanel card = new JPanel(new BorderLayout(0, 4)) {
            @Override protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(new Color(0,0,0,6));
                g2.fillRoundRect(2,2,getWidth()-2,getHeight()-2,12,12);
                g2.setColor(Color.WHITE);
                g2.fillRoundRect(0,0,getWidth()-2,getHeight()-2,12,12);
                g2.setColor(pc);
                g2.fillRoundRect(0,0,5,getHeight()-2,4,4);
                g2.dispose();
            }
        };
        card.setMaximumSize(new Dimension(Integer.MAX_VALUE, 74));
        card.setOpaque(false);
        card.setBorder(BorderFactory.createEmptyBorder(12, 16, 12, 14));
        JPanel hdr = new JPanel(new BorderLayout()); hdr.setOpaque(false);
        hdr.add(UITheme.label(a.getTitle(), UITheme.boldFont(), UITheme.TEXT_DARK), BorderLayout.WEST);
        hdr.add(UITheme.label(a.getDateTime(), UITheme.smallFont(), UITheme.TEXT_MUTED), BorderLayout.EAST);
        card.add(hdr, BorderLayout.NORTH);
        card.add(UITheme.label(a.getContent(), UITheme.captionFont(), UITheme.TEXT_MEDIUM), BorderLayout.CENTER);
        return card;
    }

    
    
    
    private void showMyCourses() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(UITheme.CONTENT_BG);

        JPanel headerBanner = buildSectionHeader("\uD83D\uDCDA  My Courses", "All courses assigned to you this semester", new Color(4,90,75), new Color(5,140,115));

        JPanel content = new JPanel(new BorderLayout(0,0));
        content.setOpaque(false);
        content.setBorder(BorderFactory.createEmptyBorder(20,26,20,26));

        List<Course> myCourses = new ArrayList<>();
        for (Course c : DataManager.loadCourses())
            if (c.getTeacherId().equalsIgnoreCase(teacher.getId())) myCourses.add(c);

        String[] cols = {"Course ID","Course Name","Schedule","Room","Credits","Enrolled","Capacity","Semester"};
        DefaultTableModel model = new DefaultTableModel(cols, 0) { public boolean isCellEditable(int r,int c){ return false; } };
        for (Course c : myCourses)
            model.addRow(new Object[]{c.getCourseId(), c.getCourseName(), c.getSchedule(), c.getRoom(),
                    c.getCreditHours(), c.getEnrolled(), c.getCapacity(), c.getSemester()});
        JTable table = new JTable(model);
        UITheme.styleTable(table);
        content.add(UITheme.scrollPane(table), BorderLayout.CENTER);

        panel.add(headerBanner, BorderLayout.NORTH);
        panel.add(content, BorderLayout.CENTER);
        showContent(panel);
    }

    
    
    
    private void showStudents() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(UITheme.CONTENT_BG);

        JPanel headerBanner = buildSectionHeader("\uD83D\uDC65  Students", "Students enrolled in your courses", new Color(4,90,75), new Color(5,140,115));

        JPanel content = new JPanel(new BorderLayout(0,12));
        content.setOpaque(false);
        content.setBorder(BorderFactory.createEmptyBorder(16,26,20,26));

        List<Course> myCourses = new ArrayList<>();
        for (Course c : DataManager.loadCourses())
            if (c.getTeacherId().equalsIgnoreCase(teacher.getId())) myCourses.add(c);

        String[] courseNames = myCourses.stream().map(Course::toString).toArray(String[]::new);
        JComboBox<String> courseCombo = UITheme.styledCombo(courseNames.length > 0 ? courseNames : new String[]{"No courses assigned"});

        JPanel filterRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        filterRow.setOpaque(false);
        filterRow.add(UITheme.label("Filter by Course:", UITheme.boldFont(), UITheme.TEXT_DARK));
        filterRow.add(courseCombo);

        String[] cols = {"Student ID","Name","Email","Major","Year","GPA"};
        DefaultTableModel model = new DefaultTableModel(cols, 0) { public boolean isCellEditable(int r,int c){ return false; } };

        Runnable refresh = () -> {
            model.setRowCount(0);
            int idx = courseCombo.getSelectedIndex();
            if (idx < 0 || idx >= myCourses.size()) return;
            Course selected = myCourses.get(idx);
            for (String sid : DataManager.getStudentsInCourse(selected.getCourseId())) {
                Student s = DataManager.findStudentById(sid);
                if (s == null) continue;
                List<Grade> g = DataManager.getGradesForStudent(sid);
                double gpa = g.isEmpty() ? 0 : g.stream().mapToDouble(Grade::getGpaPoints).average().orElse(0);
                model.addRow(new Object[]{s.getId(), s.getName(), s.getEmail(), s.getMajor(),
                        s.getYear(), String.format("%.2f", gpa)});
            }
        };
        courseCombo.addActionListener(e -> refresh.run());

        JTable table = new JTable(model);
        UITheme.styleTable(table);

        content.add(filterRow, BorderLayout.NORTH);
        content.add(UITheme.scrollPane(table), BorderLayout.CENTER);

        panel.add(headerBanner, BorderLayout.NORTH);
        panel.add(content, BorderLayout.CENTER);
        showContent(panel);
        if (!myCourses.isEmpty()) { courseCombo.setSelectedIndex(0); refresh.run(); }
    }

    
    
    
    private void showGradeEntry() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(UITheme.CONTENT_BG);

        JPanel headerBanner = buildSectionHeader("\u2B50  Grade Entry", "Enter and manage student grades", new Color(109,40,217), new Color(79,70,229));

        JPanel content = new JPanel(new BorderLayout(0,12));
        content.setOpaque(false);
        content.setBorder(BorderFactory.createEmptyBorder(16,26,20,26));

        List<Course> myCourses = new ArrayList<>();
        for (Course c : DataManager.loadCourses())
            if (c.getTeacherId().equalsIgnoreCase(teacher.getId())) myCourses.add(c);

        String[] courseNames = myCourses.stream().map(Course::toString).toArray(String[]::new);
        JComboBox<String> courseCombo = UITheme.styledCombo(courseNames.length > 0 ? courseNames : new String[]{"No courses assigned"});

        String[] cols = {"Student ID","Name","Assignment (100)","Midterm (100)","Final (100)","Total","Grade"};
        DefaultTableModel model = new DefaultTableModel(cols, 0) {
            public boolean isCellEditable(int r, int c) { return c == 2 || c == 3 || c == 4; }
        };
        final Course[] selectedCourse = {myCourses.isEmpty() ? null : myCourses.get(0)};

        Runnable load = () -> {
            model.setRowCount(0);
            int idx = courseCombo.getSelectedIndex();
            if (idx < 0 || idx >= myCourses.size()) return;
            selectedCourse[0] = myCourses.get(idx);
            for (String sid : DataManager.getStudentsInCourse(selectedCourse[0].getCourseId())) {
                Student s = DataManager.findStudentById(sid);
                if (s == null) continue;
                Grade g = null;
                for (Grade gr : DataManager.getGradesForStudent(sid))
                    if (gr.getCourseId().equalsIgnoreCase(selectedCourse[0].getCourseId())) { g = gr; break; }
                if (g != null)
                    model.addRow(new Object[]{s.getId(), s.getName(), g.getAssignment1(), g.getMidterm(),
                            g.getFinalProject(), String.format("%.1f", g.getTotal()), g.getLetterGrade()});
                else
                    model.addRow(new Object[]{s.getId(), s.getName(), 0.0, 0.0, 0.0, "0.0", "F"});
            }
        };
        courseCombo.addActionListener(e -> load.run());

        JTable table = new JTable(model);
        UITheme.styleTable(table);
        table.getColumnModel().getColumn(2).setPreferredWidth(130);
        table.getColumnModel().getColumn(3).setPreferredWidth(130);
        table.getColumnModel().getColumn(4).setPreferredWidth(130);

        JButton saveBtn = UITheme.successButton("Save Grades");
        saveBtn.addActionListener(e -> {
            if (selectedCourse[0] == null) return;
            for (int r = 0; r < model.getRowCount(); r++) {
                try {
                    String sid = (String) model.getValueAt(r, 0);
                    double a1 = Double.parseDouble(model.getValueAt(r, 2).toString());
                    double mt = Double.parseDouble(model.getValueAt(r, 3).toString());
                    double fp = Double.parseDouble(model.getValueAt(r, 4).toString());
                    Grade g = new Grade(DataManager.generateGradeId(), sid,
                            selectedCourse[0].getCourseId(), selectedCourse[0].getCourseName(),
                            a1, mt, fp, selectedCourse[0].getSemester());
                    DataManager.addOrUpdateGrade(g);
                    model.setValueAt(String.format("%.1f", g.getTotal()), r, 5);
                    model.setValueAt(g.getLetterGrade(), r, 6);
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(this, "Invalid grade at row " + (r+1));
                    return;
                }
            }
            JOptionPane.showMessageDialog(this, "Grades saved successfully!");
        });

        JPanel filterRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        filterRow.setOpaque(false);
        filterRow.add(UITheme.label("Course:", UITheme.boldFont(), UITheme.TEXT_DARK));
        filterRow.add(courseCombo);
        filterRow.add(saveBtn);

        content.add(filterRow, BorderLayout.NORTH);
        content.add(UITheme.scrollPane(table), BorderLayout.CENTER);

        panel.add(headerBanner, BorderLayout.NORTH);
        panel.add(content, BorderLayout.CENTER);
        showContent(panel);
        if (!myCourses.isEmpty()) { courseCombo.setSelectedIndex(0); load.run(); }
    }

    
    
    
    private void showAssignments() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(UITheme.CONTENT_BG);

        JPanel headerBanner = buildSectionHeader("\uD83D\uDCCB  Assignments",
                "Post and manage assignments for your courses",
                new Color(109, 40, 217), new Color(79, 70, 229));

        JButton btnPost = UITheme.primaryButton("+ Post Assignment");
        btnPost.addActionListener(e -> showPostAssignmentDialog());
        JPanel btnWrap = new JPanel(new FlowLayout(FlowLayout.RIGHT, 0, 0));
        btnWrap.setOpaque(false);
        btnWrap.add(btnPost);
        headerBanner.add(btnWrap, BorderLayout.EAST);

        JPanel content = new JPanel(new BorderLayout(0, 0));
        content.setOpaque(false);
        content.setBorder(BorderFactory.createEmptyBorder(20, 26, 20, 26));

        String[] cols = {"Course", "Assignment Title", "Due Date", "Total Marks", "Submissions", "Description"};
        List<models.Assignment> asnList = DataManager.getAssignmentsForTeacher(teacher.getId());
        DefaultTableModel model = new DefaultTableModel(cols, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };
        for (models.Assignment a : asnList) {
            int subCount = utils.DataManager.getSubmissionsForAssignment(a.getAssignmentId()).size();
            model.addRow(new Object[]{
                a.getCourseId(), a.getTitle(), a.getDueDate(),
                a.getTotalMarks() + " pts", subCount + " submitted", a.getDescription()
            });
        }
        if (asnList.isEmpty()) {
            model.addRow(new Object[]{"—", "No assignments posted yet.", "—", "—", "—", "—"});
        }

        JTable table = new JTable(model);
        UITheme.styleTable(table);

        JPopupMenu popup = new JPopupMenu();
        JMenuItem viewSubsItem = new JMenuItem("View Submissions");
        JMenuItem deleteItem   = new JMenuItem("Delete Assignment");

        viewSubsItem.addActionListener(e -> {
            int row = table.getSelectedRow();
            if (row >= 0 && !asnList.isEmpty()) showSubmissionsDialog(asnList.get(row));
        });
        deleteItem.addActionListener(e -> {
            int row = table.getSelectedRow();
            if (row >= 0 && !asnList.isEmpty()) {
                int confirm = JOptionPane.showConfirmDialog(this,
                        "Delete this assignment?", "Confirm", JOptionPane.YES_NO_OPTION);
                if (confirm == JOptionPane.YES_OPTION) {
                    DataManager.deleteAssignment(asnList.get(row).getAssignmentId());
                    showAssignments();
                }
            }
        });
        popup.add(viewSubsItem);
        popup.addSeparator();
        popup.add(deleteItem);
        table.setComponentPopupMenu(popup);

        JPanel btnBar = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        btnBar.setOpaque(false);
        btnBar.setBorder(BorderFactory.createEmptyBorder(12, 0, 0, 0));
        JButton viewSubsBtn = UITheme.ghostButton("📋  View Submissions");
        viewSubsBtn.addActionListener(e -> {
            int row = table.getSelectedRow();
            if (row < 0 || asnList.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please select an assignment first.", "No Selection", JOptionPane.WARNING_MESSAGE);
                return;
            }
            showSubmissionsDialog(asnList.get(row));
        });
        btnBar.add(viewSubsBtn);

        content.add(UITheme.scrollPane(table), BorderLayout.CENTER);
        content.add(btnBar, BorderLayout.SOUTH);
        panel.add(headerBanner, BorderLayout.NORTH);
        panel.add(content, BorderLayout.CENTER);
        showContent(panel);
    }

    private void showSubmissionsDialog(models.Assignment asn) {
        JDialog dlg = new JDialog(this, "Submissions — " + asn.getTitle(), true);
        dlg.setSize(720, 480);
        dlg.setLocationRelativeTo(this);
        dlg.getContentPane().setBackground(UITheme.CARD_BG);
        dlg.setLayout(new BorderLayout());

        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(new Color(109, 40, 217));
        header.setBorder(BorderFactory.createEmptyBorder(14, 22, 14, 22));
        JLabel title = new JLabel(asn.getTitle());
        title.setFont(UITheme.font(Font.BOLD, 16));
        title.setForeground(Color.WHITE);
        JLabel subLbl = new JLabel("Course: " + asn.getCourseId() + "   |   Due: " + asn.getDueDate() + "   |   Total Marks: " + asn.getTotalMarks());
        subLbl.setFont(UITheme.font(Font.PLAIN, 12));
        subLbl.setForeground(new Color(210, 190, 255));
        JPanel hTexts = new JPanel(new GridLayout(2, 1, 0, 4));
        hTexts.setOpaque(false);
        hTexts.add(title); hTexts.add(subLbl);
        header.add(hTexts);

        List<models.AssignmentSubmission> subs = utils.DataManager.getSubmissionsForAssignment(asn.getAssignmentId());
        String[] sCols = {"Student ID", "Student Name", "Submitted On", "Status", "Attachment", "Marks"};
        DefaultTableModel sModel = new DefaultTableModel(sCols, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };
        for (models.AssignmentSubmission s : subs) {
            String marks = s.getMarksObtained() >= 0 ? String.valueOf(s.getMarksObtained()) : "Not graded";
            sModel.addRow(new Object[]{s.getStudentId(), s.getStudentName(), s.getSubmittedOn(),
                                       s.getStatus(), s.getFileName().isEmpty() ? "—" : s.getFileName(), marks});
        }
        if (subs.isEmpty()) {
            sModel.addRow(new Object[]{"—", "No submissions yet.", "—", "—", "—", "—"});
        }
        JTable sTable = new JTable(sModel);
        UITheme.styleTable(sTable);

        JPanel btnBar2 = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 8));
        btnBar2.setBackground(UITheme.CARD_BG);

        JButton viewAnswerBtn = UITheme.ghostButton("View Answer");
        JButton gradeBtn      = UITheme.primaryButton("Grade Selected");
        JButton closeBtn      = UITheme.ghostButton("Close");

        viewAnswerBtn.addActionListener(e -> {
            int row = sTable.getSelectedRow();
            if (row < 0 || subs.isEmpty()) return;
            models.AssignmentSubmission s = subs.get(row);
            JTextArea area = new JTextArea(s.getSubmittedText(), 10, 40);
            area.setEditable(false); area.setLineWrap(true); area.setWrapStyleWord(true);
            area.setFont(UITheme.font(Font.PLAIN, 13));
            JOptionPane.showMessageDialog(dlg, new JScrollPane(area), "Answer — " + s.getStudentName(), JOptionPane.PLAIN_MESSAGE);
        });

        gradeBtn.addActionListener(e -> {
            int row = sTable.getSelectedRow();
            if (row < 0 || subs.isEmpty()) {
                JOptionPane.showMessageDialog(dlg, "Select a submission to grade.", "No Selection", JOptionPane.WARNING_MESSAGE);
                return;
            }
            models.AssignmentSubmission s = subs.get(row);
            String input = JOptionPane.showInputDialog(dlg,
                "Enter marks for " + s.getStudentName() + " (out of " + asn.getTotalMarks() + "):",
                s.getMarksObtained() >= 0 ? String.valueOf(s.getMarksObtained()) : "");
            if (input == null) return;
            try {
                int marks = Integer.parseInt(input.trim());
                if (marks < 0 || marks > asn.getTotalMarks()) {
                    JOptionPane.showMessageDialog(dlg, "Marks must be 0–" + asn.getTotalMarks(), "Invalid", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                s.setMarksObtained(marks);
                s.setStatus("Graded");
                utils.DataManager.updateSubmission(s);
                sModel.setValueAt("Graded", row, 3);
                sModel.setValueAt(String.valueOf(marks), row, 5);
                JOptionPane.showMessageDialog(dlg, "Marks saved!", "Graded", JOptionPane.INFORMATION_MESSAGE);
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(dlg, "Please enter a valid number.", "Invalid", JOptionPane.ERROR_MESSAGE);
            }
        });

        closeBtn.addActionListener(e -> { dlg.dispose(); showAssignments(); });

        btnBar2.add(viewAnswerBtn);
        btnBar2.add(gradeBtn);
        btnBar2.add(closeBtn);

        JPanel tableWrap = new JPanel(new BorderLayout());
        tableWrap.setBackground(UITheme.CARD_BG);
        tableWrap.setBorder(BorderFactory.createEmptyBorder(16, 22, 0, 22));
        tableWrap.add(UITheme.scrollPane(sTable), BorderLayout.CENTER);

        dlg.add(header, BorderLayout.NORTH);
        dlg.add(tableWrap, BorderLayout.CENTER);
        dlg.add(btnBar2, BorderLayout.SOUTH);
        dlg.setVisible(true);
    }

    private void showPostAssignmentDialog() {
        
        List<Course> myCourses = new ArrayList<>();
        for (String cid : DataManager.getEnrolledCourseIds("")) {}
        for (Course c : DataManager.loadCourses())
            if (c.getTeacherId().equalsIgnoreCase(teacher.getId())) myCourses.add(c);

        if (myCourses.isEmpty()) {
            JOptionPane.showMessageDialog(this, "You have no courses assigned.", "Info", JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        JDialog dlg = new JDialog(this, "Post New Assignment", true);
        dlg.setSize(500, 400);
        dlg.setLocationRelativeTo(this);
        dlg.setLayout(new BorderLayout());

        JPanel form = new JPanel(new GridBagLayout());
        form.setBorder(BorderFactory.createEmptyBorder(20, 24, 10, 24));
        form.setBackground(UITheme.CARD_BG);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(6, 6, 6, 6);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        
        String[] courseNames = new String[myCourses.size()];
        for (int i = 0; i < myCourses.size(); i++)
            courseNames[i] = myCourses.get(i).getCourseId() + " – " + myCourses.get(i).getCourseName();
        JComboBox<String> courseBox = UITheme.styledCombo(courseNames);

        JTextField titleField   = UITheme.styledField();
        JTextField dueDateField = UITheme.styledField();
        JTextField marksField   = UITheme.styledField();
        JTextArea  descArea     = new JTextArea(4, 30);
        descArea.setFont(UITheme.bodyFont());
        descArea.setLineWrap(true);
        descArea.setWrapStyleWord(true);
        descArea.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(UITheme.BORDER_COLOR),
            BorderFactory.createEmptyBorder(6, 8, 6, 8)));

        int r = 0;
        gbc.gridx = 0; gbc.gridy = r; gbc.weightx = 0.3; form.add(UITheme.label("Course:", UITheme.bodyFont(), UITheme.TEXT_DARK), gbc);
        gbc.gridx = 1; gbc.weightx = 0.7; form.add(courseBox, gbc);
        r++;
        gbc.gridx = 0; gbc.gridy = r; gbc.weightx = 0.3; form.add(UITheme.label("Title:", UITheme.bodyFont(), UITheme.TEXT_DARK), gbc);
        gbc.gridx = 1; gbc.weightx = 0.7; form.add(titleField, gbc);
        r++;
        gbc.gridx = 0; gbc.gridy = r; gbc.weightx = 0.3; form.add(UITheme.label("Due Date:", UITheme.bodyFont(), UITheme.TEXT_DARK), gbc);
        gbc.gridx = 1; gbc.weightx = 0.7; form.add(dueDateField, gbc);
        r++;
        gbc.gridx = 0; gbc.gridy = r; gbc.weightx = 0.3; form.add(UITheme.label("Total Marks:", UITheme.bodyFont(), UITheme.TEXT_DARK), gbc);
        gbc.gridx = 1; gbc.weightx = 0.7; form.add(marksField, gbc);
        r++;
        gbc.gridx = 0; gbc.gridy = r; gbc.weightx = 0.3; form.add(UITheme.label("Description:", UITheme.bodyFont(), UITheme.TEXT_DARK), gbc);
        gbc.gridx = 1; gbc.weightx = 0.7; form.add(new JScrollPane(descArea), gbc);

        JButton saveBtn = UITheme.primaryButton("Post Assignment");
        saveBtn.addActionListener(e -> {
            String title   = titleField.getText().trim();
            String due     = dueDateField.getText().trim();
            String marksStr= marksField.getText().trim();
            String desc    = descArea.getText().trim();
            int idx        = courseBox.getSelectedIndex();
            if (title.isEmpty() || due.isEmpty() || marksStr.isEmpty() || desc.isEmpty()) {
                JOptionPane.showMessageDialog(dlg, "Please fill all fields.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            int marks;
            try { marks = Integer.parseInt(marksStr); } catch (Exception ex) {
                JOptionPane.showMessageDialog(dlg, "Total marks must be a number.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            Course selected = myCourses.get(idx);
            String now = java.time.LocalDateTime.now()
                    .format(java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm"));
            models.Assignment asn = new models.Assignment(
                    DataManager.generateAssignmentId(),
                    selected.getCourseId(), selected.getCourseName(),
                    teacher.getId(), teacher.getName(),
                    title, desc, due, marks, selected.getSemester(), now);
            DataManager.addAssignment(asn);
            dlg.dispose();
            JOptionPane.showMessageDialog(this, "Assignment posted successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
            showAssignments();
        });

        JPanel btnRow = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        btnRow.setBackground(UITheme.CARD_BG);
        btnRow.add(saveBtn);

        dlg.add(form, BorderLayout.CENTER);
        dlg.add(btnRow, BorderLayout.SOUTH);
        dlg.setVisible(true);
    }

    
    
    
    private void showAnnouncements() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(UITheme.CONTENT_BG);

        JPanel headerBanner = buildSectionHeader("\uD83D\uDCE2  Announcements", "Post and manage course announcements", new Color(109,40,217), new Color(79,70,229));
        JButton addBtn = UITheme.accentButton("+ New Announcement");
        addBtn.addActionListener(e -> showAddAnnDialog());
        JPanel btnWrap = new JPanel(new FlowLayout(FlowLayout.RIGHT,0,0)); btnWrap.setOpaque(false);
        btnWrap.add(addBtn);
        headerBanner.add(btnWrap, BorderLayout.EAST);

        JPanel content = new JPanel(new BorderLayout(0,0));
        content.setOpaque(false);
        content.setBorder(BorderFactory.createEmptyBorder(16,26,20,26));

        JPanel list = new JPanel();
        list.setLayout(new BoxLayout(list, BoxLayout.Y_AXIS));
        list.setOpaque(false);

        boolean any = false;
        for (Announcement a : DataManager.loadAnnouncements()) {
            if (!a.getAuthorId().equalsIgnoreCase(teacher.getId())) continue;
            any = true;
            JPanel card = buildAnnCard(a);
            card.setMaximumSize(new Dimension(Integer.MAX_VALUE, 80));
            JPanel row = new JPanel(new BorderLayout(10, 0));
            row.setOpaque(false);
            JButton del = UITheme.dangerButton("Del");
            del.setFont(UITheme.smallFont());
            del.addActionListener(e -> { DataManager.deleteAnnouncement(a.getAnnouncementId()); showAnnouncements(); });
            row.add(card, BorderLayout.CENTER);
            row.add(del, BorderLayout.EAST);
            list.add(row);
            list.add(Box.createVerticalStrut(10));
        }
        if (!any) list.add(UITheme.label("No announcements posted yet.", UITheme.bodyFont(), UITheme.TEXT_MUTED));

        JScrollPane sp = new JScrollPane(list);
        sp.setBorder(null); sp.getViewport().setBackground(UITheme.CONTENT_BG);
        content.add(sp, BorderLayout.CENTER);

        panel.add(headerBanner, BorderLayout.NORTH);
        panel.add(content, BorderLayout.CENTER);
        showContent(panel);
    }

    private void showAddAnnDialog() {
        List<Course> myCourses = new ArrayList<>();
        for (Course c : DataManager.loadCourses())
            if (c.getTeacherId().equalsIgnoreCase(teacher.getId())) myCourses.add(c);

        JDialog dlg = new JDialog(this, "New Announcement", true);
        dlg.setSize(490, 400);
        dlg.setLocationRelativeTo(this);
        dlg.setLayout(new BorderLayout(0, 10));
        dlg.getRootPane().setBorder(BorderFactory.createEmptyBorder(16, 20, 16, 20));
        dlg.getContentPane().setBackground(UITheme.CARD_BG);

        JTextField titleF = UITheme.styledField();
        JTextArea contentF = new JTextArea(4, 30);
        contentF.setFont(UITheme.bodyFont());
        contentF.setLineWrap(true); contentF.setWrapStyleWord(true);
        contentF.setBackground(new Color(248,250,252));
        contentF.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(UITheme.BORDER_COLOR),
            BorderFactory.createEmptyBorder(8,10,8,10)));

        String[] prios = {"HIGH","MEDIUM","LOW"};
        JComboBox<String> prioCombo = UITheme.styledCombo(prios);

        String[] courseOpts = new String[myCourses.size()+1];
        courseOpts[0] = "Global (All Students)";
        for (int i = 0; i < myCourses.size(); i++) courseOpts[i+1] = myCourses.get(i).toString();
        JComboBox<String> courseCombo = UITheme.styledCombo(courseOpts);

        JPanel form = new JPanel(new GridLayout(0,2,8,12));
        form.setBackground(UITheme.CARD_BG);
        form.add(UITheme.label("Title:", UITheme.boldFont(), UITheme.TEXT_DARK)); form.add(titleF);
        form.add(UITheme.label("Priority:", UITheme.boldFont(), UITheme.TEXT_DARK)); form.add(prioCombo);
        form.add(UITheme.label("Course:", UITheme.boldFont(), UITheme.TEXT_DARK)); form.add(courseCombo);
        form.add(UITheme.label("Content:", UITheme.boldFont(), UITheme.TEXT_DARK)); form.add(new JScrollPane(contentF));

        JPanel btnRow = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        btnRow.setBackground(UITheme.CARD_BG);
        JButton post = UITheme.accentButton("* Post");
        JButton cancel = UITheme.ghostButton("Cancel");
        post.addActionListener(e -> {
            String t = titleF.getText().trim(), cnt = contentF.getText().trim();
            if (t.isEmpty() || cnt.isEmpty()) { JOptionPane.showMessageDialog(dlg, "Fill all fields."); return; }
            String cid = courseCombo.getSelectedIndex() == 0 ? "GLOBAL"
                    : myCourses.get(courseCombo.getSelectedIndex()-1).getCourseId();
            Announcement ann = new Announcement(DataManager.generateAnnouncementId(), t, cnt,
                    teacher.getId(), teacher.getName(), "TEACHER", cid, (String)prioCombo.getSelectedItem());
            DataManager.addAnnouncement(ann);
            dlg.dispose();
            showAnnouncements();
        });
        cancel.addActionListener(e -> dlg.dispose());
        btnRow.add(cancel); btnRow.add(post);

        JLabel title = UITheme.label("*  New Announcement", UITheme.headingFont(), UITheme.PRIMARY);
        title.setBorder(BorderFactory.createEmptyBorder(0,0,8,0));
        dlg.add(title, BorderLayout.NORTH);
        dlg.add(form, BorderLayout.CENTER);
        dlg.add(btnRow, BorderLayout.SOUTH);
        dlg.setVisible(true);
    }

    
    
    
    private void showProfile() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(UITheme.CONTENT_BG);

        JPanel headerBanner = buildSectionHeader("o  My Profile", "Manage your account and personal information", new Color(4,90,75), new Color(5,140,115));

        JPanel content = new JPanel(new BorderLayout(0,16));
        content.setOpaque(false);
        content.setBorder(BorderFactory.createEmptyBorder(24,50,24,50));

        Teacher fresh = DataManager.findTeacherById(teacher.getId());
        if (fresh != null) teacher = fresh;

        
        JPanel twoCol = new JPanel(new GridBagLayout());
        twoCol.setOpaque(false);
        GridBagConstraints tc = new GridBagConstraints();
        tc.anchor = GridBagConstraints.NORTH;
        tc.fill   = GridBagConstraints.BOTH;
        tc.insets = new Insets(0, 0, 0, 16);

        tc.gridx = 0; tc.gridy = 0; tc.weightx = 0.28;
        JPanel picCard = buildProfilePicturePanel(() -> DataManager.updateTeacher(teacher));
        twoCol.add(picCard, tc);

        tc.gridx = 1; tc.weightx = 0.72; tc.insets = new Insets(0, 0, 0, 0);
        JPanel formCard = new JPanel(new GridBagLayout()) {
            @Override protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(new Color(0,0,0,6));
                g2.fillRoundRect(2,2,getWidth()-2,getHeight()-2,14,14);
                g2.setColor(Color.WHITE);
                g2.fillRoundRect(0,0,getWidth()-2,getHeight()-2,14,14);
                g2.dispose();
            }
        };
        formCard.setOpaque(false);
        formCard.setBorder(BorderFactory.createEmptyBorder(28,32,28,32));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10,10,10,10);
        gbc.anchor = GridBagConstraints.WEST;
        gbc.fill   = GridBagConstraints.HORIZONTAL;

        String[][] fields = {
            {"Full Name", teacher.getName()}, {"Teacher ID", teacher.getId()},
            {"Email", teacher.getEmail()},    {"Phone", teacher.getPhone()},
            {"Department", teacher.getDepartment()}, {"Designation", teacher.getDesignation()},
        };
        Map<String, JTextField> fm = new LinkedHashMap<>();
        int row = 0;
        for (String[] f : fields) {
            gbc.gridx = 0; gbc.gridy = row; gbc.weightx = 0;
            formCard.add(UITheme.label(f[0]+": ", UITheme.boldFont(), UITheme.TEXT_DARK), gbc);
            gbc.gridx = 1; gbc.weightx = 1;
            JTextField tf = UITheme.styledField(); tf.setText(f[1]);
            boolean editable = !f[0].equals("Teacher ID");
            tf.setEditable(editable);
            if (!editable) { tf.setBackground(UITheme.CONTENT_BG); tf.setForeground(UITheme.TEXT_MUTED); }
            fm.put(f[0], tf); formCard.add(tf, gbc); row++;
        }
        gbc.gridx = 0; gbc.gridy = row; gbc.weightx = 0;
        formCard.add(UITheme.label("Password:", UITheme.boldFont(), UITheme.TEXT_DARK), gbc);
        gbc.gridx = 1; gbc.weightx = 1;
        JButton changePwdBtn = UITheme.ghostButton("Change Password");
        changePwdBtn.addActionListener(e -> showChangePasswordDialog());
        formCard.add(changePwdBtn, gbc);

        twoCol.add(formCard, tc);

        JPanel btnRow = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        btnRow.setOpaque(false);
        JButton save = UITheme.primaryButton("Save Changes");
        save.addActionListener(e -> {
            teacher.setName(fm.get("Full Name").getText().trim());
            teacher.setEmail(fm.get("Email").getText().trim());
            teacher.setPhone(fm.get("Phone").getText().trim());
            teacher.setDepartment(fm.get("Department").getText().trim());
            teacher.setDesignation(fm.get("Designation").getText().trim());
            DataManager.updateTeacher(teacher);
            userNameLbl.setText(teacher.getName().split(" ")[0]);
            JOptionPane.showMessageDialog(this, "Profile updated successfully!");
        });
        btnRow.add(save);

        content.add(twoCol, BorderLayout.CENTER);
        content.add(btnRow, BorderLayout.SOUTH);

        JScrollPane profileScroll = new JScrollPane(content);
        profileScroll.setBorder(null);
        profileScroll.setOpaque(false);
        profileScroll.getViewport().setOpaque(false);
        profileScroll.getViewport().setBackground(UITheme.CONTENT_BG);
        profileScroll.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        profileScroll.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        profileScroll.getVerticalScrollBar().setUnitIncrement(16);

        panel.add(headerBanner, BorderLayout.NORTH);
        panel.add(profileScroll, BorderLayout.CENTER);
        showContent(panel);
    }

    private void showChangePasswordDialog() {
        JDialog dlg = new JDialog(this, "Change Password", true);
        dlg.setSize(400,280);
        dlg.setLocationRelativeTo(this);
        dlg.setLayout(new BorderLayout(10,10));
        dlg.getRootPane().setBorder(BorderFactory.createEmptyBorder(20,24,20,24));
        dlg.getContentPane().setBackground(UITheme.CARD_BG);

        JPasswordField currentF = UITheme.styledPasswordField();
        JPasswordField newF     = UITheme.styledPasswordField();
        JPasswordField confirmF = UITheme.styledPasswordField();

        JPanel form = new JPanel(new GridLayout(3,2,10,14));
        form.setBackground(UITheme.CARD_BG);
        form.add(UITheme.label("Current Password:", UITheme.boldFont(), UITheme.TEXT_DARK)); form.add(currentF);
        form.add(UITheme.label("New Password:",     UITheme.boldFont(), UITheme.TEXT_DARK)); form.add(newF);
        form.add(UITheme.label("Confirm New:",      UITheme.boldFont(), UITheme.TEXT_DARK)); form.add(confirmF);

        JPanel btnRow = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        btnRow.setBackground(UITheme.CARD_BG);
        JButton change = UITheme.accentButton("Change");
        JButton cancel = UITheme.ghostButton("Cancel");
        change.addActionListener(e -> {
            String curr = new String(currentF.getPassword());
            String newP = new String(newF.getPassword());
            String conf = new String(confirmF.getPassword());
            if (!teacher.getPassword().equals(curr)) { JOptionPane.showMessageDialog(dlg,"Current password is incorrect."); return; }
            if (!newP.equals(conf)) { JOptionPane.showMessageDialog(dlg,"New passwords do not match."); return; }
            if (newP.length() < 6) { JOptionPane.showMessageDialog(dlg,"Password must be at least 6 characters."); return; }
            teacher.setPassword(newP);
            DataManager.updateTeacher(teacher);
            JOptionPane.showMessageDialog(dlg, "Password changed successfully!");
            dlg.dispose();
        });
        cancel.addActionListener(e -> dlg.dispose());
        btnRow.add(cancel); btnRow.add(change);

        JLabel title = UITheme.label("Change Password", UITheme.headingFont(), UITheme.PRIMARY);
        title.setBorder(BorderFactory.createEmptyBorder(0,0,8,0));
        dlg.add(title, BorderLayout.NORTH);
        dlg.add(form, BorderLayout.CENTER);
        dlg.add(btnRow, BorderLayout.SOUTH);
        dlg.setVisible(true);
    }

    private JPanel buildSectionHeader(String title, String subtitle, Color c1, Color c2) {
        String sym = "";
        String dispTitle = title;
        int spIdx = title.indexOf("  ");
        if (spIdx > 0) { sym = title.substring(0, spIdx).trim(); dispTitle = title.substring(spIdx).trim(); }
        final String finalSym = sym;
        final String finalTitle = dispTitle;

        JPanel banner = new JPanel(new BorderLayout()) {
            @Override protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                GradientPaint gp = new GradientPaint(0, 0, c1, getWidth(), getHeight(), c2);
                g2.setPaint(gp); g2.fillRect(0, 0, getWidth(), getHeight());
                g2.setColor(new Color(255,255,255,18));
                g2.fillOval(getWidth()-160,-40,200,200);
                g2.setColor(new Color(255,255,255,10));
                g2.fillOval(getWidth()-60,10,100,100);
                g2.dispose();
            }
        };
        banner.setPreferredSize(new Dimension(0, 84));

        JPanel iconCircle = new JPanel() {
            @Override protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(new Color(255, 255, 255, 45));
                g2.fillOval(6, 6, 52, 52);
                if (!finalSym.isEmpty()) {
                    g2.setColor(Color.WHITE);
                    Font sf = UITheme.getSymbolFontPublic(finalSym, 22);
                    g2.setFont(sf);
                    FontMetrics fm = g2.getFontMetrics();
                    g2.drawString(finalSym, (64 - fm.stringWidth(finalSym)) / 2,
                            (64 - fm.getHeight()) / 2 + fm.getAscent());
                }
                g2.dispose();
            }
            @Override public Dimension getPreferredSize() { return new Dimension(64, 84); }
        };
        iconCircle.setOpaque(false);

        JPanel texts = new JPanel(new GridLayout(2,1,0,4)); texts.setOpaque(false);
        texts.setBorder(BorderFactory.createEmptyBorder(18, 16, 18, 28));
        texts.add(UITheme.label(finalTitle, UITheme.font(Font.BOLD, 22), Color.WHITE));
        texts.add(UITheme.label(subtitle, UITheme.font(Font.PLAIN, 12), new Color(210, 240, 255)));

        JPanel left = new JPanel(new BorderLayout()); left.setOpaque(false);
        left.add(iconCircle, BorderLayout.WEST);
        left.add(texts, BorderLayout.CENTER);
        banner.add(left, BorderLayout.WEST);
        return banner;
    }
}
