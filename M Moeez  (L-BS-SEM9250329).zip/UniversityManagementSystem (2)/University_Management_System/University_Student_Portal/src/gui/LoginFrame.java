package gui;

import models.*;
import utils.DataManager;
import utils.UITheme;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

public class LoginFrame extends JFrame {

    private JTextField idField;
    private JPasswordField passField;
    private JLabel statusLabel;
    private JLabel idLbl;
    private String[] selectedRole = {"STUDENT"};

    private static BufferedImage bgImage   = null;
    private static BufferedImage logoImage = null;

    static {
        try { bgImage   = ImageIO.read(new File("icon/login_portal.png")); }  catch (IOException e) { bgImage = null; }
        try { logoImage = ImageIO.read(new File("icon/university_logo.png")); } catch (IOException e) { logoImage = null; }
    }

    public LoginFrame() {
        setTitle("University Portal - Sign In");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1060, 660);
        setLocationRelativeTo(null);
        setResizable(false);
        UITheme.applyGlobalDefaults();
        initUI();
    }

    private void initUI() {
        JPanel root = new JPanel(new GridLayout(1, 2));

        
        JPanel leftPanel = new JPanel(new GridBagLayout()) {
            @Override protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                
                if (bgImage != null) {
                    double pa = (double) getWidth() / getHeight();
                    double ia = (double) bgImage.getWidth() / bgImage.getHeight();
                    int dw, dh, dx, dy;
                    if (pa > ia) { dw = getWidth(); dh = (int)(getWidth()/ia); }
                    else { dh = getHeight(); dw = (int)(getHeight()*ia); }
                    dx = (getWidth()-dw)/2; dy = (getHeight()-dh)/2;
                    g2.drawImage(bgImage, dx, dy, dw, dh, null);
                } else {
                    GradientPaint gp = new GradientPaint(0, 0, UITheme.PRIMARY_DARK, getWidth(), getHeight(), new Color(10, 60, 100));
                    g2.setPaint(gp); g2.fillRect(0, 0, getWidth(), getHeight());
                }
                
                GradientPaint overlay = new GradientPaint(0, 0, new Color(5, 20, 65, 185), getWidth(), getHeight(), new Color(8, 60, 90, 200));
                g2.setPaint(overlay); g2.fillRect(0, 0, getWidth(), getHeight());

                
                g2.setColor(new Color(245, 158, 11, 18));
                g2.fillOval(-80, -80, 320, 320);
                g2.setColor(new Color(37, 99, 235, 14));
                g2.fillOval(getWidth()-200, getHeight()-200, 300, 300);
                g2.setColor(new Color(255, 255, 255, 8));
                g2.fillOval(getWidth()-120, 30, 160, 160);

                
                g2.setColor(new Color(255, 255, 255, 8));
                
                g2.fillRoundRect(18, getHeight()-110, 50, 65, 4, 4);
                g2.fillRoundRect(72, getHeight()-105, 50, 65, 4, 4);
                
                g2.fillRect(getWidth()-115, 52, 60, 8);
                g2.fillRoundRect(getWidth()-105, 38, 40, 18, 4, 4);
                
                int[] dx = {30, 50, 30, 10}; int[] dy = {95, 115, 135, 115};
                g2.fillPolygon(dx, dy, 4);
                
                g2.setColor(new Color(245, 158, 11, 12));
                g2.fillOval(getWidth()-70, getHeight()-150, 35, 35);
                g2.fillOval(getWidth()-40, getHeight()-100, 20, 20);

                g2.dispose();
            }
        };

        
        JPanel logoArea = new JPanel();
        logoArea.setOpaque(false);
        logoArea.setLayout(new BoxLayout(logoArea, BoxLayout.Y_AXIS));

        
        if (logoImage != null) {
            Image scaled = logoImage.getScaledInstance(100, 100, Image.SCALE_SMOOTH);
            JLabel logoLbl = new JLabel(new ImageIcon(scaled));
            logoLbl.setAlignmentX(Component.CENTER_ALIGNMENT);
            logoArea.add(logoLbl);
            logoArea.add(Box.createVerticalStrut(20));
        } else {
            JPanel shield = createShield();
            shield.setAlignmentX(Component.CENTER_ALIGNMENT);
            logoArea.add(shield);
            logoArea.add(Box.createVerticalStrut(20));
        }

        JLabel uniLbl = new JLabel("UNIVERSITY");
        uniLbl.setFont(UITheme.font(Font.BOLD, 30));
        uniLbl.setForeground(Color.WHITE);
        uniLbl.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel portalLbl = new JLabel("STUDENT PORTAL");
        portalLbl.setFont(UITheme.font(Font.BOLD, 18));
        portalLbl.setForeground(UITheme.ACCENT);
        portalLbl.setAlignmentX(Component.CENTER_ALIGNMENT);

        
        JPanel divider = new JPanel() {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                GradientPaint gp = new GradientPaint(0,0,new Color(245,158,11,0),getWidth()/2,0,UITheme.ACCENT);
                g2.setPaint(gp); g2.fillRect(0,0,getWidth()/2,2);
                GradientPaint gp2 = new GradientPaint(getWidth()/2,0,UITheme.ACCENT,getWidth(),0,new Color(245,158,11,0));
                g2.setPaint(gp2); g2.fillRect(getWidth()/2,0,getWidth()/2,2);
                g2.dispose();
            }
            @Override public Dimension getPreferredSize() { return new Dimension(150,2); }
            @Override public Dimension getMaximumSize()   { return new Dimension(150,2); }
        };
        divider.setOpaque(false);
        divider.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel tagLbl = new JLabel("Empowering Education Since 2024");
        tagLbl.setFont(UITheme.font(Font.PLAIN, 12));
        tagLbl.setForeground(new Color(190, 215, 240));
        tagLbl.setAlignmentX(Component.CENTER_ALIGNMENT);

        
        JPanel features = new JPanel(new FlowLayout(FlowLayout.CENTER, 8, 0));
        features.setOpaque(false);
        for (String feat : new String[]{"Grades", "Courses", "Notices", "Schedule"}) {
            JLabel pill = new JLabel(feat);
            pill.setFont(UITheme.font(Font.BOLD, 11));
            pill.setForeground(new Color(200, 225, 255));
            pill.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(255,255,255,40),1),
                BorderFactory.createEmptyBorder(4,12,4,12)));
            features.add(pill);
        }

        logoArea.add(uniLbl);
        logoArea.add(Box.createVerticalStrut(6));
        logoArea.add(portalLbl);
        logoArea.add(Box.createVerticalStrut(16));
        logoArea.add(divider);
        logoArea.add(Box.createVerticalStrut(16));
        logoArea.add(tagLbl);
        logoArea.add(Box.createVerticalStrut(20));
        logoArea.add(features);

        leftPanel.add(logoArea);
        leftPanel.setBorder(BorderFactory.createEmptyBorder(40, 40, 40, 40));

        
        JPanel rightPanel = new JPanel(new GridBagLayout()) {
            @Override protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                // Dark blue gradient background
                GradientPaint gp = new GradientPaint(0, 0, new Color(5, 18, 60),
                    getWidth(), getHeight(), new Color(8, 30, 90));
                g2.setPaint(gp);
                g2.fillRect(0, 0, getWidth(), getHeight());
                // Subtle glowing circles
                g2.setColor(new Color(37, 99, 235, 28));
                g2.fillOval(getWidth() - 160, -50, 240, 240);
                g2.setColor(new Color(14, 165, 233, 18));
                g2.fillOval(-70, getHeight() - 160, 220, 220);
                g2.setColor(new Color(99, 179, 237, 12));
                g2.fillOval(getWidth() / 2 - 60, getHeight() / 2, 200, 200);
                // Top accent line
                GradientPaint accentLine = new GradientPaint(0, 0, new Color(37,99,235,0),
                    getWidth()/2, 0, new Color(125, 211, 252, 180));
                g2.setPaint(accentLine);
                g2.setStroke(new java.awt.BasicStroke(2f));
                g2.drawLine(0, 0, getWidth(), 0);
                g2.dispose();
            }
        };

        JPanel formBox = new JPanel();
        formBox.setLayout(new BoxLayout(formBox, BoxLayout.Y_AXIS));
        formBox.setOpaque(false);
        formBox.setBorder(BorderFactory.createEmptyBorder(10, 52, 10, 52));

        
        if (logoImage != null) {
            Image smallLogo = logoImage.getScaledInstance(52, 52, Image.SCALE_SMOOTH);
            JLabel smallLogoLbl = new JLabel(new ImageIcon(smallLogo));
            smallLogoLbl.setAlignmentX(Component.LEFT_ALIGNMENT);
            formBox.add(smallLogoLbl);
            formBox.add(Box.createVerticalStrut(12));
        }

        JLabel welcomeLbl = new JLabel("Welcome Back");
        welcomeLbl.setFont(UITheme.font(Font.BOLD, 30));
        welcomeLbl.setForeground(Color.WHITE);
        welcomeLbl.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel signInLbl = new JLabel("Sign in to access your portal");
        signInLbl.setFont(UITheme.font(Font.PLAIN, 13));
        signInLbl.setForeground(new Color(148, 197, 234));
        signInLbl.setAlignmentX(Component.LEFT_ALIGNMENT);

        formBox.add(welcomeLbl);
        formBox.add(Box.createVerticalStrut(5));
        formBox.add(signInLbl);
        formBox.add(Box.createVerticalStrut(22));

        
        Color TAB_ACTIVE   = new Color(33, 102, 172);
        Color TAB_INACTIVE = new Color(149, 185, 220);
        String[] roles     = {"STUDENT", "TEACHER", "ADMIN"};
        String[] roleLabels = {"Student ID / Email", "Teacher ID / Email", "Admin ID / Email"};

        JButton[] tabBtns = new JButton[3];

        JPanel tabPanel = new JPanel(new GridLayout(1, 3, 4, 0));
        tabPanel.setOpaque(false);
        tabPanel.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));
        tabPanel.setAlignmentX(Component.LEFT_ALIGNMENT);
        tabPanel.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 0));

        for (int ti = 0; ti < roles.length; ti++) {
            final int idx = ti;
            final String role = roles[ti];
            final String lbl  = roleLabels[ti];

            JButton tabBtn = new JButton(role) {
                @Override protected void paintComponent(Graphics g) {
                    Graphics2D g2 = (Graphics2D) g.create();
                    g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                    boolean active = role.equals(selectedRole[0]);
                    g2.setColor(active ? TAB_ACTIVE : TAB_INACTIVE);
                    if (idx == 0)
                        g2.fillRoundRect(0, 0, getWidth() + 6, getHeight(), 8, 8);
                    else if (idx == roles.length - 1)
                        g2.fillRoundRect(-6, 0, getWidth() + 6, getHeight(), 8, 8);
                    else
                        g2.fillRect(0, 0, getWidth(), getHeight());
                    
                    if (active) {
                        g2.setColor(new Color(255, 255, 255, 200));
                        g2.setStroke(new java.awt.BasicStroke(2.5f));
                        g2.drawLine(8, getHeight() - 4, getWidth() - 8, getHeight() - 4);
                    }
                    g2.dispose();
                    super.paintComponent(g);
                }
            };
            tabBtn.setFont(UITheme.font(Font.BOLD, 13));
            tabBtn.setForeground(Color.WHITE);
            tabBtn.setContentAreaFilled(false);
            tabBtn.setBorderPainted(false);
            tabBtn.setFocusPainted(false);
            tabBtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            tabBtn.addActionListener(e -> {
                selectedRole[0] = role;
                idLbl.setText(lbl);
                idField.setToolTipText("Enter your " + lbl);
                for (JButton b : tabBtns) b.repaint();
            });
            tabBtns[idx] = tabBtn;
            tabPanel.add(tabBtn);
        }

        formBox.add(tabPanel);
        formBox.add(Box.createVerticalStrut(20));

        
        idLbl = new JLabel("Student ID / Email");
        idLbl.setFont(UITheme.boldFont());
        idLbl.setForeground(new Color(186, 230, 253));
        idLbl.setAlignmentX(Component.LEFT_ALIGNMENT);
        idField = UITheme.styledField();
        idField.setMaximumSize(new Dimension(Integer.MAX_VALUE, 44));
        idField.setAlignmentX(Component.LEFT_ALIGNMENT);
        idField.setBackground(Color.WHITE);

        formBox.add(idLbl);
        formBox.add(Box.createVerticalStrut(7));
        formBox.add(idField);
        formBox.add(Box.createVerticalStrut(16));

        
        JLabel passLbl = new JLabel("Password");
        passLbl.setFont(UITheme.boldFont());
        passLbl.setForeground(new Color(186, 230, 253));
        passLbl.setAlignmentX(Component.LEFT_ALIGNMENT);
        passField = UITheme.styledPasswordField();
        passField.setMaximumSize(new Dimension(Integer.MAX_VALUE, 44));
        passField.setAlignmentX(Component.LEFT_ALIGNMENT);
        passField.setBackground(Color.WHITE);

        formBox.add(passLbl);
        formBox.add(Box.createVerticalStrut(7));
        formBox.add(passField);
        formBox.add(Box.createVerticalStrut(8));

        JLabel forgotLbl = new JLabel("Forgot password?");
        forgotLbl.setFont(UITheme.font(Font.PLAIN, 12));
        forgotLbl.setForeground(new Color(125, 211, 252));
        forgotLbl.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        forgotLbl.addMouseListener(new MouseAdapter() {
            @Override public void mouseClicked(MouseEvent e) { showForgotPasswordDialog(); }
            @Override public void mouseEntered(MouseEvent e) { forgotLbl.setForeground(UITheme.PRIMARY); }
            @Override public void mouseExited(MouseEvent e)  { forgotLbl.setForeground(new Color(125, 211, 252)); }
        });

        
        JPanel forgotRow = new JPanel(new FlowLayout(FlowLayout.RIGHT, 0, 0));
        forgotRow.setOpaque(false);
        forgotRow.setAlignmentX(Component.LEFT_ALIGNMENT);
        forgotRow.setMaximumSize(new Dimension(Integer.MAX_VALUE, 20));
        forgotRow.add(forgotLbl);
        formBox.add(forgotRow);
        formBox.add(Box.createVerticalStrut(22));

        
        JButton loginBtn = new JButton("SIGN IN") {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                GradientPaint gp = getModel().isRollover()
                    ? new GradientPaint(0,0,UITheme.SECONDARY,getWidth(),0,new Color(79,70,229))
                    : new GradientPaint(0,0,UITheme.PRIMARY,getWidth(),0,UITheme.SECONDARY);
                g2.setPaint(gp);
                g2.fillRoundRect(0,0,getWidth(),getHeight(),10,10);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        loginBtn.setFont(UITheme.font(Font.BOLD, 15));
        loginBtn.setForeground(Color.WHITE);
        loginBtn.setContentAreaFilled(false);
        loginBtn.setBorderPainted(false);
        loginBtn.setFocusPainted(false);
        loginBtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        loginBtn.setBorder(BorderFactory.createEmptyBorder(12, 0, 12, 0));
        loginBtn.setMaximumSize(new Dimension(Integer.MAX_VALUE, 48));
        loginBtn.setAlignmentX(Component.LEFT_ALIGNMENT);
        formBox.add(loginBtn);
        formBox.add(Box.createVerticalStrut(12));

        // ── Sign Up link ──────────────────────────────────────────────────────
        JPanel signupRow = new JPanel(new FlowLayout(FlowLayout.CENTER, 4, 0));
        signupRow.setOpaque(false);
        signupRow.setAlignmentX(Component.LEFT_ALIGNMENT);
        signupRow.setMaximumSize(new Dimension(Integer.MAX_VALUE, 24));
        JLabel noAccLbl = new JLabel("New student?");
        noAccLbl.setFont(UITheme.font(Font.PLAIN, 12));
        noAccLbl.setForeground(new Color(148, 197, 234));
        JLabel signupLinkLbl = new JLabel("Apply for Admission");
        signupLinkLbl.setFont(UITheme.font(Font.BOLD, 12));
        signupLinkLbl.setForeground(new Color(125, 211, 252));
        signupLinkLbl.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        signupLinkLbl.addMouseListener(new MouseAdapter() {
            @Override public void mouseClicked(MouseEvent e) { showSignUpDialog(); }
            @Override public void mouseEntered(MouseEvent e) { signupLinkLbl.setForeground(UITheme.PRIMARY); }
            @Override public void mouseExited(MouseEvent e)  { signupLinkLbl.setForeground(new Color(125, 211, 252)); }
        });
        signupRow.add(noAccLbl);
        signupRow.add(signupLinkLbl);
        formBox.add(signupRow);
        formBox.add(Box.createVerticalStrut(8));

        
        statusLabel = new JLabel(" ");
        statusLabel.setFont(UITheme.font(Font.BOLD, 12));
        statusLabel.setForeground(UITheme.DANGER);
        statusLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        formBox.add(statusLabel);

        
        formBox.add(Box.createVerticalStrut(20));
        JPanel hintCard = new JPanel(new GridLayout(1, 3, 0, 0)) {
            @Override protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                GradientPaint gp = new GradientPaint(0, 0, new Color(10, 40, 100, 200),
                    getWidth(), getHeight(), new Color(15, 55, 130, 200));
                g2.setPaint(gp);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 12, 12);
                g2.setColor(new Color(125, 211, 252, 80));
                g2.setStroke(new BasicStroke(1.2f));
                g2.drawRoundRect(0, 0, getWidth()-1, getHeight()-1, 12, 12);
                g2.dispose();
            }
        };
        hintCard.setOpaque(false);
        hintCard.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        hintCard.setMaximumSize(new Dimension(Integer.MAX_VALUE, 52));
        hintCard.setAlignmentX(Component.LEFT_ALIGNMENT);
        Color[] roleColors = {UITheme.TEAL, UITheme.SECONDARY, UITheme.ACCENT};
        String[] roleNames = {"Student", "Teacher", "Admin"};
        String[] roleIcons = {"\uD83D\uDC64", "\uD83D\uDC68\u200D\uD83C\uDFEB", "\u2699"};
        for (int i = 0; i < roleNames.length; i++) {
            final Color rc = roleColors[i];
            final String ri = roleIcons[i];
            JPanel cell = new JPanel(new FlowLayout(FlowLayout.CENTER, 6, 0));
            cell.setOpaque(false);
            JPanel dot = new JPanel() {
                @Override protected void paintComponent(Graphics g) {
                    super.paintComponent(g);
                    Graphics2D g2 = (Graphics2D) g.create();
                    g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                    g2.setColor(rc);
                    g2.fillOval(0, 0, 20, 20);
                    g2.setColor(Color.WHITE);
                    Font riFont = UITheme.getSymbolFontPublic(ri, 9);
                    g2.setFont(riFont);
                    FontMetrics fm = g2.getFontMetrics();
                    g2.drawString(ri, (20-fm.stringWidth(ri))/2, (20-fm.getHeight())/2+fm.getAscent());
                    g2.dispose();
                }
                @Override public Dimension getPreferredSize() { return new Dimension(20, 20); }
            };
            dot.setOpaque(false);
            JLabel lbl = UITheme.label(roleNames[i], UITheme.font(Font.BOLD, 12), new Color(186, 230, 253));
            cell.add(dot); cell.add(lbl);
            hintCard.add(cell);
        }
        formBox.add(hintCard);

        formBox.add(Box.createVerticalStrut(20));
        JLabel footerLbl = new JLabel("Secure Access  |  (c) 2024 University Portal");
        footerLbl.setFont(UITheme.font(Font.PLAIN, 11));
        footerLbl.setForeground(new Color(100, 160, 210));
        footerLbl.setAlignmentX(Component.CENTER_ALIGNMENT);
        formBox.add(footerLbl);

        rightPanel.add(formBox);

        
        java.awt.event.ActionListener loginAction = e -> performLogin();
        loginBtn.addActionListener(loginAction);
        passField.addActionListener(loginAction);
        idField.addActionListener(loginAction);

        root.add(leftPanel);
        root.add(rightPanel);
        setContentPane(root);
    }

    private void performLogin() {
        String id   = idField.getText().trim();
        String pass = new String(passField.getPassword()).trim();
        if (id.isEmpty() || pass.isEmpty()) {
            statusLabel.setText("Please enter your ID/Email and password.");
            statusLabel.setForeground(UITheme.DANGER);
            return;
        }
        User user = DataManager.authenticate(id, pass);
        if (user == null || !user.getRole().equals(selectedRole[0])) {
            statusLabel.setText("Invalid credentials for " + selectedRole[0] + ". Please try again.");
            statusLabel.setForeground(UITheme.DANGER);
            passField.setText("");
            return;
        }
        statusLabel.setForeground(UITheme.SUCCESS);
        statusLabel.setText("Login successful! Loading your portal...");
        SwingUtilities.invokeLater(() -> {
            dispose();
            switch (user.getRole()) {
                case "STUDENT": new StudentDashboard((models.Student) user).setVisible(true); break;
                case "TEACHER": new TeacherDashboard((models.Teacher) user).setVisible(true); break;
                case "ADMIN":   new AdminDashboard((models.Admin)   user).setVisible(true);   break;
            }
        });
    }

    private void showSignUpDialog() {
        JDialog dlg = new JDialog(this, "Student Admission Application", true);
        dlg.setSize(480, 560);
        dlg.setLocationRelativeTo(this);
        dlg.setResizable(false);

        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBackground(new Color(250, 252, 255));
        panel.setBorder(BorderFactory.createEmptyBorder(28, 36, 24, 36));

        JLabel title = new JLabel("Apply for Admission");
        title.setFont(UITheme.font(Font.BOLD, 22));
        title.setForeground(UITheme.PRIMARY);
        title.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel sub = new JLabel("Fill in your details. Admin will review your application.");
        sub.setFont(UITheme.font(Font.PLAIN, 12));
        sub.setForeground(UITheme.TEXT_MUTED);
        sub.setAlignmentX(Component.LEFT_ALIGNMENT);

        panel.add(title);
        panel.add(Box.createVerticalStrut(4));
        panel.add(sub);
        panel.add(Box.createVerticalStrut(20));

        // Helper to add a labelled field row
        java.util.function.BiFunction<String, JTextField, JTextField> addField = (labelText, tf) -> {
            JLabel lbl = new JLabel(labelText);
            lbl.setFont(UITheme.boldFont());
            lbl.setForeground(UITheme.TEXT_DARK);
            lbl.setAlignmentX(Component.LEFT_ALIGNMENT);
            tf.setMaximumSize(new Dimension(Integer.MAX_VALUE, 42));
            tf.setAlignmentX(Component.LEFT_ALIGNMENT);
            tf.setBackground(Color.WHITE);
            panel.add(lbl);
            panel.add(Box.createVerticalStrut(4));
            panel.add(tf);
            panel.add(Box.createVerticalStrut(12));
            return tf;
        };

        JTextField nameField    = addField.apply("Full Name *", UITheme.styledField());
        JTextField emailField   = addField.apply("Email Address *", UITheme.styledField());
        JPasswordField passField2 = (JPasswordField) addField.apply("Password *",
                UITheme.styledPasswordField());
        JTextField phoneField   = addField.apply("Phone Number", UITheme.styledField());

        // Major dropdown
        JLabel majorLbl = new JLabel("Intended Major *");
        majorLbl.setFont(UITheme.boldFont());
        majorLbl.setForeground(UITheme.TEXT_DARK);
        majorLbl.setAlignmentX(Component.LEFT_ALIGNMENT);
        String[] majors = {"Computer Science", "Software Engineering", "Information Technology",
                "Mathematics", "Physics", "Business Administration", "English", "Other"};
        JComboBox<String> majorBox = new JComboBox<>(majors);
        majorBox.setMaximumSize(new Dimension(Integer.MAX_VALUE, 42));
        majorBox.setAlignmentX(Component.LEFT_ALIGNMENT);
        majorBox.setBackground(Color.WHITE);
        panel.add(majorLbl);
        panel.add(Box.createVerticalStrut(4));
        panel.add(majorBox);
        panel.add(Box.createVerticalStrut(14));

        JLabel resultLbl = new JLabel(" ");
        resultLbl.setFont(UITheme.font(Font.BOLD, 12));
        resultLbl.setAlignmentX(Component.LEFT_ALIGNMENT);
        panel.add(resultLbl);
        panel.add(Box.createVerticalStrut(10));

        // Buttons
        JPanel btnRow = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        btnRow.setOpaque(false);
        btnRow.setAlignmentX(Component.LEFT_ALIGNMENT);
        btnRow.setMaximumSize(new Dimension(Integer.MAX_VALUE, 44));

        JButton cancelBtn = new JButton("Cancel");
        cancelBtn.setFont(UITheme.font(Font.PLAIN, 13));
        cancelBtn.setForeground(UITheme.TEXT_DARK);
        cancelBtn.setFocusPainted(false);
        cancelBtn.addActionListener(e -> dlg.dispose());

        JButton submitBtn = new JButton("Submit Application") {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                GradientPaint gp = new GradientPaint(0, 0, UITheme.PRIMARY, getWidth(), 0, UITheme.SECONDARY);
                g2.setPaint(gp);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 8, 8);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        submitBtn.setFont(UITheme.font(Font.BOLD, 13));
        submitBtn.setForeground(Color.WHITE);
        submitBtn.setContentAreaFilled(false);
        submitBtn.setBorderPainted(false);
        submitBtn.setFocusPainted(false);
        submitBtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        submitBtn.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));

        submitBtn.addActionListener(e -> {
            String name  = nameField.getText().trim();
            String email = emailField.getText().trim();
            String pass  = new String(passField2.getPassword()).trim();
            String phone = phoneField.getText().trim();
            String major = (String) majorBox.getSelectedItem();

            if (name.isEmpty() || email.isEmpty() || pass.isEmpty()) {
                resultLbl.setForeground(UITheme.DANGER);
                resultLbl.setText("Please fill in all required (*) fields.");
                return;
            }
            if (!email.contains("@")) {
                resultLbl.setForeground(UITheme.DANGER);
                resultLbl.setText("Please enter a valid email address.");
                return;
            }
            // Check duplicate email
            if (utils.DataManager.findStudentByEmail(email) != null
                    || utils.DataManager.isPendingApplicationEmail(email)) {
                resultLbl.setForeground(UITheme.DANGER);
                resultLbl.setText("This email already has an account or pending application.");
                return;
            }
            utils.DataManager.addPendingApplication(name, email, pass,
                    phone.isEmpty() ? "N/A" : phone, "N/A", major);

            // Show success and close after 2 s
            resultLbl.setForeground(UITheme.SUCCESS);
            resultLbl.setText("<html>✔ Application submitted! You will be notified by admin.</html>");
            submitBtn.setEnabled(false);
            nameField.setEnabled(false);
            emailField.setEnabled(false);
            passField2.setEnabled(false);
            phoneField.setEnabled(false);
            majorBox.setEnabled(false);
            cancelBtn.setText("Close");
        });

        btnRow.add(cancelBtn);
        btnRow.add(submitBtn);
        panel.add(btnRow);

        JScrollPane scroll = new JScrollPane(panel);
        scroll.setBorder(null);
        dlg.setContentPane(scroll);
        dlg.setVisible(true);
    }

    private void showForgotPasswordDialog() {
        
        JDialog dlg = new JDialog(this, "Forgot Password", true);
        dlg.setSize(420, 300);
        dlg.setLocationRelativeTo(this);
        dlg.setResizable(false);

        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBackground(new Color(250, 252, 255));
        panel.setBorder(BorderFactory.createEmptyBorder(30, 36, 24, 36));

        JLabel title = new JLabel("Reset Your Password");
        title.setFont(UITheme.font(Font.BOLD, 20));
        title.setForeground(UITheme.PRIMARY);
        title.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel sub = new JLabel("Enter your Student ID or registered email");
        sub.setFont(UITheme.font(Font.PLAIN, 12));
        sub.setForeground(UITheme.TEXT_MUTED);
        sub.setAlignmentX(Component.LEFT_ALIGNMENT);

        panel.add(title);
        panel.add(Box.createVerticalStrut(6));
        panel.add(sub);
        panel.add(Box.createVerticalStrut(20));

        JLabel idLbl = new JLabel("Student ID / Email");
        idLbl.setFont(UITheme.boldFont());
        idLbl.setForeground(new Color(186, 230, 253));
        idLbl.setAlignmentX(Component.LEFT_ALIGNMENT);

        JTextField resetIdField = UITheme.styledField();
        resetIdField.setMaximumSize(new Dimension(Integer.MAX_VALUE, 44));
        resetIdField.setAlignmentX(Component.LEFT_ALIGNMENT);
        resetIdField.setBackground(Color.WHITE);

        panel.add(idLbl);
        panel.add(Box.createVerticalStrut(7));
        panel.add(resetIdField);
        panel.add(Box.createVerticalStrut(16));

        JLabel resultLbl = new JLabel(" ");
        resultLbl.setFont(UITheme.font(Font.BOLD, 12));
        resultLbl.setAlignmentX(Component.LEFT_ALIGNMENT);
        panel.add(resultLbl);
        panel.add(Box.createVerticalStrut(12));

        
        JPanel btnRow = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        btnRow.setOpaque(false);
        btnRow.setAlignmentX(Component.LEFT_ALIGNMENT);
        btnRow.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));

        JButton cancelBtn = new JButton("Cancel");
        cancelBtn.setFont(UITheme.font(Font.PLAIN, 13));
        cancelBtn.setForeground(UITheme.TEXT_DARK);
        cancelBtn.setFocusPainted(false);
        cancelBtn.addActionListener(e -> dlg.dispose());

        JButton lookupBtn = new JButton("Find Account") {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                GradientPaint gp = new GradientPaint(0, 0, UITheme.PRIMARY, getWidth(), 0, UITheme.SECONDARY);
                g2.setPaint(gp);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 8, 8);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        lookupBtn.setFont(UITheme.font(Font.BOLD, 13));
        lookupBtn.setForeground(Color.WHITE);
        lookupBtn.setContentAreaFilled(false);
        lookupBtn.setBorderPainted(false);
        lookupBtn.setFocusPainted(false);
        lookupBtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        lookupBtn.setBorder(BorderFactory.createEmptyBorder(8, 18, 8, 18));

        java.awt.event.ActionListener lookupAction = e -> {
            String input = resetIdField.getText().trim();
            if (input.isEmpty()) {
                resultLbl.setForeground(UITheme.DANGER);
                resultLbl.setText("Please enter your ID or email.");
                return;
            }
            
            models.User found = null;
            for (models.Admin a : DataManager.loadAdmins()) {
                if (a.getId().equalsIgnoreCase(input) || a.getEmail().equalsIgnoreCase(input)) { found = a; break; }
            }
            if (found == null) {
                for (models.Teacher t : DataManager.loadTeachers()) {
                    if (t.getId().equalsIgnoreCase(input) || t.getEmail().equalsIgnoreCase(input)) { found = t; break; }
                }
            }
            if (found == null) {
                for (models.Student s : DataManager.loadStudents()) {
                    if (s.getId().equalsIgnoreCase(input) || s.getEmail().equalsIgnoreCase(input)) { found = s; break; }
                }
            }
            if (found == null) {
                resultLbl.setForeground(UITheme.DANGER);
                resultLbl.setText("No account found for: " + input);
            } else {
                resultLbl.setForeground(UITheme.SUCCESS);
                resultLbl.setText("<html>Account found: <b>" + found.getName()
                    + "</b> &nbsp;|&nbsp; Password: <b>" + found.getPassword() + "</b></html>");
                lookupBtn.setEnabled(false);
                resetIdField.setEnabled(false);
            }
        };

        lookupBtn.addActionListener(lookupAction);
        resetIdField.addActionListener(lookupAction);

        btnRow.add(cancelBtn);
        btnRow.add(lookupBtn);
        panel.add(btnRow);

        dlg.setContentPane(panel);
        dlg.setVisible(true);
    }

    private JPanel createShield() {
        JPanel p = new JPanel() {
            @Override protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                int w = getWidth(), h = getHeight();
                int[] xs = {w/2, w-5, w-5, w/2, 5, 5};
                int[] ys = {5, 20, h*2/3, h-5, h*2/3, 20};
                g2.setColor(UITheme.GOLD);
                g2.fillPolygon(xs, ys, 6);
                int[] xi = {w/2, w-15, w-15, w/2, 15, 15};
                int[] yi = {18, 28, h*2/3-5, h-18, h*2/3-5, 28};
                g2.setColor(UITheme.PRIMARY);
                g2.fillPolygon(xi, yi, 6);
                g2.setColor(Color.WHITE);
                g2.setFont(UITheme.font(Font.BOLD, 28));
                FontMetrics fm = g2.getFontMetrics();
                String u = "U";
                g2.drawString(u, (w-fm.stringWidth(u))/2, h/2+fm.getAscent()/2-2);
            }
            @Override public Dimension getPreferredSize() { return new Dimension(80, 90); }
        };
        p.setOpaque(false);
        return p;
    }
}
