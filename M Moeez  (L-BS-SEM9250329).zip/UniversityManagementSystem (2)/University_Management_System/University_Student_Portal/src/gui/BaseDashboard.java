package gui;

import utils.UITheme;
import models.User;

import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.Ellipse2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.nio.file.*;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public abstract class BaseDashboard extends JFrame {

    protected User currentUser;
    protected JPanel contentArea;
    protected JPanel sidebarPanel;
    protected Map<String, JButton> navButtons = new LinkedHashMap<>();
    protected String activeNav = "";
    protected JLabel userNameLbl;
    protected JLabel userRoleLbl;
    protected JPanel topBarAvatar; 

    private static final String PROFILE_PICS_DIR = "data/profile_pics";

    
    private static final int SIDEBAR_COLLAPSED = 80;

    
    private final List<NavItem> navItems = new ArrayList<>();

    private static BufferedImage logoImage = null;
    static {
        try { logoImage = ImageIO.read(new File("icon/university_logo.png")); }
        catch (IOException e) { logoImage = null; }
    }

    
    private static class NavItem {
        final String label;
        final int[]  shape; 
        final String iconKey;
        final Runnable action;
        NavItem(String label, String iconKey, Runnable action) {
            this.label   = label;
            this.iconKey = iconKey;
            this.action  = action;
            this.shape   = null;
        }
    }

    public BaseDashboard(User user, String title) {
        this.currentUser = user;
        setTitle(title);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1380, 820);
        setLocationRelativeTo(null);
        setMinimumSize(new Dimension(1100, 700));
        UITheme.applyGlobalDefaults();
        buildLayout();
    }

    
    private void buildLayout() {
        JPanel root = new JPanel(new BorderLayout());
        root.setBackground(UITheme.CONTENT_BG);

        
        JPanel topBar = new JPanel(new BorderLayout()) {
            @Override protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                // Rich 3-stop gradient: deep navy → royal blue → indigo
                GradientPaint gp = new GradientPaint(0, 0, UITheme.PRIMARY_DARK, getWidth(), 0,
                    new Color(55, 48, 180));
                g2.setPaint(gp);
                g2.fillRect(0, 0, getWidth(), getHeight());
                // Sheen overlay
                g2.setColor(new Color(255, 255, 255, 12));
                g2.fillRect(0, 0, getWidth(), getHeight() / 2);
                // Decorative circle
                g2.setColor(new Color(255, 255, 255, 8));
                g2.fillOval(getWidth() / 2 - 80, -30, 160, 100);
                // Bottom border line (accent gold)
                g2.setPaint(new GradientPaint(0, getHeight() - 2,
                    new Color(UITheme.ACCENT.getRed(), UITheme.ACCENT.getGreen(), UITheme.ACCENT.getBlue(), 0),
                    getWidth() / 2, getHeight() - 2, UITheme.ACCENT_LIGHT));
                g2.setStroke(new BasicStroke(2f));
                g2.drawLine(0, getHeight() - 1, getWidth(), getHeight() - 1);
                g2.dispose();
            }
        };
        topBar.setPreferredSize(new Dimension(0, 62));
        topBar.setBorder(BorderFactory.createEmptyBorder(0, 18, 0, 22));

        JPanel topLeft = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 0));
        topLeft.setOpaque(false);
        if (logoImage != null) {
            Image scaled = logoImage.getScaledInstance(40, 40, Image.SCALE_SMOOTH);
            topLeft.add(new JLabel(new ImageIcon(scaled)));
        }
        JPanel appNamePanel = new JPanel(new GridLayout(2, 1, 0, 1));
        appNamePanel.setOpaque(false);
        appNamePanel.add(UITheme.label("University Portal",          UITheme.font(Font.BOLD,  16), Color.WHITE));
        appNamePanel.add(UITheme.label("Learning Management System", UITheme.font(Font.PLAIN, 10), new Color(180, 200, 230)));
        topLeft.add(appNamePanel);

        JPanel topRight = new JPanel(new FlowLayout(FlowLayout.RIGHT, 12, 0));
        topRight.setOpaque(false);

        
        topBarAvatar = new JPanel() {
            @Override protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                
                g2.setClip(new Ellipse2D.Float(0, 0, 36, 36));
                String picPath = currentUser.getProfilePicturePath();
                if (picPath != null && !picPath.isEmpty()) {
                    try {
                        BufferedImage img = ImageIO.read(new File(picPath));
                        if (img != null) {
                            g2.drawImage(img, 0, 0, 36, 36, null);
                            g2.dispose();
                            return;
                        }
                    } catch (IOException ex) {  }
                }
                g2.setPaint(new GradientPaint(0, 0, UITheme.ACCENT, 36, 36, UITheme.ACCENT_DARK));
                g2.fillOval(0, 0, 36, 36);
                g2.setClip(null);
                g2.setColor(Color.WHITE);
                g2.setFont(UITheme.font(Font.BOLD, 15));
                String init = currentUser.getName().substring(0, 1).toUpperCase();
                FontMetrics fm = g2.getFontMetrics();
                g2.drawString(init, (36 - fm.stringWidth(init)) / 2, (36 - fm.getHeight()) / 2 + fm.getAscent());
                g2.dispose();
            }
            @Override public Dimension getPreferredSize() { return new Dimension(36, 36); }
        };
        JPanel avatar = topBarAvatar;
        avatar.setOpaque(false);

        JPanel userInfo = new JPanel(new GridLayout(2, 1, 0, 1));
        userInfo.setOpaque(false);
        userNameLbl = UITheme.label(currentUser.getName().split(" ")[0], UITheme.boldFont(), Color.WHITE);
        String roleText = currentUser.getRole().charAt(0) + currentUser.getRole().substring(1).toLowerCase();
        userRoleLbl  = UITheme.label(roleText, UITheme.smallFont(), new Color(180, 200, 235));
        userInfo.add(userNameLbl);
        userInfo.add(userRoleLbl);

        JButton logoutBtn = new JButton("Sign Out") {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(getModel().isRollover() ? new Color(220, 38, 38) : new Color(200, 40, 40, 180));
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 8, 8);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        logoutBtn.setFont(UITheme.font(Font.BOLD, 11));
        logoutBtn.setForeground(Color.WHITE);
        logoutBtn.setContentAreaFilled(false);
        logoutBtn.setBorderPainted(false);
        logoutBtn.setFocusPainted(false);
        logoutBtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        logoutBtn.setBorder(BorderFactory.createEmptyBorder(6, 14, 6, 14));
        logoutBtn.addActionListener(e -> logout());

        topRight.add(avatar);
        topRight.add(userInfo);
        topRight.add(logoutBtn);
        topBar.add(topLeft,  BorderLayout.WEST);
        topBar.add(topRight, BorderLayout.EAST);

        
        sidebarPanel = new JPanel() {
            @Override protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                // Deep gradient sidebar
                GradientPaint gp = new GradientPaint(0, 0, new Color(8, 25, 70),
                    0, getHeight(), new Color(20, 15, 55));
                g2.setPaint(gp);
                g2.fillRect(0, 0, getWidth(), getHeight());
                // Decorative circles
                g2.setColor(new Color(100, 80, 255, 18));
                g2.fillOval(-30, getHeight() / 2 - 80, 120, 120);
                g2.setColor(new Color(26, 86, 219, 15));
                g2.fillOval(-20, 20, 100, 100);
                // Right border gradient
                GradientPaint border = new GradientPaint(getWidth() - 1, 0,
                    new Color(100, 150, 255, 30), getWidth() - 1, getHeight(),
                    new Color(100, 50, 255, 10));
                g2.setPaint(border);
                g2.fillRect(getWidth() - 1, 0, 1, getHeight());
                g2.dispose();
            }
        };
        sidebarPanel.setLayout(new BoxLayout(sidebarPanel, BoxLayout.Y_AXIS));
        sidebarPanel.setOpaque(false);
        sidebarPanel.setPreferredSize(new Dimension(SIDEBAR_COLLAPSED, 0));
        sidebarPanel.setBorder(BorderFactory.createEmptyBorder(16, 0, 16, 0));

        
        JPanel logoMark = new JPanel() {
            @Override protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                int cx = getWidth() / 2, cy = getHeight() / 2;
                
                g2.setColor(UITheme.ACCENT);
                g2.setStroke(new BasicStroke(2f));
                g2.drawOval(cx - 16, cy - 16, 32, 32);
                
                g2.setColor(Color.WHITE);
                g2.setFont(UITheme.font(Font.BOLD, 16));
                FontMetrics fm = g2.getFontMetrics();
                g2.drawString("U", cx - fm.stringWidth("U") / 2, cy + fm.getAscent() / 2 - 1);
                g2.dispose();
            }
            @Override public Dimension getPreferredSize() { return new Dimension(SIDEBAR_COLLAPSED, 52); }
            @Override public Dimension getMaximumSize()   { return new Dimension(SIDEBAR_COLLAPSED, 52); }
        };
        logoMark.setOpaque(false);
        logoMark.setAlignmentX(Component.CENTER_ALIGNMENT);
        sidebarPanel.add(logoMark);

        
        sidebarPanel.add(makeSidebarDivider());
        sidebarPanel.add(Box.createVerticalStrut(8));

        
        addNavigationItems();

        sidebarPanel.add(Box.createVerticalGlue());

        
        contentArea = UITheme.contentBackground();
        contentArea.setBackground(UITheme.CONTENT_BG);

        // Wrap sidebar in a JScrollPane so it scrolls when the window is too short
        JScrollPane sidebarScroll = new JScrollPane(sidebarPanel,
                JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
                JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        sidebarScroll.setBorder(null);
        sidebarScroll.setOpaque(false);
        sidebarScroll.getViewport().setOpaque(false);
        sidebarScroll.getViewport().setBackground(UITheme.PRIMARY_DARK);
        sidebarScroll.setPreferredSize(new Dimension(SIDEBAR_COLLAPSED, 0));
        // Style the vertical scrollbar to be visible on the dark sidebar
        JScrollBar vsb = sidebarScroll.getVerticalScrollBar();
        vsb.setOpaque(true);
        vsb.setPreferredSize(new Dimension(6, 0));
        vsb.setUnitIncrement(16);
        vsb.setUI(new javax.swing.plaf.basic.BasicScrollBarUI() {
            @Override protected void configureScrollBarColors() {
                thumbColor = new Color(120, 160, 230, 180);
                trackColor = new Color(5, 20, 60);
            }
            @Override protected void paintThumb(java.awt.Graphics g, javax.swing.JComponent c, java.awt.Rectangle r) {
                java.awt.Graphics2D g2 = (java.awt.Graphics2D) g.create();
                g2.setRenderingHint(java.awt.RenderingHints.KEY_ANTIALIASING, java.awt.RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(new Color(120, 160, 230, 200));
                g2.fillRoundRect(r.x + 1, r.y + 2, r.width - 2, r.height - 4, 4, 4);
                g2.dispose();
            }
            @Override protected void paintTrack(java.awt.Graphics g, javax.swing.JComponent c, java.awt.Rectangle r) {
                java.awt.Graphics2D g2 = (java.awt.Graphics2D) g.create();
                g2.setColor(new Color(5, 20, 60));
                g2.fillRect(r.x, r.y, r.width, r.height);
                g2.dispose();
            }
            @Override protected JButton createDecreaseButton(int orientation) {
                return createZeroButton();
            }
            @Override protected JButton createIncreaseButton(int orientation) {
                return createZeroButton();
            }
            private JButton createZeroButton() {
                JButton btn = new JButton();
                btn.setPreferredSize(new Dimension(0, 0));
                btn.setMinimumSize(new Dimension(0, 0));
                btn.setMaximumSize(new Dimension(0, 0));
                return btn;
            }
        });

        JPanel center = new JPanel(new BorderLayout());
        center.add(sidebarScroll, BorderLayout.WEST);
        center.add(contentArea,   BorderLayout.CENTER);

        root.add(topBar,  BorderLayout.NORTH);
        root.add(center,  BorderLayout.CENTER);
        setContentPane(root);
    }

    
    /**
     * iconKey maps to a drawn icon glyph (no emoji, no font icons needed).
     * Supported keys: home, courses, assignments, grades, calendar,
     *                 notices, fee, profile, students, teachers,
     *                 announcements, admins, gradeentry
     */
    protected void addNavButton(String iconKey, String label, Runnable action) {

        JButton btn = new JButton() {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                boolean active = getBackground().equals(UITheme.SIDEBAR_ACTIVE);
                boolean hover  = getBackground().equals(UITheme.SIDEBAR_HOVER);

                
                if (active) {
                    g2.setColor(UITheme.SIDEBAR_ACTIVE);
                    g2.fillRoundRect(8, 4, getWidth() - 16, getHeight() - 8, 12, 12);
                    
                    g2.setColor(UITheme.ACCENT);
                    g2.fillRoundRect(0, 10, 4, getHeight() - 20, 4, 4);
                } else if (hover) {
                    g2.setColor(new Color(255, 255, 255, 18));
                    g2.fillRoundRect(8, 4, getWidth() - 16, getHeight() - 8, 12, 12);
                }

                
                int cx = getWidth() / 2;
                int cy = getHeight() / 2 - 6;   
                Color iconColor = active ? Color.WHITE : new Color(160, 190, 230);
                drawIcon(g2, iconKey, cx, cy, iconColor, active);

                
                g2.setFont(new Font("SansSerif", Font.PLAIN, 10));
                g2.setColor(active ? Color.WHITE : new Color(160, 190, 230));
                FontMetrics fm = g2.getFontMetrics();
                int tx = cx - fm.stringWidth(label) / 2;
                int ty = getHeight() - 7;
                g2.drawString(label, tx, ty);

                g2.dispose();
                
            }

            @Override public Dimension getPreferredSize() { return new Dimension(SIDEBAR_COLLAPSED, 62); }
            @Override public Dimension getMaximumSize()   { return new Dimension(SIDEBAR_COLLAPSED, 62); }
            @Override public Dimension getMinimumSize()   { return new Dimension(SIDEBAR_COLLAPSED, 62); }
        };

        btn.setOpaque(false);
        btn.setContentAreaFilled(false);
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
        btn.setBackground(UITheme.SIDEBAR_BG);
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btn.setAlignmentX(Component.CENTER_ALIGNMENT);

        
        btn.setToolTipText(label);

        btn.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                if (!btn.getBackground().equals(UITheme.SIDEBAR_ACTIVE))
                    btn.setBackground(UITheme.SIDEBAR_HOVER);
            }
            public void mouseExited(MouseEvent e) {
                if (!btn.getBackground().equals(UITheme.SIDEBAR_ACTIVE))
                    btn.setBackground(UITheme.SIDEBAR_BG);
            }
        });

        btn.addActionListener(e -> {
            setActiveNav(label, btn);
            action.run();
        });

        navButtons.put(label, btn);
        sidebarPanel.add(btn);
        sidebarPanel.add(Box.createVerticalStrut(2));
    }

    
    private void drawIcon(Graphics2D g2, String key, int cx, int cy, Color color, boolean active) {
        g2.setColor(color);
        g2.setStroke(new BasicStroke(1.8f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        int s = 10; 

        switch (key.toLowerCase()) {
            case "home": {
                
                int[] hx = {cx, cx + s, cx + s - 2, cx - s + 2, cx - s};
                int[] hy = {cy - s, cy, cy + s, cy + s, cy};
                g2.drawPolygon(hx, hy, 5);
                
                g2.drawRect(cx - 3, cy + 2, 6, s - 2);
                break;
            }
            case "courses": {
                
                g2.drawLine(cx, cy - s + 2, cx, cy + s - 2);
                g2.drawArc(cx - s, cy - s + 2, s, s * 2 - 4, 90, 180);
                g2.drawArc(cx, cy - s + 2, s, s * 2 - 4, -90, 180);
                break;
            }
            case "assignments": {
                
                g2.drawRoundRect(cx - s + 2, cy - s + 2, (s - 2) * 2, (s - 2) * 2, 4, 4);
                g2.drawLine(cx - 3, cy - s + 2, cx + 3, cy - s + 2);
                
                g2.drawLine(cx - 4, cy + 1, cx - 1, cy + 4);
                g2.drawLine(cx - 1, cy + 4, cx + 5, cy - 3);
                break;
            }
            case "grades": {
                
                g2.fillRect(cx - s + 1, cy + 2, 5, s - 2);
                g2.fillRect(cx - 2,    cy - 2, 5, s + 2);
                g2.fillRect(cx + s - 5, cy - s + 1, 5, s * 2 - 1);
                break;
            }
            case "gradeentry": {
                
                g2.drawLine(cx - s + 2, cy - 2, cx + 2, cy - 2);
                g2.drawLine(cx - s + 2, cy + 2, cx + 2, cy + 2);
                g2.drawLine(cx + 4, cy - s, cx + s - 1, cy - 3);
                g2.drawLine(cx + s - 1, cy - 3, cx + 4, cy + 2);
                break;
            }
            case "calendar": {
                
                g2.drawRoundRect(cx - s + 1, cy - s + 3, (s - 1) * 2, (s - 3) * 2, 4, 4);
                g2.drawLine(cx - s + 1, cy - s + 9, cx + s - 1, cy - s + 9);
                g2.drawLine(cx - 3, cy - s + 3, cx - 3, cy - s - 1);
                g2.drawLine(cx + 3, cy - s + 3, cx + 3, cy - s - 1);
                
                g2.fillOval(cx - 6, cy - 2, 3, 3);
                g2.fillOval(cx - 1, cy - 2, 3, 3);
                g2.fillOval(cx + 4, cy - 2, 3, 3);
                break;
            }
            case "notices":
            case "announcements": {
                
                g2.drawArc(cx - 6, cy - s + 2, 12, 12, 0, 180);
                g2.drawLine(cx - 6, cy + 2, cx + 6, cy + 2);
                g2.drawLine(cx - 6, cy + 2, cx - 6, cy - s + 8);
                g2.drawLine(cx + 6, cy + 2, cx + 6, cy - s + 8);
                g2.drawArc(cx - 3, cy + 2, 6, 5, 180, 180);
                g2.fillOval(cx - 1, cy - s + 2, 3, 3);
                break;
            }
            case "fee": {
                
                g2.drawOval(cx - s + 3, cy - s + 3, (s - 3) * 2, (s - 3) * 2);
                g2.setFont(UITheme.font(Font.BOLD, 11));
                FontMetrics fm = g2.getFontMetrics();
                g2.drawString("$", cx - fm.stringWidth("$") / 2, cy + fm.getAscent() / 2 - 1);
                break;
            }
            case "profile": {
                
                g2.drawOval(cx - 5, cy - s + 1, 10, 10);
                g2.drawArc(cx - 8, cy + 2, 16, 12, 0, 180);
                break;
            }
            case "students": {
                
                g2.drawOval(cx - 7, cy - s + 1, 8, 8);
                g2.drawArc(cx - 10, cy + 1, 12, 9, 0, 180);
                g2.drawOval(cx + 1, cy - s + 3, 7, 7);
                g2.drawArc(cx - 1, cy + 3, 12, 8, 0, 180);
                break;
            }
            case "teachers": {
                
                g2.drawRoundRect(cx - s + 1, cy - s + 1, (s - 1) * 2, s + 3, 4, 4);
                g2.drawLine(cx, cy + 4, cx, cy + s);
                g2.drawLine(cx - 3, cy + s, cx + 3, cy + s);
                
                g2.drawOval(cx - 2, cy - s + 3, 5, 5);
                break;
            }
            case "admins": {
                
                int[] ax = {cx, cx + s - 2, cx + s - 2, cx, cx - s + 2, cx - s + 2};
                int[] ay = {cy - s, cy - s + 4, cy + 1, cy + s, cy + 1, cy - s + 4};
                g2.drawPolygon(ax, ay, 6);
                
                g2.setFont(UITheme.font(Font.BOLD, 9));
                FontMetrics fm2 = g2.getFontMetrics();
                g2.drawString("*", cx - fm2.stringWidth("*") / 2, cy + fm2.getAscent() / 2);
                break;
            }
            default: {
                
                g2.drawOval(cx - s + 2, cy - s + 2, (s - 2) * 2, (s - 2) * 2);
                if (!key.isEmpty()) {
                    g2.setFont(UITheme.font(Font.BOLD, 11));
                    FontMetrics fm = g2.getFontMetrics();
                    String ch = key.substring(0, 1).toUpperCase();
                    g2.drawString(ch, cx - fm.stringWidth(ch) / 2, cy + fm.getAscent() / 2 - 1);
                }
                break;
            }
        }
    }

    
    protected void setActiveNav(String label, JButton btn) {
        for (JButton b : navButtons.values()) {
            b.setBackground(UITheme.SIDEBAR_BG);
            b.repaint();
        }
        btn.setBackground(UITheme.SIDEBAR_ACTIVE);
        btn.repaint();
        activeNav = label;
    }

    
    private JPanel makeSidebarDivider() {
        JPanel p = new JPanel() {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setColor(new Color(255, 255, 255, 22));
                g2.fillRect(12, 0, getWidth() - 24, 1);
                g2.dispose();
            }
            @Override public Dimension getPreferredSize() { return new Dimension(SIDEBAR_COLLAPSED, 1); }
            @Override public Dimension getMaximumSize()   { return new Dimension(SIDEBAR_COLLAPSED, 8); }
        };
        p.setOpaque(false);
        return p;
    }

    protected void showContent(JPanel panel) {
        contentArea.removeAll();
        contentArea.add(panel, BorderLayout.CENTER);
        contentArea.revalidate();
        contentArea.repaint();
    }

    protected void logout() {
        int c = JOptionPane.showConfirmDialog(this, "Are you sure you want to sign out?",
                "Sign Out", JOptionPane.YES_NO_OPTION);
        if (c == JOptionPane.YES_OPTION) {
            dispose();
            new LoginFrame().setVisible(true);
        }
    }

    protected abstract void addNavigationItems();
    protected abstract void showDefaultPanel();

    
    /**
     * Builds a self-contained panel showing the current profile picture
     * (or a placeholder) plus an "Upload Photo" button.
     * After a successful upload the user's profilePicturePath is updated,
     * the top-bar avatar is refreshed, and persistCallback.run() is called
     * so the subclass can persist the change.
     */
    protected JPanel buildProfilePicturePanel(Runnable persistCallback) {
        
        new File(PROFILE_PICS_DIR).mkdirs();

        
        JPanel card = new JPanel(new GridBagLayout()) {
            @Override protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(new Color(0, 0, 0, 6));
                g2.fillRoundRect(2, 2, getWidth() - 2, getHeight() - 2, 14, 14);
                g2.setColor(Color.WHITE);
                g2.fillRoundRect(0, 0, getWidth() - 2, getHeight() - 2, 14, 14);
                g2.dispose();
            }
        };
        card.setOpaque(false);
        card.setBorder(BorderFactory.createEmptyBorder(20, 24, 20, 24));

        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(8, 8, 8, 8);
        c.anchor = GridBagConstraints.CENTER;

        
        final int AV = 110;
        JPanel picDisplay = new JPanel() {
            @Override protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                
                g2.setColor(new Color(UITheme.PRIMARY.getRed(), UITheme.PRIMARY.getGreen(), UITheme.PRIMARY.getBlue(), 60));
                g2.setStroke(new BasicStroke(3f));
                g2.drawOval(1, 1, AV - 2, AV - 2);
                g2.setClip(new Ellipse2D.Float(3, 3, AV - 6, AV - 6));
                String picPath = currentUser.getProfilePicturePath();
                if (picPath != null && !picPath.isEmpty()) {
                    try {
                        BufferedImage img = ImageIO.read(new File(picPath));
                        if (img != null) {
                            g2.drawImage(img, 3, 3, AV - 6, AV - 6, null);
                            g2.dispose(); return;
                        }
                    } catch (IOException ex) {  }
                }
                
                g2.setPaint(new GradientPaint(0, 0, UITheme.ACCENT, AV, AV, UITheme.ACCENT_DARK));
                g2.fillRect(0, 0, AV, AV);
                g2.setClip(null);
                g2.setColor(Color.WHITE);
                g2.setFont(UITheme.font(Font.BOLD, 38));
                String init = currentUser.getName().substring(0, 1).toUpperCase();
                FontMetrics fm = g2.getFontMetrics();
                g2.drawString(init, (AV - fm.stringWidth(init)) / 2,
                        (AV - fm.getHeight()) / 2 + fm.getAscent());
                g2.dispose();
            }
            @Override public Dimension getPreferredSize() { return new Dimension(AV, AV); }
            @Override public Dimension getMinimumSize()   { return new Dimension(AV, AV); }
        };
        picDisplay.setOpaque(false);

        
        String roleText = currentUser.getRole().charAt(0)
                + currentUser.getRole().substring(1).toLowerCase();
        JLabel roleLbl = UITheme.label(roleText, UITheme.font(Font.BOLD, 11),
                new Color(UITheme.PRIMARY.getRed(), UITheme.PRIMARY.getGreen(), UITheme.PRIMARY.getBlue()));

        
        JButton uploadBtn = UITheme.primaryButton("Upload Photo");
        JButton removeBtn = UITheme.ghostButton("Remove");
        removeBtn.setVisible(!currentUser.getProfilePicturePath().isEmpty());

        uploadBtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        uploadBtn.addActionListener(e -> {
            JFileChooser fc = new JFileChooser();
            fc.setDialogTitle("Choose Profile Picture");
            fc.setFileFilter(new FileNameExtensionFilter(
                    "Image files (JPG, PNG, GIF, BMP)", "jpg", "jpeg", "png", "gif", "bmp"));
            fc.setAcceptAllFileFilterUsed(false);
            int result = fc.showOpenDialog(BaseDashboard.this);
            if (result != JFileChooser.APPROVE_OPTION) return;
            File chosen = fc.getSelectedFile();
            try {
                
                String ext = chosen.getName().contains(".")
                        ? chosen.getName().substring(chosen.getName().lastIndexOf('.'))
                        : ".jpg";
                Path dest = Paths.get(PROFILE_PICS_DIR, currentUser.getId() + ext);
                Files.copy(chosen.toPath(), dest, StandardCopyOption.REPLACE_EXISTING);
                currentUser.setProfilePicturePath(dest.toString());
                persistCallback.run();
                picDisplay.repaint();
                if (topBarAvatar != null) topBarAvatar.repaint();
                removeBtn.setVisible(true);
                JOptionPane.showMessageDialog(BaseDashboard.this,
                        "Profile picture updated successfully!", "Success",
                        JOptionPane.INFORMATION_MESSAGE);
            } catch (IOException ex) {
                JOptionPane.showMessageDialog(BaseDashboard.this,
                        "Failed to save image: " + ex.getMessage(), "Error",
                        JOptionPane.ERROR_MESSAGE);
            }
        });

        removeBtn.addActionListener(e -> {
            int confirm = JOptionPane.showConfirmDialog(BaseDashboard.this,
                    "Remove your profile picture?", "Confirm",
                    JOptionPane.YES_NO_OPTION);
            if (confirm != JOptionPane.YES_OPTION) return;
            currentUser.setProfilePicturePath("");
            persistCallback.run();
            picDisplay.repaint();
            if (topBarAvatar != null) topBarAvatar.repaint();
            removeBtn.setVisible(false);
        });

        JPanel btnRow = new JPanel(new FlowLayout(FlowLayout.CENTER, 8, 0));
        btnRow.setOpaque(false);
        btnRow.add(uploadBtn);
        btnRow.add(removeBtn);

        JLabel hintLbl = UITheme.label("JPG, PNG, GIF or BMP • Max recommended 2MB",
                UITheme.smallFont(), UITheme.TEXT_MUTED);

        
        c.gridx = 0; c.gridy = 0;
        card.add(picDisplay, c);
        c.gridy = 1;
        card.add(UITheme.label(currentUser.getName(), UITheme.boldFont(), UITheme.TEXT_DARK), c);
        c.gridy = 2;
        card.add(roleLbl, c);
        c.gridy = 3;
        card.add(btnRow, c);
        c.gridy = 4;
        card.add(hintLbl, c);

        return card;
    }
}
