package utils;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.geom.*;
import java.awt.image.BufferedImage;

public class UITheme {

    // ── Core Palette ────────────────────────────────────────────────────────
    public static final Color PRIMARY         = new Color(10, 36, 99);
    public static final Color PRIMARY_LIGHT   = new Color(18, 55, 140);
    public static final Color PRIMARY_DARK    = new Color(5, 20, 60);
    public static final Color SECONDARY       = new Color(26, 86, 219);
    public static final Color ACCENT          = new Color(245, 158, 11);
    public static final Color ACCENT_LIGHT    = new Color(252, 196, 75);
    public static final Color ACCENT_DARK     = new Color(180, 110, 5);
    public static final Color TEAL            = new Color(13, 148, 136);
    public static final Color TEAL_LIGHT      = new Color(20, 184, 166);
    public static final Color PURPLE          = new Color(109, 40, 217);
    public static final Color PURPLE_LIGHT    = new Color(139, 92, 246);
    public static final Color ROSE            = new Color(225, 29, 72);
    public static final Color CYAN            = new Color(6, 182, 212);
    public static final Color EMERALD         = new Color(16, 185, 129);
    public static final Color INDIGO          = new Color(67, 56, 202);

    // ── Sidebar ─────────────────────────────────────────────────────────────
    public static final Color SIDEBAR_BG      = new Color(8, 28, 75);
    public static final Color SIDEBAR_HOVER   = new Color(18, 48, 110);
    public static final Color SIDEBAR_ACTIVE  = new Color(26, 86, 219);

    // ── Content / Cards ─────────────────────────────────────────────────────
    public static final Color CONTENT_BG      = new Color(224, 242, 255);   // sky blue background
    public static final Color CARD_BG         = Color.WHITE;
    public static final Color SKY_LIGHT       = new Color(186, 230, 253);   // sky-200
    public static final Color SKY_MED         = new Color(125, 211, 252);   // sky-300
    public static final Color SKY_DARK        = new Color(14, 165, 233);    // sky-500
    public static final Color SKY_DEEP        = new Color(2, 132, 199);     // sky-600
    public static final Color TEXT_DARK       = new Color(15, 23, 42);
    public static final Color TEXT_MEDIUM     = new Color(51, 65, 85);
    public static final Color TEXT_MUTED      = new Color(100, 116, 139);
    public static final Color BORDER_COLOR    = new Color(226, 232, 240);
    public static final Color BORDER_LIGHT    = new Color(241, 245, 249);

    // ── Status ───────────────────────────────────────────────────────────────
    public static final Color SUCCESS         = new Color(5, 150, 105);
    public static final Color SUCCESS_LIGHT   = new Color(209, 250, 229);
    public static final Color WARNING         = new Color(217, 119, 6);
    public static final Color WARNING_LIGHT   = new Color(254, 243, 199);
    public static final Color DANGER          = new Color(220, 38, 38);
    public static final Color DANGER_LIGHT    = new Color(254, 226, 226);
    public static final Color INFO            = new Color(37, 99, 235);
    public static final Color INFO_LIGHT      = new Color(219, 234, 254);

    // ── Table ────────────────────────────────────────────────────────────────
    public static final Color TABLE_HEADER    = new Color(2, 132, 199);     // sky-600
    public static final Color TABLE_ALT_ROW   = new Color(240, 249, 255);   // sky-50
    public static final Color HOVER           = new Color(239, 246, 255);
    public static final Color GOLD            = new Color(245, 158, 11);

    // ── Gradient Helpers ─────────────────────────────────────────────────────
    // Dashboard background gradient colours
    public static final Color BG_GRAD_TOP    = new Color(230, 238, 255);  // pale blue
    public static final Color BG_GRAD_BOT    = new Color(243, 240, 255);  // pale lavender

    // ── Fonts ────────────────────────────────────────────────────────────────
    public static Font font(int style, int size) {
        for (String name : new String[]{"Calibri", "Segoe UI", "SansSerif"}) {
            Font f = new Font(name, style, size);
            if (!f.getFamily().equals("Dialog")) return f;
        }
        return new Font("SansSerif", style, size);
    }

    public static Font titleFont()    { return font(Font.BOLD, 24); }
    public static Font headingFont()  { return font(Font.BOLD, 18); }
    public static Font subheadFont()  { return font(Font.BOLD, 14); }
    public static Font bodyFont()     { return font(Font.PLAIN, 13); }
    public static Font smallFont()    { return font(Font.PLAIN, 11); }
    public static Font boldFont()     { return font(Font.BOLD, 13); }
    public static Font captionFont()  { return font(Font.PLAIN, 12); }

    // ── Background panel with diagonal gradient ──────────────────────────────
    public static JPanel contentBackground() {
        return new JPanel(new BorderLayout()) {
            @Override protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                // Diagonal gradient background
                GradientPaint gp = new GradientPaint(
                    0, 0, BG_GRAD_TOP,
                    getWidth(), getHeight(), BG_GRAD_BOT
                );
                g2.setPaint(gp);
                g2.fillRect(0, 0, getWidth(), getHeight());
                // Subtle decorative circles
                g2.setColor(new Color(100, 140, 255, 18));
                g2.fillOval(getWidth() - 220, -60, 280, 280);
                g2.fillOval(-80, getHeight() - 180, 250, 250);
                g2.setColor(new Color(180, 120, 255, 12));
                g2.fillOval(getWidth() / 2, getHeight() - 100, 200, 200);
                g2.dispose();
            }
        };
    }

    // ── Gradient panel ────────────────────────────────────────────────────────
    public static JPanel gradientPanel(Color c1, Color c2, boolean horizontal) {
        return new JPanel() {
            @Override protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                GradientPaint gp = horizontal
                    ? new GradientPaint(0, 0, c1, getWidth(), 0, c2)
                    : new GradientPaint(0, 0, c1, 0, getHeight(), c2);
                g2.setPaint(gp);
                g2.fillRect(0, 0, getWidth(), getHeight());
            }
        };
    }

    // ── Stat Card ─────────────────────────────────────────────────────────────
    public static JPanel statCard(String value, String label, Color accent) {
        return statCard(value, label, accent, null);
    }

    public static JPanel statCard(String value, String label, Color accent, String icon) {
        JPanel card = new JPanel(new BorderLayout(0, 0)) {
            @Override protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                // Card shadow
                g2.setColor(new Color(accent.getRed(), accent.getGreen(), accent.getBlue(), 20));
                g2.fillRoundRect(3, 3, getWidth() - 3, getHeight() - 3, 16, 16);
                // Card body with subtle gradient
                GradientPaint gp = new GradientPaint(0, 0, Color.WHITE,
                    0, getHeight(), new Color(
                        Math.max(0, 255 - (255 - accent.getRed()) / 12),
                        Math.max(0, 255 - (255 - accent.getGreen()) / 12),
                        Math.max(0, 255 - (255 - accent.getBlue()) / 12)
                    ));
                g2.setPaint(gp);
                g2.fillRoundRect(0, 0, getWidth() - 3, getHeight() - 3, 16, 16);
                // Top accent bar
                g2.setColor(accent);
                g2.fillRoundRect(0, 0, getWidth() - 3, 6, 4, 4);
                // Border
                g2.setColor(new Color(accent.getRed(), accent.getGreen(), accent.getBlue(), 50));
                g2.setStroke(new BasicStroke(1.2f));
                g2.drawRoundRect(0, 0, getWidth() - 4, getHeight() - 4, 16, 16);
                g2.dispose();
            }
        };
        card.setOpaque(false);
        card.setBorder(BorderFactory.createEmptyBorder(18, 18, 16, 18));

        // Icon circle with symbol
        JPanel iconCircle = new JPanel() {
            @Override protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                // Gradient fill circle
                GradientPaint gp = new GradientPaint(0, 0,
                    new Color(accent.getRed(), accent.getGreen(), accent.getBlue(), 200),
                    42, 42, accent.darker());
                g2.setPaint(gp);
                g2.fillOval(0, 0, 42, 42);
                // Draw icon symbol based on label
                g2.setColor(Color.WHITE);
                String sym = getSymbolForLabel(label, icon);
                // Use a font that supports Unicode/emoji symbols
                Font symFont = getSymbolFont(sym, 16);
                g2.setFont(symFont);
                FontMetrics fm = g2.getFontMetrics();
                g2.drawString(sym, (42 - fm.stringWidth(sym)) / 2,
                    (42 - fm.getHeight()) / 2 + fm.getAscent());
                g2.dispose();
            }
            @Override public Dimension getPreferredSize() { return new Dimension(42, 42); }
        };
        iconCircle.setOpaque(false);

        JLabel valLbl = new JLabel(value);
        valLbl.setFont(new Font("Calibri", Font.BOLD, 30));
        valLbl.setForeground(TEXT_DARK);

        JLabel nameLbl = new JLabel(label.toUpperCase());
        nameLbl.setFont(font(Font.BOLD, 10));
        nameLbl.setForeground(TEXT_MUTED);

        JPanel textPanel = new JPanel();
        textPanel.setLayout(new BoxLayout(textPanel, BoxLayout.Y_AXIS));
        textPanel.setOpaque(false);
        textPanel.add(valLbl);
        textPanel.add(Box.createVerticalStrut(3));
        textPanel.add(nameLbl);

        card.add(textPanel, BorderLayout.CENTER);
        card.add(iconCircle, BorderLayout.EAST);
        return card;
    }

    public static Font getSymbolFontPublic(String sym, int size) { return getSymbolFont(sym, size); }
    private static Font getSymbolFont(String sym, int size) {
        // Try fonts that support Unicode symbols and emoji in order of preference
        for (String name : new String[]{"Segoe UI Symbol", "Segoe UI Emoji", "Apple Color Emoji",
                                         "Noto Emoji", "Dialog", "SansSerif"}) {
            Font f = new Font(name, Font.BOLD, size);
            if (f.canDisplayUpTo(sym) == -1) return f; // -1 means full support
        }
        return new Font("Dialog", Font.BOLD, size);
    }

    private static String getSymbolForLabel(String label, String icon) {
        // If an explicit icon is passed and is a meaningful symbol (not a placeholder), use it
        if (icon != null && !icon.isEmpty() && !icon.equals("#") && !icon.equals("*")
                && !icon.equals("") && !icon.equals("-") && !icon.equals(">>")) {
            return icon;
        }
        if (label == null) return "\u25CF"; // ●
        String l = label.toLowerCase();
        if (l.contains("student"))                              return "\uD83D\uDC64"; // 👤
        if (l.contains("teacher") || l.contains("faculty"))    return "\uD83D\uDC68\u200D\uD83C\uDFEB"; // 👨‍🏫
        if (l.contains("course") || l.contains("enroll"))      return "\uD83D\uDCDA"; // 📚
        if (l.contains("cgpa") || l.contains("gpa"))           return "\uD83C\uDFC6"; // 🏆
        if (l.contains("grade") || l.contains("complet"))      return "\u2B50"; // ⭐
        if (l.contains("assign"))                              return "\uD83D\uDCCB"; // 📋
        if (l.contains("fee") || l.contains("paid"))           return "\uD83D\uDCB0"; // 💰
        if (l.contains("credit"))                              return "\uD83D\uDCCA"; // 📊
        if (l.contains("year") || l.contains("sem"))           return "\uD83D\uDCC5"; // 📅
        if (l.contains("notice") || l.contains("ann"))         return "\uD83D\uDCE2"; // 📢
        if (l.contains("pending") || l.contains("applic"))     return "\u23F3"; // ⏳
        if (l.contains("depart"))                              return "\uD83C\uDFDB"; // 🏛
        if (l.contains("total"))                               return "\uD83D\uDCCA"; // 📊
        if (l.contains("active") || l.contains("my"))         return "\u2705"; // ✅
        return "\u25CF"; // ●
    }

    private static String getQuickButtonSymbol(String icon, String label) {
        // Map common action labels to emoji
        if (label == null) return "\u25CF";
        String l = label.toLowerCase();
        if (l.contains("add student"))    return "\uD83D\uDC64"; // 👤
        if (l.contains("add teacher"))    return "\uD83D\uDC68\u200D\uD83C\uDFEB"; // 👨‍🏫
        if (l.contains("add course"))     return "\uD83D\uDCDA"; // 📚
        if (l.contains("announce"))       return "\uD83D\uDCE2"; // 📢
        if (l.contains("view student"))   return "\uD83D\uDC65"; // 👥
        if (l.contains("manage"))         return "\u2699"; // ⚙
        if (l.contains("fee"))            return "\uD83D\uDCB0"; // 💰
        if (l.contains("report"))         return "\uD83D\uDCCA"; // 📊
        if (l.contains("grade"))          return "\u2B50"; // ⭐
        if (l.contains("assign"))         return "\uD83D\uDCCB"; // 📋
        if (l.contains("course"))         return "\uD83D\uDCDA"; // 📚
        if (l.contains("student"))        return "\uD83D\uDC64"; // 👤
        if (l.contains("teacher"))        return "\uD83D\uDC68\u200D\uD83C\uDFEB"; // 👨‍🏫
        if (l.contains("schedule"))       return "\uD83D\uDCC5"; // 📅
        if (l.contains("setting"))        return "\u2699"; // ⚙
        if (l.contains("logout") || l.contains("log out")) return "\uD83D\uDEAA"; // 🚪
        if (l.contains("profile"))        return "\uD83D\uDC64"; // 👤
        if (l.contains("notice"))         return "\uD83D\uDCEC"; // 📬
        if (l.contains("submit"))         return "\u2705"; // ✅
        if (l.contains("upload"))         return "\uD83D\uDCE4"; // 📤
        if (l.contains("download"))       return "\uD83D\uDCE5"; // 📥
        if (l.contains("search"))         return "\uD83D\uDD0D"; // 🔍
        if (l.contains("challan"))        return "\uD83D\uDCB3"; // 💳
        if (l.contains("application"))    return "\uD83D\uDCDD"; // 📝
        if (icon != null && !icon.isEmpty() && !icon.equals("+") && !icon.equals(">>")
            && !icon.equals("=") && !icon.equals("-")) return icon;
        // Fallback: use icon character if it seems meaningful
        if (icon != null && icon.equals("+")) return "\u2795"; // ➕
        return "\u25CF"; // ●
    }

    // ── Dashboard Header Banner ───────────────────────────────────────────────
    public static JPanel dashboardHeader(String title, String subtitle, Color c1, Color c2) {
        JPanel header = new JPanel(new BorderLayout()) {
            @Override protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                // Rich gradient
                GradientPaint gp = new GradientPaint(0, 0, c1, getWidth(), getHeight(), c2);
                g2.setPaint(gp);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 0, 0);
                // Decorative geometric overlay
                g2.setColor(new Color(255, 255, 255, 15));
                g2.fillOval(getWidth() - 150, -50, 200, 200);
                g2.fillOval(getWidth() - 80, 10, 110, 110);
                g2.setColor(new Color(255, 255, 255, 8));
                g2.fillOval(getWidth() - 250, -20, 150, 150);
                // Accent sparkle dots
                g2.setColor(new Color(ACCENT.getRed(), ACCENT.getGreen(), ACCENT.getBlue(), 80));
                g2.fillOval(40, 12, 8, 8);
                g2.fillOval(60, 20, 5, 5);
                g2.fillOval(30, 24, 4, 4);
                g2.dispose();
            }
        };
        header.setBorder(BorderFactory.createEmptyBorder(22, 30, 22, 30));

        JPanel texts = new JPanel(new GridLayout(2, 1, 0, 5));
        texts.setOpaque(false);
        JLabel titleLbl = new JLabel(title);
        titleLbl.setFont(font(Font.BOLD, 24));
        titleLbl.setForeground(Color.WHITE);
        JLabel subLbl = new JLabel(subtitle);
        subLbl.setFont(font(Font.PLAIN, 13));
        subLbl.setForeground(new Color(220, 230, 250));
        texts.add(titleLbl);
        texts.add(subLbl);
        header.add(texts, BorderLayout.WEST);
        return header;
    }

    // ── Section Header ────────────────────────────────────────────────────────
    public static JPanel sectionHeader(String title) {
        JPanel p = new JPanel(new BorderLayout(8, 0));
        p.setOpaque(false);
        p.setBorder(BorderFactory.createEmptyBorder(0, 0, 12, 0));

        JPanel accent = new JPanel() {
            @Override public Dimension getPreferredSize() { return new Dimension(5, 22); }
            @Override protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                GradientPaint gp = new GradientPaint(0, 0, SECONDARY, 0, getHeight(), PURPLE_LIGHT);
                g2.setPaint(gp);
                g2.fillRoundRect(0, 0, 5, getHeight(), 5, 5);
                g2.dispose();
            }
        };
        accent.setOpaque(false);

        JLabel l = new JLabel(title);
        l.setFont(subheadFont());
        l.setForeground(TEXT_DARK);

        p.add(accent, BorderLayout.WEST);
        p.add(l, BorderLayout.CENTER);
        return p;
    }

    // ── Card ──────────────────────────────────────────────────────────────────
    public static JPanel card() {
        JPanel p = new JPanel() {
            @Override protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                // Shadow
                g2.setColor(new Color(100, 140, 220, 14));
                g2.fillRoundRect(3, 3, getWidth() - 2, getHeight() - 2, 14, 14);
                // White card
                g2.setColor(Color.WHITE);
                g2.fillRoundRect(0, 0, getWidth() - 3, getHeight() - 3, 14, 14);
                // Subtle border
                g2.setColor(new Color(200, 215, 240, 120));
                g2.setStroke(new BasicStroke(1f));
                g2.drawRoundRect(0, 0, getWidth() - 4, getHeight() - 4, 14, 14);
                g2.dispose();
            }
        };
        p.setOpaque(false);
        p.setBorder(BorderFactory.createEmptyBorder(16, 16, 16, 16));
        return p;
    }

    // ── Announcement Row ──────────────────────────────────────────────────────
    public static JPanel announcementRow(String title, String meta, Color dot) {
        JPanel row = new JPanel(new BorderLayout(10, 0));
        row.setOpaque(false);
        row.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(0, 0, 1, 0, BORDER_LIGHT),
            BorderFactory.createEmptyBorder(9, 0, 9, 0)));

        JPanel dotPanel = new JPanel() {
            @Override protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                // Glowing dot
                g2.setColor(new Color(dot.getRed(), dot.getGreen(), dot.getBlue(), 50));
                g2.fillOval(-1, 3, 12, 12);
                g2.setColor(dot);
                g2.fillOval(1, 5, 8, 8);
                g2.dispose();
            }
            @Override public Dimension getPreferredSize() { return new Dimension(14, 22); }
        };
        dotPanel.setOpaque(false);

        JLabel titleLbl = new JLabel(title);
        titleLbl.setFont(boldFont());
        titleLbl.setForeground(TEXT_DARK);

        JLabel metaLbl = new JLabel(meta);
        metaLbl.setFont(smallFont());
        metaLbl.setForeground(TEXT_MUTED);

        JPanel textPanel = new JPanel(new GridLayout(2, 1, 0, 1));
        textPanel.setOpaque(false);
        textPanel.add(titleLbl);
        textPanel.add(metaLbl);

        row.add(dotPanel, BorderLayout.WEST);
        row.add(textPanel, BorderLayout.CENTER);
        return row;
    }

    // ── Schedule Row ──────────────────────────────────────────────────────────
    public static JPanel scheduleRow(String time, String desc, Color accent) {
        JPanel row = new JPanel(new BorderLayout(12, 0));
        row.setOpaque(false);
        row.setBorder(BorderFactory.createEmptyBorder(7, 0, 7, 0));

        JLabel timeLbl = new JLabel(time, SwingConstants.CENTER) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                GradientPaint gp = new GradientPaint(0, 0,
                    new Color(accent.getRed(), accent.getGreen(), accent.getBlue(), 40),
                    0, getHeight(),
                    new Color(accent.getRed(), accent.getGreen(), accent.getBlue(), 20));
                g2.setPaint(gp);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 8, 8);
                g2.setColor(new Color(accent.getRed(), accent.getGreen(), accent.getBlue(), 80));
                g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 8, 8);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        timeLbl.setFont(font(Font.BOLD, 10));
        timeLbl.setForeground(accent.darker());
        timeLbl.setPreferredSize(new Dimension(72, 24));
        timeLbl.setOpaque(false);

        JLabel descLbl = new JLabel(desc);
        descLbl.setFont(bodyFont());
        descLbl.setForeground(TEXT_MEDIUM);

        // Color indicator bar on left
        JPanel bar = new JPanel() {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                GradientPaint gp = new GradientPaint(0, 0, accent, 0, getHeight(), accent.darker());
                g2.setPaint(gp);
                g2.fillRoundRect(0, 2, 3, getHeight() - 4, 3, 3);
                g2.dispose();
            }
            @Override public Dimension getPreferredSize() { return new Dimension(6, 0); }
        };
        bar.setOpaque(false);

        row.add(bar, BorderLayout.WEST);
        row.add(timeLbl, BorderLayout.CENTER);

        JPanel right = new JPanel(new BorderLayout(8, 0));
        right.setOpaque(false);
        right.add(descLbl, BorderLayout.CENTER);
        row.add(right, BorderLayout.EAST);
        row.add(timeLbl, BorderLayout.WEST);
        row.add(descLbl, BorderLayout.CENTER);
        return row;
    }

    // ── Deadline Row ──────────────────────────────────────────────────────────
    public static JPanel deadlineRow(String title, String due) {
        JPanel row = new JPanel(new BorderLayout(8, 0));
        row.setOpaque(false);
        row.setBorder(BorderFactory.createEmptyBorder(7, 0, 7, 0));

        JLabel titleLbl = new JLabel("  ⚡ " + title);
        titleLbl.setFont(bodyFont());
        titleLbl.setForeground(TEXT_MEDIUM);

        JLabel dueLbl = new JLabel(due);
        dueLbl.setFont(font(Font.BOLD, 11));
        dueLbl.setForeground(WARNING);
        dueLbl.setHorizontalAlignment(SwingConstants.RIGHT);

        row.add(titleLbl, BorderLayout.CENTER);
        row.add(dueLbl, BorderLayout.EAST);
        return row;
    }

    // ── Quick Button ──────────────────────────────────────────────────────────
    public static JButton quickButton(String icon, String label, Color accent) {
        JButton btn = new JButton() {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                // Gradient background
                Color bg1 = getModel().isPressed()
                    ? new Color(accent.getRed(), accent.getGreen(), accent.getBlue(), 40)
                    : getModel().isRollover()
                    ? new Color(accent.getRed(), accent.getGreen(), accent.getBlue(), 28)
                    : Color.WHITE;
                Color bg2 = getModel().isRollover()
                    ? new Color(accent.getRed(), accent.getGreen(), accent.getBlue(), 12)
                    : new Color(248, 250, 255);
                GradientPaint gp = new GradientPaint(0, 0, bg1, 0, getHeight(), bg2);
                g2.setPaint(gp);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 14, 14);
                g2.setColor(new Color(accent.getRed(), accent.getGreen(), accent.getBlue(), 90));
                g2.setStroke(new BasicStroke(1.2f));
                g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 14, 14);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        btn.setLayout(new GridLayout(2, 1, 0, 2));
        btn.setFocusPainted(false);
        btn.setContentAreaFilled(false);
        btn.setBorderPainted(false);
        btn.setOpaque(false);
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btn.setBorder(BorderFactory.createEmptyBorder(12, 8, 12, 8));

        JPanel iconDot = new JPanel() {
            @Override protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                GradientPaint gp = new GradientPaint(0, 0, accent,
                    28, 28, new Color(accent.getRed() / 2, accent.getGreen() / 2, accent.getBlue() / 2 + 40));
                g2.setPaint(gp);
                g2.fillOval(0, 0, 28, 28);
                // Symbol
                g2.setColor(Color.WHITE);
                String sym = getQuickButtonSymbol(icon, label);
                Font symFont = getSymbolFont(sym, 13);
                g2.setFont(symFont);
                FontMetrics fm = g2.getFontMetrics();
                g2.drawString(sym, (28 - fm.stringWidth(sym)) / 2, (28 - fm.getHeight()) / 2 + fm.getAscent());
                g2.dispose();
            }
            @Override public Dimension getPreferredSize() { return new Dimension(28, 28); }
        };
        iconDot.setOpaque(false);

        JLabel textLbl = new JLabel(label, SwingConstants.CENTER);
        textLbl.setFont(font(Font.BOLD, 11));
        textLbl.setForeground(TEXT_MEDIUM);

        btn.add(iconDot);
        btn.add(textLbl);
        return btn;
    }

    // ── Buttons ───────────────────────────────────────────────────────────────
    public static JButton primaryButton(String text) {
        JButton btn = makeGradientButton(text, PRIMARY, PRIMARY_LIGHT, Color.WHITE);
        btn.setBorder(BorderFactory.createEmptyBorder(9, 22, 9, 22));
        return btn;
    }

    public static JButton accentButton(String text) {
        JButton btn = makeGradientButton(text, SECONDARY, new Color(37, 99, 235), Color.WHITE);
        btn.setBorder(BorderFactory.createEmptyBorder(8, 20, 8, 20));
        return btn;
    }

    public static JButton dangerButton(String text) {
        JButton btn = makeGradientButton(text, DANGER, new Color(185, 28, 28), Color.WHITE);
        btn.setBorder(BorderFactory.createEmptyBorder(8, 20, 8, 20));
        return btn;
    }

    public static JButton successButton(String text) {
        JButton btn = makeGradientButton(text, SUCCESS, new Color(4, 120, 87), Color.WHITE);
        btn.setBorder(BorderFactory.createEmptyBorder(8, 20, 8, 20));
        return btn;
    }

    public static JButton ghostButton(String text) {
        JButton btn = new JButton(text) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                Color bg = getModel().isRollover() ? HOVER : Color.WHITE;
                g2.setColor(bg);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 8, 8);
                g2.setColor(BORDER_COLOR);
                g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 8, 8);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        btn.setFont(boldFont());
        btn.setForeground(TEXT_DARK);
        btn.setContentAreaFilled(false);
        btn.setBorderPainted(false);
        btn.setFocusPainted(false);
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btn.setBorder(BorderFactory.createEmptyBorder(8, 18, 8, 18));
        return btn;
    }

    private static JButton makeGradientButton(String text, Color c1, Color c2, Color fg) {
        JButton btn = new JButton(text) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                GradientPaint gp = getModel().isRollover()
                    ? new GradientPaint(0, 0, c2, getWidth(), 0, c1)
                    : new GradientPaint(0, 0, c1, getWidth(), 0, c2);
                g2.setPaint(gp);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 10, 10);
                // Sheen
                g2.setColor(new Color(255, 255, 255, 30));
                g2.fillRoundRect(0, 0, getWidth(), getHeight() / 2, 10, 10);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        btn.setFont(boldFont());
        btn.setForeground(fg);
        btn.setContentAreaFilled(false);
        btn.setBorderPainted(false);
        btn.setFocusPainted(false);
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        return btn;
    }

    // ── Form Fields ───────────────────────────────────────────────────────────
    public static JTextField styledField() {
        JTextField f = new JTextField();
        f.setFont(bodyFont());
        f.setBackground(new Color(248, 250, 252));
        f.setForeground(TEXT_DARK);
        f.setCaretColor(PRIMARY);
        f.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(BORDER_COLOR, 1),
            BorderFactory.createEmptyBorder(9, 12, 9, 12)));
        return f;
    }

    public static JPasswordField styledPasswordField() {
        JPasswordField f = new JPasswordField();
        f.setFont(bodyFont());
        f.setBackground(new Color(248, 250, 252));
        f.setForeground(TEXT_DARK);
        f.setCaretColor(PRIMARY);
        f.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(BORDER_COLOR, 1),
            BorderFactory.createEmptyBorder(9, 12, 9, 12)));
        return f;
    }

    public static JComboBox<String> styledCombo(String[] items) {
        JComboBox<String> cb = new JComboBox<>(items);
        cb.setFont(bodyFont());
        cb.setBackground(new Color(248, 250, 252));
        cb.setForeground(TEXT_DARK);
        return cb;
    }

    // ── Labels ────────────────────────────────────────────────────────────────
    public static JLabel label(String text, Font f, Color c) {
        JLabel l = new JLabel(text);
        l.setFont(f);
        l.setForeground(c);
        return l;
    }

    public static JLabel badge(String text, Color bg, Color fg) {
        JLabel lbl = new JLabel(text.toUpperCase(), SwingConstants.CENTER) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                GradientPaint gp = new GradientPaint(0, 0, bg, 0, getHeight(), bg.darker());
                g2.setPaint(gp);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 20, 20);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        lbl.setFont(font(Font.BOLD, 10));
        lbl.setForeground(fg);
        lbl.setOpaque(false);
        lbl.setBorder(BorderFactory.createEmptyBorder(3, 10, 3, 10));
        return lbl;
    }

    // ── Table ─────────────────────────────────────────────────────────────────
    public static void styleTable(JTable table) {
        table.setFont(bodyFont());
        table.setRowHeight(44);
        table.setShowGrid(false);
        table.setIntercellSpacing(new Dimension(0, 1));
        table.setSelectionBackground(new Color(186, 230, 253, 200)); // SKY_LIGHT
        table.setSelectionForeground(new Color(2, 132, 199));         // SKY_DEEP
        table.setBackground(CARD_BG);
        table.setFillsViewportHeight(true);
        // Header: sky blue gradient
        table.getTableHeader().setFont(font(Font.BOLD, 12));
        table.getTableHeader().setBackground(TABLE_HEADER);
        table.getTableHeader().setForeground(Color.WHITE);
        table.getTableHeader().setPreferredSize(new Dimension(0, 48));
        table.getTableHeader().setBorder(BorderFactory.createEmptyBorder());
        table.getTableHeader().setDefaultRenderer(new javax.swing.table.DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable t, Object value, boolean isSelected,
                    boolean hasFocus, int row, int col) {
                JLabel lbl = (JLabel) super.getTableCellRendererComponent(t, value, isSelected, hasFocus, row, col);
                // Painted via a custom panel for gradient
                JPanel hdrCell = new JPanel(new BorderLayout()) {
                    @Override protected void paintComponent(Graphics g) {
                        Graphics2D g2 = (Graphics2D) g.create();
                        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                        GradientPaint gp = new GradientPaint(0, 0, new Color(2, 132, 199),
                                0, getHeight(), new Color(14, 165, 233));
                        g2.setPaint(gp);
                        g2.fillRect(0, 0, getWidth(), getHeight());
                        // right divider
                        g2.setColor(new Color(255,255,255,30));
                        g2.drawLine(getWidth()-1, 4, getWidth()-1, getHeight()-4);
                        g2.dispose();
                        super.paintComponent(g);
                    }
                };
                hdrCell.setOpaque(false);
                JLabel inner = new JLabel(value == null ? "" : value.toString());
                inner.setFont(font(Font.BOLD, 12));
                inner.setForeground(Color.WHITE);
                inner.setBorder(BorderFactory.createEmptyBorder(0, 14, 0, 14));
                hdrCell.add(inner);
                return hdrCell;
            }
        });
        table.setDefaultRenderer(Object.class, new javax.swing.table.DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable t, Object v, boolean sel,
                    boolean foc, int row, int col) {
                super.getTableCellRendererComponent(t, v, sel, foc, row, col);
                if (sel) {
                    setBackground(new Color(186, 230, 253));
                    setForeground(new Color(2, 132, 199));
                    setFont(font(Font.BOLD, 13));
                } else {
                    setBackground(row % 2 == 0 ? Color.WHITE : new Color(240, 249, 255));
                    setForeground(TEXT_MEDIUM);
                    setFont(bodyFont());
                }
                setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(224, 242, 254, 150)),
                    BorderFactory.createEmptyBorder(0, 14, 0, 14)));
                return this;
            }
        });
    }

    public static JScrollPane scrollPane(Component c) {
        JScrollPane sp = new JScrollPane(c);
        sp.setBorder(BorderFactory.createLineBorder(BORDER_COLOR, 1));
        sp.getViewport().setBackground(CARD_BG);
        sp.getVerticalScrollBar().setPreferredSize(new Dimension(8, 0));
        return sp;
    }

    // ── Course Card ───────────────────────────────────────────────────────────
    public static JPanel courseCard(String courseId, String courseName, String schedule, String room, Color accent) {
        JPanel card = new JPanel(new BorderLayout(0, 6)) {
            @Override protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                // Shadow
                g2.setColor(new Color(accent.getRed(), accent.getGreen(), accent.getBlue(), 18));
                g2.fillRoundRect(3, 3, getWidth() - 2, getHeight() - 2, 16, 16);
                // Card gradient
                GradientPaint gp = new GradientPaint(0, 0, Color.WHITE,
                    0, getHeight(), new Color(
                        Math.max(0, 255 - (255 - accent.getRed()) / 10),
                        Math.max(0, 255 - (255 - accent.getGreen()) / 10),
                        255));
                g2.setPaint(gp);
                g2.fillRoundRect(0, 0, getWidth() - 2, getHeight() - 2, 16, 16);
                // Top bar
                g2.setPaint(new GradientPaint(0, 0, accent, getWidth(), 0, accent.darker()));
                g2.fillRoundRect(0, 0, getWidth() - 2, 7, 4, 4);
                // Border
                g2.setColor(new Color(accent.getRed(), accent.getGreen(), accent.getBlue(), 60));
                g2.setStroke(new BasicStroke(1f));
                g2.drawRoundRect(0, 0, getWidth() - 3, getHeight() - 3, 16, 16);
                g2.dispose();
            }
        };
        card.setOpaque(false);
        card.setBorder(BorderFactory.createEmptyBorder(18, 16, 16, 16));

        JLabel idLbl = label(courseId, font(Font.BOLD, 10), accent.darker());
        JLabel nameLbl = label(courseName, subheadFont(), TEXT_DARK);
        nameLbl.setBorder(BorderFactory.createEmptyBorder(4, 0, 4, 0));
        JLabel metaLbl = label("  ⏱ " + schedule + "   📍 " + room, smallFont(), TEXT_MUTED);

        JPanel content = new JPanel();
        content.setLayout(new BoxLayout(content, BoxLayout.Y_AXIS));
        content.setOpaque(false);
        content.add(idLbl);
        content.add(nameLbl);
        content.add(metaLbl);

        card.add(content, BorderLayout.CENTER);
        return card;
    }

    // ── Global Defaults ───────────────────────────────────────────────────────
    public static void applyGlobalDefaults() {
        UIManager.put("OptionPane.messageFont",      bodyFont());
        UIManager.put("OptionPane.buttonFont",       boldFont());
        UIManager.put("Button.font",                 boldFont());
        UIManager.put("Label.font",                  bodyFont());
        UIManager.put("TextField.font",              bodyFont());
        UIManager.put("ComboBox.font",               bodyFont());
        UIManager.put("Table.font",                  bodyFont());
        UIManager.put("TableHeader.font",            boldFont());
        UIManager.put("Panel.background",            CONTENT_BG);
        UIManager.put("OptionPane.background",       CARD_BG);
        UIManager.put("OptionPane.messageForeground",TEXT_DARK);
        UIManager.put("ScrollBar.width",             8);
    }
}
