package utils;

import models.*;

import java.io.*;
import java.util.*;
import java.util.stream.Collectors;

public class DataManager {

    private static final String DATA_DIR            = "data";
    private static final String STUDENTS_FILE       = DATA_DIR + "/students.csv";
    private static final String TEACHERS_FILE       = DATA_DIR + "/teachers.csv";
    private static final String ADMINS_FILE         = DATA_DIR + "/admins.csv";
    private static final String COURSES_FILE        = DATA_DIR + "/courses.csv";
    private static final String GRADES_FILE         = DATA_DIR + "/grades.csv";
    private static final String ENROLLMENTS_FILE    = DATA_DIR + "/enrollments.csv";
    private static final String ANNOUNCEMENTS_FILE  = DATA_DIR + "/announcements.csv";
    private static final String ASSIGNMENTS_FILE    = DATA_DIR + "/assignments.csv";
    private static final String PENDING_APPS_FILE   = DATA_DIR + "/pending_applications.csv";
    private static final String SUBMISSIONS_FILE    = DATA_DIR + "/submissions.csv";

    // ─────────────────────────────────────────────
    //  INITIALIZATION
    // ─────────────────────────────────────────────
    public static void initialize() {
        new File(DATA_DIR).mkdirs();
        seedIfEmpty();
    }

    private static void seedIfEmpty() {
        seedAdmins();
        seedTeachers();
        seedCourses();
        seedStudents();
        seedEnrollments();
        seedGrades();
        seedAnnouncements();
    }

    private static void seedAdmins() {
        if (new File(ADMINS_FILE).exists() && !fileIsEmpty(ADMINS_FILE)) return;
        List<Admin> list = new ArrayList<>();
        list.add(new Admin("ADM001","Super Admin","admin@university.edu","admin123","0300-1111111","Main Campus","SUPER"));
        list.add(new Admin("ADM002","John Registrar","registrar@university.edu","reg123","0300-2222222","Admin Block","REGULAR"));
        saveAdmins(list);
    }

    private static void seedTeachers() {
        if (new File(TEACHERS_FILE).exists() && !fileIsEmpty(TEACHERS_FILE)) return;
        List<Teacher> list = new ArrayList<>();
        list.add(new Teacher("TCH001","Dr. Sarah Johnson","sarah.j@university.edu","teach123","0301-1111111","Faculty Quarters","Computer Science","Associate Professor"));
        list.add(new Teacher("TCH002","Prof. Michael Brown","m.brown@university.edu","teach123","0301-2222222","Faculty Quarters","Mathematics","Professor"));
        list.add(new Teacher("TCH003","Dr. Emily Davis","e.davis@university.edu","teach123","0301-3333333","Faculty Quarters","English","Assistant Professor"));
        list.add(new Teacher("TCH004","Dr. Robert Wilson","r.wilson@university.edu","teach123","0301-4444444","Faculty Quarters","Physics","Associate Professor"));
        list.add(new Teacher("TCH005","Dr. Ayesha Khan","a.khan@university.edu","teach123","0301-5555555","Faculty Quarters","Islamic Studies","Assistant Professor"));
        list.add(new Teacher("TCH006","Dr. Ali Raza","a.raza@university.edu","teach123","0301-6666666","Faculty Quarters","Software Engineering","Associate Professor"));
        saveTeachers(list);
    }

    private static void seedCourses() {
        if (new File(COURSES_FILE).exists() && !fileIsEmpty(COURSES_FILE)) return;
        List<Course> cs = new ArrayList<>();

        // ── SEMESTER 1 ──────────────────────────────────────────────────────────
        cs.add(mk("CSIT-111","Intro to Info & Comm Tech","TCH001","Dr. Sarah Johnson",3,"Semester I","Mon/Wed 08:00-09:30","CS-101",50,
                "Introduction to ICT concepts, hardware, software, and internet fundamentals.",
                "Computer Science",1,
                "Week 1-2: Introduction to Computers and ICT\n" +
                "Week 3-4: Hardware Components and Architecture\n" +
                "Week 5-6: Operating Systems Overview\n" +
                "Week 7-8: Internet and Web Technologies\n" +
                "Week 9-10: Office Productivity Tools\n" +
                "Week 11-12: Data Communication Basics\n" +
                "Week 13-14: Cybersecurity Fundamentals\n" +
                "Week 15-16: Emerging Technologies & Lab Practice\n" +
                "Assessment: Assignments 20% | Midterm 30% | Final 50%"));

        cs.add(mk("CSPF-141","Programming Fundamentals","TCH001","Dr. Sarah Johnson",4,"Semester I","Mon/Wed/Fri 10:00-11:00","CS-201",45,
                "Basic programming concepts using Python: variables, loops, functions, and arrays.",
                "Computer Science",1,
                "Week 1-2: Introduction to Programming & Python Setup\n" +
                "Week 3-4: Variables, Data Types, and Operators\n" +
                "Week 5-6: Control Structures (if/else, loops)\n" +
                "Week 7-8: Functions and Modular Programming\n" +
                "Week 9-10: Lists, Tuples, and Dictionaries\n" +
                "Week 11-12: File I/O Basics\n" +
                "Week 13-14: Introduction to Algorithms\n" +
                "Week 15-16: Mini Project & Review\n" +
                "Assessment: Assignments 20% | Midterm 30% | Final 50%"));

        cs.add(mk("ESEC-112","English Composition & Comprehension","TCH003","Dr. Emily Davis",3,"Semester I","Tue/Thu 09:00-10:30","LNG-101",40,
                "Academic writing, reading comprehension, grammar, and critical thinking skills.",
                "English",1,
                "Week 1-2: Grammar Review and Sentence Structure\n" +
                "Week 3-4: Paragraph Writing Techniques\n" +
                "Week 5-6: Essay Writing (Narrative & Descriptive)\n" +
                "Week 7-8: Reading Comprehension Strategies\n" +
                "Week 9-10: Argumentative Writing\n" +
                "Week 11-12: Research-based Writing\n" +
                "Week 13-14: Editing and Proofreading\n" +
                "Week 15-16: Final Essay Workshop\n" +
                "Assessment: Assignments 20% | Midterm 30% | Final 50%"));

        cs.add(mk("SSPS-113","Pakistan Studies","TCH005","Dr. Ayesha Khan",2,"Semester I","Mon/Wed 12:00-13:00","HUM-101",60,
                "History, geography, culture, and political system of Pakistan.",
                "Social Sciences",1,
                "Week 1-3: Geography and Physical Features of Pakistan\n" +
                "Week 4-6: Historical Background (Pre-independence)\n" +
                "Week 7-9: Pakistan Movement and Independence\n" +
                "Week 10-12: Constitutional History\n" +
                "Week 13-14: Economic and Social Development\n" +
                "Week 15-16: Foreign Policy and Current Affairs\n" +
                "Assessment: Assignments 20% | Midterm 30% | Final 50%"));

        cs.add(mk("SSIS-114","Islamic Studies","TCH005","Dr. Ayesha Khan",2,"Semester I","Tue/Thu 12:00-13:00","HUM-102",60,
                "Islamic history, principles, and values in modern context.",
                "Islamic Studies",1,
                "Week 1-3: Fundamentals of Islam (Quran & Sunnah)\n" +
                "Week 4-6: Pillars of Islam\n" +
                "Week 7-9: Islamic History: Early Caliphate\n" +
                "Week 10-12: Islamic Civilization and Contributions\n" +
                "Week 13-14: Islam and Modern World\n" +
                "Week 15-16: Ethics in Islam\n" +
                "Assessment: Assignments 20% | Midterm 30% | Final 50%"));

        cs.add(mk("EEAP-121","Applied Physics","TCH004","Dr. Robert Wilson",3,"Semester I","Mon/Wed/Fri 14:00-15:00","SCI-201",40,
                "Mechanics, electricity, magnetism, and wave optics relevant to computing.",
                "Physics",1,
                "Week 1-2: Mechanics: Motion and Forces\n" +
                "Week 3-4: Work, Energy, and Power\n" +
                "Week 5-6: Electricity Fundamentals\n" +
                "Week 7-8: Circuits (Series and Parallel)\n" +
                "Week 9-10: Magnetism and Electromagnetic Induction\n" +
                "Week 11-12: Wave and Sound\n" +
                "Week 13-14: Optics and Light\n" +
                "Week 15-16: Modern Physics Concepts\n" +
                "Assessment: Assignments 20% | Midterm 30% | Final 50%"));

        // ── SEMESTER 2 ──────────────────────────────────────────────────────────
        cs.add(mk("CSOO-142","Object Oriented Programming","TCH001","Dr. Sarah Johnson",4,"Semester II","Mon/Wed 10:00-11:30","CS-202",45,
                "OOP concepts: classes, objects, inheritance, polymorphism, and encapsulation in Java.",
                "Computer Science",2,
                "Week 1-2: Introduction to OOP and Java\n" +
                "Week 3-4: Classes, Objects, and Constructors\n" +
                "Week 5-6: Encapsulation and Access Modifiers\n" +
                "Week 7-8: Inheritance and Method Overriding\n" +
                "Week 9-10: Polymorphism and Interfaces\n" +
                "Week 11-12: Abstract Classes and Exception Handling\n" +
                "Week 13-14: Collections Framework\n" +
                "Week 15-16: File I/O and Mini Project\n" +
                "Assessment: Assignments 20% | Midterm 30% | Final 50%"));

        cs.add(mk("ESPS-115","Communication & Presentation Skills","TCH003","Dr. Emily Davis",3,"Semester II","Tue/Thu 09:00-10:30","LNG-102",40,
                "Verbal and non-verbal communication, public speaking, and professional presentations.",
                "English",2,
                "Week 1-2: Fundamentals of Communication\n" +
                "Week 3-4: Non-verbal Communication\n" +
                "Week 5-6: Active Listening Skills\n" +
                "Week 7-8: Public Speaking Basics\n" +
                "Week 9-10: Presentation Design (PowerPoint)\n" +
                "Week 11-12: Group Presentations\n" +
                "Week 13-14: Business Communication\n" +
                "Week 15-16: Individual Presentation Projects\n" +
                "Assessment: Assignments 20% | Midterm 30% | Final 50%"));

        cs.add(mk("MTCA-122","Calculus & Analytical Geometry","TCH002","Prof. Michael Brown",3,"Semester II","Mon/Wed/Fri 08:00-09:00","MATH-201",45,
                "Limits, derivatives, integration, and analytical geometry fundamentals.",
                "Mathematics",2,
                "Week 1-2: Functions and Limits\n" +
                "Week 3-4: Differentiation Rules\n" +
                "Week 5-6: Applications of Derivatives\n" +
                "Week 7-8: Integration Techniques\n" +
                "Week 9-10: Definite Integrals and Area\n" +
                "Week 11-12: Analytical Geometry: Lines and Curves\n" +
                "Week 13-14: Conic Sections\n" +
                "Week 15-16: Applications and Review\n" +
                "Assessment: Assignments 20% | Midterm 30% | Final 50%"));

        cs.add(mk("CSDS-143","Discrete Structures","TCH002","Prof. Michael Brown",3,"Semester II","Tue/Thu 11:00-12:30","MATH-202",40,
                "Logic, set theory, relations, functions, graph theory, and combinatorics.",
                "Mathematics",2,
                "Week 1-2: Propositional Logic\n" +
                "Week 3-4: Predicate Logic and Proof Techniques\n" +
                "Week 5-6: Set Theory\n" +
                "Week 7-8: Relations and Functions\n" +
                "Week 9-10: Combinatorics and Counting\n" +
                "Week 11-12: Graph Theory Basics\n" +
                "Week 13-14: Trees and Graph Algorithms\n" +
                "Week 15-16: Boolean Algebra and Review\n" +
                "Assessment: Assignments 20% | Midterm 30% | Final 50%"));

        // ── SEMESTER 3 ──────────────────────────────────────────────────────────
        cs.add(mk("EEDL-201","Digital Logic Design","TCH004","Dr. Robert Wilson",4,"Semester III","Mon/Wed 10:00-11:30","EE-301",40,
                "Number systems, Boolean algebra, combinational and sequential logic circuits.",
                "Electrical Engineering",3,
                "Week 1-2: Number Systems and Codes\n" +
                "Week 3-4: Boolean Algebra and Logic Gates\n" +
                "Week 5-6: Combinational Logic: Adders, Mux, Decoders\n" +
                "Week 7-8: Karnaugh Maps\n" +
                "Week 9-10: Sequential Circuits: Flip-Flops\n" +
                "Week 11-12: Registers and Counters\n" +
                "Week 13-14: Memory and Programmable Logic\n" +
                "Week 15-16: Lab Project (Circuit Design)\n" +
                "Assessment: Assignments 20% | Midterm 30% | Final 50%"));

        cs.add(mk("CSDA-244","Data Structures & Algorithms","TCH001","Dr. Sarah Johnson",4,"Semester III","Tue/Thu 09:00-10:30","CS-301",40,
                "Arrays, linked lists, stacks, queues, trees, graphs, sorting, and searching algorithms.",
                "Computer Science",3,
                "Week 1-2: Algorithm Analysis (Big-O Notation)\n" +
                "Week 3-4: Arrays and Linked Lists\n" +
                "Week 5-6: Stacks and Queues\n" +
                "Week 7-8: Recursion and Divide & Conquer\n" +
                "Week 9-10: Binary Trees and BST\n" +
                "Week 11-12: Heaps and Priority Queues\n" +
                "Week 13-14: Sorting Algorithms\n" +
                "Week 15-16: Graph Algorithms and Review\n" +
                "Assessment: Assignments 20% | Midterm 30% | Final 50%"));

        cs.add(mk("MTLA-223","Linear Algebra","TCH002","Prof. Michael Brown",3,"Semester III","Mon/Wed/Fri 12:00-13:00","MATH-301",40,
                "Vectors, matrices, determinants, eigenvalues, and linear transformations.",
                "Mathematics",3,
                "Week 1-2: Vectors and Matrices\n" +
                "Week 3-4: Matrix Operations and Determinants\n" +
                "Week 5-6: Systems of Linear Equations\n" +
                "Week 7-8: Vector Spaces\n" +
                "Week 9-10: Linear Transformations\n" +
                "Week 11-12: Eigenvalues and Eigenvectors\n" +
                "Week 13-14: Orthogonality and Projection\n" +
                "Week 15-16: Applications in CS and Review\n" +
                "Assessment: Assignments 20% | Midterm 30% | Final 50%"));

        cs.add(mk("CSPP-216","Professional Practices","TCH006","Dr. Ali Raza",3,"Semester III","Tue/Thu 14:00-15:30","CS-302",50,
                "Ethics in computing, professional responsibilities, IPR, project management basics.",
                "Computer Science",3,
                "Week 1-2: Introduction to Professional Ethics\n" +
                "Week 3-4: Computing and Society\n" +
                "Week 5-6: Intellectual Property Rights\n" +
                "Week 7-8: Professional Codes of Conduct\n" +
                "Week 9-10: Project Management Fundamentals\n" +
                "Week 11-12: Risk Management\n" +
                "Week 13-14: Workplace Communication\n" +
                "Week 15-16: Case Studies and Review\n" +
                "Assessment: Assignments 20% | Midterm 30% | Final 50%"));

        // ── SEMESTER 4 ──────────────────────────────────────────────────────────
        cs.add(mk("CSAA-202","Design & Analysis of Algorithms","TCH001","Dr. Sarah Johnson",3,"Semester IV","Mon/Wed 09:00-10:30","CS-401",40,
                "Greedy algorithms, dynamic programming, NP-completeness, and algorithm optimization.",
                "Computer Science",4,
                "Week 1-2: Review of Algorithm Analysis\n" +
                "Week 3-4: Greedy Algorithms\n" +
                "Week 5-6: Dynamic Programming\n" +
                "Week 7-8: Backtracking and Branch & Bound\n" +
                "Week 9-10: Graph Algorithms (Dijkstra, Floyd-Warshall)\n" +
                "Week 11-12: String Matching Algorithms\n" +
                "Week 13-14: NP-Completeness\n" +
                "Week 15-16: Approximation Algorithms & Review\n" +
                "Assessment: Assignments 20% | Midterm 30% | Final 50%"));

        cs.add(mk("SESE-245","Software Engineering","TCH006","Dr. Ali Raza",3,"Semester IV","Tue/Thu 10:00-11:30","CS-402",45,
                "SDLC, requirements engineering, design patterns, testing, and project management.",
                "Software Engineering",4,
                "Week 1-2: Introduction to Software Engineering\n" +
                "Week 3-4: Requirements Engineering\n" +
                "Week 5-6: Software Design and Architecture\n" +
                "Week 7-8: UML and Design Patterns\n" +
                "Week 9-10: Software Testing Techniques\n" +
                "Week 11-12: Agile and Scrum Methodology\n" +
                "Week 13-14: Software Quality Assurance\n" +
                "Week 15-16: Group Project Presentations\n" +
                "Assessment: Assignments 20% | Midterm 30% | Final 50%"));

        cs.add(mk("CSWP-265","CS Elective I - Web Programming","TCH001","Dr. Sarah Johnson",3,"Semester IV","Mon/Wed/Fri 14:00-15:00","CS-403",40,
                "HTML, CSS, JavaScript, and introductory web frameworks for building web applications.",
                "Computer Science",4,
                "Week 1-2: HTML5 Fundamentals\n" +
                "Week 3-4: CSS3 Styling and Layouts\n" +
                "Week 5-6: JavaScript Basics\n" +
                "Week 7-8: DOM Manipulation\n" +
                "Week 9-10: Forms and Validation\n" +
                "Week 11-12: AJAX and Fetch API\n" +
                "Week 13-14: Introduction to Bootstrap\n" +
                "Week 15-16: Final Web Project\n" +
                "Assessment: Assignments 20% | Midterm 30% | Final 50%"));

        cs.add(mk("MTDE-225","CS Supporting II - Differential Equations","TCH002","Prof. Michael Brown",3,"Semester IV","Tue/Thu 12:00-13:30","MATH-401",35,
                "Ordinary differential equations and their applications in computing and engineering.",
                "Mathematics",4,
                "Week 1-2: Introduction to Differential Equations\n" +
                "Week 3-4: First Order ODEs\n" +
                "Week 5-6: Second Order Linear ODEs\n" +
                "Week 7-8: System of Differential Equations\n" +
                "Week 9-10: Laplace Transforms\n" +
                "Week 11-12: Series Solutions\n" +
                "Week 13-14: Partial Differential Equations (Intro)\n" +
                "Week 15-16: Applications and Review\n" +
                "Assessment: Assignments 20% | Midterm 30% | Final 50%"));

        // ── SEMESTER 5 ──────────────────────────────────────────────────────────
        cs.add(mk("CSDB-346","Database Systems","TCH001","Dr. Sarah Johnson",4,"Semester V","Mon/Wed 10:00-11:30","CS-501",45,
                "Relational model, SQL, normalization, transactions, and database design.",
                "Computer Science",5,
                "Week 1-2: Introduction to DBMS\n" +
                "Week 3-4: Entity-Relationship Model\n" +
                "Week 5-6: Relational Model & SQL Basics\n" +
                "Week 7-8: Advanced SQL (Joins, Subqueries)\n" +
                "Week 9-10: Normalization (1NF to BCNF)\n" +
                "Week 11-12: Transaction Management & ACID\n" +
                "Week 13-14: Indexing and Query Optimization\n" +
                "Week 15-16: NoSQL Introduction & Lab Project\n" +
                "Assessment: Assignments 20% | Midterm 30% | Final 50%"));

        cs.add(mk("CSCA-303","Computer Organization & Assembly Language","TCH004","Dr. Robert Wilson",4,"Semester V","Tue/Thu 09:00-10:30","CS-502",40,
                "Computer architecture, instruction sets, memory hierarchy, and assembly language programming.",
                "Computer Science",5,
                "Week 1-2: Computer Organization Overview\n" +
                "Week 3-4: Data Representation and Arithmetic\n" +
                "Week 5-6: CPU Architecture and ISA\n" +
                "Week 7-8: Assembly Language Programming (x86)\n" +
                "Week 9-10: Addressing Modes\n" +
                "Week 11-12: Memory Hierarchy (Cache, RAM, ROM)\n" +
                "Week 13-14: I/O Systems and Interrupts\n" +
                "Week 15-16: Lab Project\n" +
                "Assessment: Assignments 20% | Midterm 30% | Final 50%"));

        cs.add(mk("CSOS-347","Operating Systems","TCH006","Dr. Ali Raza",4,"Semester V","Mon/Wed 14:00-15:30","CS-503",40,
                "Process management, memory management, file systems, and OS design principles.",
                "Computer Science",5,
                "Week 1-2: Introduction to Operating Systems\n" +
                "Week 3-4: Process Management and Scheduling\n" +
                "Week 5-6: Inter-Process Communication\n" +
                "Week 7-8: Thread Management\n" +
                "Week 9-10: Memory Management (Paging, Segmentation)\n" +
                "Week 11-12: Virtual Memory\n" +
                "Week 13-14: File System Management\n" +
                "Week 15-16: Deadlock & OS Security\n" +
                "Assessment: Assignments 20% | Midterm 30% | Final 50%"));

        cs.add(mk("MTSP-326","Statistics & Probability","TCH002","Prof. Michael Brown",3,"Semester V","Fri 09:00-12:00","MATH-501",45,
                "Probability theory, random variables, distributions, hypothesis testing, and regression.",
                "Mathematics",5,
                "Week 1-2: Introduction to Probability\n" +
                "Week 3-4: Probability Distributions\n" +
                "Week 5-6: Random Variables (Discrete & Continuous)\n" +
                "Week 7-8: Normal and Binomial Distributions\n" +
                "Week 9-10: Sampling and Estimation\n" +
                "Week 11-12: Hypothesis Testing\n" +
                "Week 13-14: Regression Analysis\n" +
                "Week 15-16: Applications in CS\n" +
                "Assessment: Assignments 20% | Midterm 30% | Final 50%"));

        // ── SEMESTER 6 ──────────────────────────────────────────────────────────
        cs.add(mk("CSCN-348","Computer Networks","TCH004","Dr. Robert Wilson",4,"Semester VI","Mon/Wed 09:00-10:30","CS-601",40,
                "OSI model, TCP/IP, routing, switching, network security, and wireless networks.",
                "Computer Science",6,
                "Week 1-2: Introduction to Networks and OSI Model\n" +
                "Week 3-4: Physical and Data Link Layers\n" +
                "Week 5-6: Network Layer and IP Addressing\n" +
                "Week 7-8: Routing Protocols\n" +
                "Week 9-10: Transport Layer (TCP/UDP)\n" +
                "Week 11-12: Application Layer Protocols\n" +
                "Week 13-14: Network Security\n" +
                "Week 15-16: Wireless Networks & Lab Project\n" +
                "Assessment: Assignments 20% | Midterm 30% | Final 50%"));

        cs.add(mk("CSAI-304","Artificial Intelligence","TCH001","Dr. Sarah Johnson",4,"Semester VI","Tue/Thu 10:00-11:30","CS-602",40,
                "Search algorithms, knowledge representation, machine learning basics, and AI applications.",
                "Computer Science",6,
                "Week 1-2: Introduction to AI and Intelligent Agents\n" +
                "Week 3-4: Search Algorithms (BFS, DFS, A*)\n" +
                "Week 5-6: Heuristic Search and Game Playing\n" +
                "Week 7-8: Knowledge Representation (Logic)\n" +
                "Week 9-10: Expert Systems\n" +
                "Week 11-12: Machine Learning Fundamentals\n" +
                "Week 13-14: Neural Networks Basics\n" +
                "Week 15-16: AI Applications and Ethics\n" +
                "Assessment: Assignments 20% | Midterm 30% | Final 50%"));

        cs.add(mk("CSTA-305","Theory of Automata","TCH002","Prof. Michael Brown",3,"Semester VI","Mon/Wed/Fri 12:00-13:00","CS-603",40,
                "Finite automata, regular expressions, context-free grammars, and Turing machines.",
                "Computer Science",6,
                "Week 1-2: Introduction and Mathematical Preliminaries\n" +
                "Week 3-4: Finite Automata (DFA and NFA)\n" +
                "Week 5-6: Regular Expressions and Languages\n" +
                "Week 7-8: Pumping Lemma for Regular Languages\n" +
                "Week 9-10: Context-Free Grammars\n" +
                "Week 11-12: Pushdown Automata\n" +
                "Week 13-14: Turing Machines\n" +
                "Week 15-16: Computability and Complexity\n" +
                "Assessment: Assignments 20% | Midterm 30% | Final 50%"));

        cs.add(mk("ESTW-317","Technical & Business Writing","TCH003","Dr. Emily Davis",3,"Semester VI","Tue/Thu 14:00-15:30","LNG-601",45,
                "Technical documentation, report writing, proposals, and professional business communication.",
                "English",6,
                "Week 1-2: Technical Writing Fundamentals\n" +
                "Week 3-4: Technical Reports and Documentation\n" +
                "Week 5-6: Software Documentation (SRS, API Docs)\n" +
                "Week 7-8: Business Letters and Emails\n" +
                "Week 9-10: Proposals and Research Reports\n" +
                "Week 11-12: Resume and Cover Letter Writing\n" +
                "Week 13-14: Presentations and Infographics\n" +
                "Week 15-16: Peer Review and Final Report\n" +
                "Assessment: Assignments 20% | Midterm 30% | Final 50%"));

        // ── SEMESTER 7 ──────────────────────────────────────────────────────────
        cs.add(mk("CSCC-406","Compiler Construction","TCH001","Dr. Sarah Johnson",3,"Semester VII","Mon/Wed 10:00-11:30","CS-701",35,
                "Lexical analysis, parsing, semantic analysis, intermediate code, and code generation.",
                "Computer Science",7,
                "Week 1-2: Introduction to Compilers\n" +
                "Week 3-4: Lexical Analysis and Scanning\n" +
                "Week 5-6: Top-Down Parsing\n" +
                "Week 7-8: Bottom-Up Parsing (LR Parsers)\n" +
                "Week 9-10: Semantic Analysis\n" +
                "Week 11-12: Intermediate Code Generation\n" +
                "Week 13-14: Code Optimization\n" +
                "Week 15-16: Code Generation & Mini Compiler Project\n" +
                "Assessment: Assignments 20% | Midterm 30% | Final 50%"));

        cs.add(mk("CSIS-449","Information Security","TCH006","Dr. Ali Raza",3,"Semester VII","Tue/Thu 09:00-10:30","CS-702",40,
                "Cryptography, network security, access control, digital forensics, and ethical hacking.",
                "Computer Science",7,
                "Week 1-2: Introduction to Information Security\n" +
                "Week 3-4: Symmetric Cryptography\n" +
                "Week 5-6: Asymmetric Cryptography (PKI)\n" +
                "Week 7-8: Network Security Protocols\n" +
                "Week 9-10: Web Application Security\n" +
                "Week 11-12: Ethical Hacking and Penetration Testing\n" +
                "Week 13-14: Digital Forensics\n" +
                "Week 15-16: Security Policies and Legal Issues\n" +
                "Assessment: Assignments 20% | Midterm 30% | Final 50%"));

        cs.add(mk("SESM-470","CS Elective V - Software Project Mgmt","TCH006","Dr. Ali Raza",3,"Semester VII","Mon/Wed 14:00-15:30","CS-703",40,
                "Project planning, risk management, Agile/Scrum, cost estimation, and team dynamics.",
                "Software Engineering",7,
                "Week 1-2: Introduction to Project Management\n" +
                "Week 3-4: Project Planning and Scheduling (Gantt Charts)\n" +
                "Week 5-6: Risk Identification and Management\n" +
                "Week 7-8: Agile and Scrum Framework\n" +
                "Week 9-10: Cost and Effort Estimation\n" +
                "Week 11-12: Team Building and Leadership\n" +
                "Week 13-14: Quality Management\n" +
                "Week 15-16: Capstone Project Planning\n" +
                "Assessment: Assignments 20% | Midterm 30% | Final 50%"));

        // ── SEMESTER 8 ──────────────────────────────────────────────────────────
        cs.add(mk("CSMA-472","CS Elective VI - Mobile App Development","TCH001","Dr. Sarah Johnson",3,"Semester VIII","Mon/Wed 10:00-11:30","CS-801",40,
                "Android/iOS development, UI design, REST APIs, and publishing mobile applications.",
                "Computer Science",8,
                "Week 1-2: Mobile Platform Overview (Android/iOS)\n" +
                "Week 3-4: Android Studio and Java/Kotlin Basics\n" +
                "Week 5-6: UI Components and Layouts\n" +
                "Week 7-8: Activities, Intents, and Fragments\n" +
                "Week 9-10: Data Persistence (SQLite, SharedPrefs)\n" +
                "Week 11-12: Networking and REST APIs\n" +
                "Week 13-14: Firebase Integration\n" +
                "Week 15-16: App Publishing and Final Project\n" +
                "Assessment: Assignments 20% | Midterm 30% | Final 50%"));

        cs.add(mk("CSPD-407","Parallel & Distributed Computing","TCH004","Dr. Robert Wilson",3,"Semester VIII","Tue/Thu 10:00-11:30","CS-802",35,
                "Parallel architectures, distributed systems, concurrency, and cloud computing.",
                "Computer Science",8,
                "Week 1-2: Introduction to Parallel Computing\n" +
                "Week 3-4: Parallel Architectures (SIMD, MIMD)\n" +
                "Week 5-6: Thread-level Parallelism\n" +
                "Week 7-8: Message Passing Interface (MPI)\n" +
                "Week 9-10: Distributed Systems Concepts\n" +
                "Week 11-12: Cloud Computing and Virtualization\n" +
                "Week 13-14: MapReduce and Hadoop\n" +
                "Week 15-16: Distributed Algorithms & Review\n" +
                "Assessment: Assignments 20% | Midterm 30% | Final 50%"));

        cs.add(mk("CSEC-473","Univ Elective V - Economics for Computing","TCH002","Prof. Michael Brown",3,"Semester VIII","Fri 09:00-12:00","HUM-801",50,
                "Micro/macro economics, market structures, cost analysis, and technology economics.",
                "Economics",8,
                "Week 1-2: Introduction to Economics\n" +
                "Week 3-4: Supply, Demand, and Market Equilibrium\n" +
                "Week 5-6: Cost Analysis and Production\n" +
                "Week 7-8: Market Structures\n" +
                "Week 9-10: Macroeconomics and GDP\n" +
                "Week 11-12: Technology and Economic Growth\n" +
                "Week 13-14: Digital Economy and E-Commerce\n" +
                "Week 15-16: Economic Policy and Review\n" +
                "Assessment: Assignments 20% | Midterm 30% | Final 50%"));

        saveCourses(cs);
    }

    private static Course mk(String id, String name, String tId, String tName, int cr, String sem,
                              String sched, String room, int cap, String desc, String dept,
                              int semNum, String outline) {
        Course c = new Course(id, name, tId, tName, cr, sem, sched, room, cap, desc, dept, semNum, outline);
        return c;
    }

    private static void seedStudents() {
        if (new File(STUDENTS_FILE).exists() && !fileIsEmpty(STUDENTS_FILE)) return;
        List<Student> list = new ArrayList<>();
        list.add(new Student("STU001","Alex Johnson","alex.j@student.edu","stu123","0302-1111111","Dorm Block A","Computer Science",1,"Semester I"));
        list.add(new Student("STU002","Maria Garcia","maria.g@student.edu","stu123","0302-2222222","Dorm Block B","Computer Science",2,"Semester II"));
        list.add(new Student("STU003","James Wilson","james.w@student.edu","stu123","0302-3333333","Dorm Block A","Computer Science",3,"Semester III"));
        saveStudents(list);
    }

    private static void seedEnrollments() {
        if (new File(ENROLLMENTS_FILE).exists() && !fileIsEmpty(ENROLLMENTS_FILE)) return;
        List<String> lines = new ArrayList<>();
        // STU001 enrolled in Semester I courses
        lines.add("STU001,CSIT-111");
        lines.add("STU001,CSPF-141");
        lines.add("STU001,ESEC-112");
        lines.add("STU001,SSPS-113");
        lines.add("STU001,SSIS-114");
        lines.add("STU001,EEAP-121");
        // STU002 enrolled in Semester II courses
        lines.add("STU002,CSOO-142");
        lines.add("STU002,ESPS-115");
        lines.add("STU002,MTCA-122");
        lines.add("STU002,CSDS-143");
        // STU003 enrolled in Semester III courses
        lines.add("STU003,EEDL-201");
        lines.add("STU003,CSDA-244");
        lines.add("STU003,MTLA-223");
        writeLines(ENROLLMENTS_FILE, lines);

        List<Course> courses = loadCourses();
        Map<String, Integer> counts = new HashMap<>();
        for (String line : lines) {
            String cid = line.split(",")[1].trim();
            counts.put(cid, counts.getOrDefault(cid, 0) + 1);
        }
        for (Course c : courses) {
            if (counts.containsKey(c.getCourseId())) c.setEnrolled(counts.get(c.getCourseId()));
        }
        saveCourses(courses);
    }

    private static void seedGrades() {
        if (new File(GRADES_FILE).exists() && !fileIsEmpty(GRADES_FILE)) return;
        List<Grade> grades = new ArrayList<>();
        // STU001 completed Semester I
        grades.add(new Grade("GRD001","STU001","CSIT-111","Intro to Info & Comm Tech",88,85,90,"Semester I"));
        grades.add(new Grade("GRD002","STU001","CSPF-141","Programming Fundamentals",92,89,94,"Semester I"));
        grades.add(new Grade("GRD003","STU001","ESEC-112","English Composition",78,80,82,"Semester I"));
        grades.add(new Grade("GRD004","STU001","SSPS-113","Pakistan Studies",85,88,86,"Semester I"));
        grades.add(new Grade("GRD005","STU001","SSIS-114","Islamic Studies",90,91,93,"Semester I"));
        grades.add(new Grade("GRD006","STU001","EEAP-121","Applied Physics",75,72,78,"Semester I"));
        // STU002 Semester II
        grades.add(new Grade("GRD007","STU002","CSOO-142","Object Oriented Programming",90,88,92,"Semester II"));
        grades.add(new Grade("GRD008","STU002","MTCA-122","Calculus & Analytical Geometry",80,76,82,"Semester II"));
        // STU003 Semester III
        grades.add(new Grade("GRD009","STU003","CSDA-244","Data Structures & Algorithms",88,84,90,"Semester III"));
        grades.add(new Grade("GRD010","STU003","MTLA-223","Linear Algebra",76,78,80,"Semester III"));
        saveGrades(grades);
    }

    private static void seedAnnouncements() {
        if (new File(ANNOUNCEMENTS_FILE).exists() && !fileIsEmpty(ANNOUNCEMENTS_FILE)) return;
        List<Announcement> list = new ArrayList<>();
        list.add(new Announcement("ANN001","Mid-Term Exam Schedule Released",
                "Mid-term exams will be held from Oct 14 to Oct 18. Check your timetable.",
                "ADM001","Super Admin","ADMIN","GLOBAL","HIGH","2024-10-01 09:00"));
        list.add(new Announcement("ANN002","Add/Drop Period Open",
                "The course add/drop period is now open until Oct 7. Visit your portal to make changes.",
                "ADM001","Super Admin","ADMIN","GLOBAL","HIGH","2024-09-25 10:00"));
        list.add(new Announcement("ANN003","Programming Fundamentals Grades Posted",
                "Assignment 1 grades for CSPF-141 are now available.",
                "TCH001","Dr. Sarah Johnson","TEACHER","CSPF-141","MEDIUM","2024-10-05 14:30"));
        saveAnnouncements(list);
    }

    // ─────────────────────────────────────────────
    //  STUDENT CRUD
    // ─────────────────────────────────────────────
    public static List<Student> loadStudents() {
        List<Student> list = new ArrayList<>();
        File f = new File(STUDENTS_FILE);
        if (!f.exists()) return list;
        try (BufferedReader br = new BufferedReader(new FileReader(f))) {
            String line;
            while ((line = br.readLine()) != null) {
                line = line.trim();
                if (!line.isEmpty()) {
                    Student s = Student.fromCSV(line);
                    if (s != null) list.add(s);
                }
            }
        } catch (IOException e) { e.printStackTrace(); }
        return list;
    }

    private static void saveStudents(List<Student> list) {
        try (PrintWriter pw = new PrintWriter(new FileWriter(STUDENTS_FILE))) {
            for (Student s : list) pw.println(s.toCSV());
        } catch (IOException e) { e.printStackTrace(); }
    }

    public static Student findStudentById(String id) {
        for (Student s : loadStudents()) if (s.getId().equalsIgnoreCase(id)) return s;
        return null;
    }

    public static Student findStudentByEmail(String email) {
        for (Student s : loadStudents()) if (s.getEmail().equalsIgnoreCase(email)) return s;
        return null;
    }

    public static void addStudent(Student s) {
        List<Student> list = loadStudents();
        list.add(s);
        saveStudents(list);
    }

    public static void updateStudent(Student updated) {
        List<Student> list = loadStudents();
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).getId().equalsIgnoreCase(updated.getId())) { list.set(i, updated); break; }
        }
        saveStudents(list);
    }

    public static void deleteStudent(String id) {
        List<Student> list = loadStudents();
        list.removeIf(s -> s.getId().equalsIgnoreCase(id));
        saveStudents(list);
    }

    public static String generateStudentId() {
        return "STU" + String.format("%03d", loadStudents().size() + 1);
    }

    // ─────────────────────────────────────────────
    //  TEACHER CRUD
    // ─────────────────────────────────────────────
    public static List<Teacher> loadTeachers() {
        List<Teacher> list = new ArrayList<>();
        File f = new File(TEACHERS_FILE);
        if (!f.exists()) return list;
        try (BufferedReader br = new BufferedReader(new FileReader(f))) {
            String line;
            while ((line = br.readLine()) != null) {
                line = line.trim();
                if (!line.isEmpty()) {
                    Teacher t = Teacher.fromCSV(line);
                    if (t != null) list.add(t);
                }
            }
        } catch (IOException e) { e.printStackTrace(); }
        return list;
    }

    private static void saveTeachers(List<Teacher> list) {
        try (PrintWriter pw = new PrintWriter(new FileWriter(TEACHERS_FILE))) {
            for (Teacher t : list) pw.println(t.toCSV());
        } catch (IOException e) { e.printStackTrace(); }
    }

    public static Teacher findTeacherById(String id) {
        for (Teacher t : loadTeachers()) if (t.getId().equalsIgnoreCase(id)) return t;
        return null;
    }

    public static Teacher findTeacherByEmail(String email) {
        for (Teacher t : loadTeachers()) if (t.getEmail().equalsIgnoreCase(email)) return t;
        return null;
    }

    public static void addTeacher(Teacher t) { List<Teacher> l = loadTeachers(); l.add(t); saveTeachers(l); }
    public static void updateTeacher(Teacher updated) {
        List<Teacher> l = loadTeachers();
        for (int i = 0; i < l.size(); i++) if (l.get(i).getId().equalsIgnoreCase(updated.getId())) { l.set(i, updated); break; }
        saveTeachers(l);
    }
    public static void deleteTeacher(String id) { List<Teacher> l = loadTeachers(); l.removeIf(t -> t.getId().equalsIgnoreCase(id)); saveTeachers(l); }
    public static String generateTeacherId() { return "TCH" + String.format("%03d", loadTeachers().size() + 1); }

    // ─────────────────────────────────────────────
    //  ADMIN CRUD
    // ─────────────────────────────────────────────
    public static List<Admin> loadAdmins() {
        List<Admin> list = new ArrayList<>();
        File f = new File(ADMINS_FILE);
        if (!f.exists()) return list;
        try (BufferedReader br = new BufferedReader(new FileReader(f))) {
            String line;
            while ((line = br.readLine()) != null) {
                line = line.trim();
                if (!line.isEmpty()) { Admin a = Admin.fromCSV(line); if (a != null) list.add(a); }
            }
        } catch (IOException e) { e.printStackTrace(); }
        return list;
    }

    private static void saveAdmins(List<Admin> list) {
        try (PrintWriter pw = new PrintWriter(new FileWriter(ADMINS_FILE))) {
            for (Admin a : list) pw.println(a.toCSV());
        } catch (IOException e) { e.printStackTrace(); }
    }

    public static Admin findAdminById(String id) {
        for (Admin a : loadAdmins()) if (a.getId().equalsIgnoreCase(id)) return a;
        return null;
    }

    public static Admin findAdminByEmail(String email) {
        for (Admin a : loadAdmins()) if (a.getEmail().equalsIgnoreCase(email)) return a;
        return null;
    }

    public static void addAdmin(Admin a) { List<Admin> l = loadAdmins(); l.add(a); saveAdmins(l); }
    public static void updateAdmin(Admin updated) {
        List<Admin> l = loadAdmins();
        for (int i = 0; i < l.size(); i++) if (l.get(i).getId().equalsIgnoreCase(updated.getId())) { l.set(i, updated); break; }
        saveAdmins(l);
    }
    public static void deleteAdmin(String id) { List<Admin> l = loadAdmins(); l.removeIf(a -> a.getId().equalsIgnoreCase(id)); saveAdmins(l); }
    public static String generateAdminId() { return "ADM" + String.format("%03d", loadAdmins().size() + 1); }

    // ─────────────────────────────────────────────
    //  COURSE CRUD
    // ─────────────────────────────────────────────
    public static List<Course> loadCourses() {
        List<Course> list = new ArrayList<>();
        File f = new File(COURSES_FILE);
        if (!f.exists()) return list;
        try (BufferedReader br = new BufferedReader(new FileReader(f))) {
            String line;
            while ((line = br.readLine()) != null) {
                line = line.trim();
                if (!line.isEmpty()) { Course c = Course.fromCSV(line); if (c != null) list.add(c); }
            }
        } catch (IOException e) { e.printStackTrace(); }
        return list;
    }

    private static void saveCourses(List<Course> list) {
        try (PrintWriter pw = new PrintWriter(new FileWriter(COURSES_FILE))) {
            for (Course c : list) pw.println(c.toCSV());
        } catch (IOException e) { e.printStackTrace(); }
    }

    public static Course findCourseById(String id) {
        for (Course c : loadCourses()) if (c.getCourseId().equalsIgnoreCase(id)) return c;
        return null;
    }

    /** Return courses grouped by semester number (1-8). */
    public static Map<Integer, List<Course>> getCoursesBySemesterNumber() {
        Map<Integer, List<Course>> map = new TreeMap<>();
        for (Course c : loadCourses()) {
            int s = c.getSemesterNumber();
            map.computeIfAbsent(s, k -> new ArrayList<>()).add(c);
        }
        return map;
    }

    public static void addCourse(Course c) { List<Course> l = loadCourses(); l.add(c); saveCourses(l); }
    public static void updateCourse(Course updated) {
        List<Course> l = loadCourses();
        for (int i = 0; i < l.size(); i++) if (l.get(i).getCourseId().equalsIgnoreCase(updated.getCourseId())) { l.set(i, updated); break; }
        saveCourses(l);
    }
    public static void deleteCourse(String id) { List<Course> l = loadCourses(); l.removeIf(c -> c.getCourseId().equalsIgnoreCase(id)); saveCourses(l); }
    public static String generateCourseId() { return "CRS" + String.format("%03d", loadCourses().size() + 1); }

    // ─────────────────────────────────────────────
    //  ENROLLMENT
    // ─────────────────────────────────────────────
    public static List<String> getEnrolledCourseIds(String studentId) {
        List<String> list = new ArrayList<>();
        File f = new File(ENROLLMENTS_FILE);
        if (!f.exists()) return list;
        try (BufferedReader br = new BufferedReader(new FileReader(f))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] p = line.trim().split(",");
                if (p.length >= 2 && p[0].trim().equalsIgnoreCase(studentId)) list.add(p[1].trim());
            }
        } catch (IOException e) { e.printStackTrace(); }
        return list;
    }

    public static boolean enrollStudent(String studentId, String courseId) {
        List<String> already = getEnrolledCourseIds(studentId);
        if (already.contains(courseId)) return false;
        Course c = findCourseById(courseId);
        if (c == null || c.isFull()) return false;
        try (PrintWriter pw = new PrintWriter(new FileWriter(ENROLLMENTS_FILE, true))) {
            pw.println(studentId + "," + courseId);
        } catch (IOException e) { e.printStackTrace(); return false; }
        c.setEnrolled(c.getEnrolled() + 1);
        updateCourse(c);
        return true;
    }

    public static void dropEnrollment(String studentId, String courseId) {
        List<String> lines = new ArrayList<>();
        File f = new File(ENROLLMENTS_FILE);
        if (!f.exists()) return;
        try (BufferedReader br = new BufferedReader(new FileReader(f))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] p = line.trim().split(",");
                if (p.length < 2 || (p[0].trim().equalsIgnoreCase(studentId) && p[1].trim().equalsIgnoreCase(courseId))) continue;
                lines.add(line.trim());
            }
        } catch (IOException e) { e.printStackTrace(); }
        writeLines(ENROLLMENTS_FILE, lines);
        Course c = findCourseById(courseId);
        if (c != null && c.getEnrolled() > 0) { c.setEnrolled(c.getEnrolled() - 1); updateCourse(c); }
    }

    // ─────────────────────────────────────────────
    //  GRADES
    // ─────────────────────────────────────────────
    public static List<Grade> loadGrades() {
        List<Grade> list = new ArrayList<>();
        File f = new File(GRADES_FILE);
        if (!f.exists()) return list;
        try (BufferedReader br = new BufferedReader(new FileReader(f))) {
            String line;
            while ((line = br.readLine()) != null) {
                line = line.trim();
                if (!line.isEmpty()) { Grade g = Grade.fromCSV(line); if (g != null) list.add(g); }
            }
        } catch (IOException e) { e.printStackTrace(); }
        return list;
    }

    private static void saveGrades(List<Grade> list) {
        try (PrintWriter pw = new PrintWriter(new FileWriter(GRADES_FILE))) {
            for (Grade g : list) pw.println(g.toCSV());
        } catch (IOException e) { e.printStackTrace(); }
    }

    public static List<Grade> getGradesForStudent(String studentId) {
        List<Grade> out = new ArrayList<>();
        for (Grade g : loadGrades()) if (g.getStudentId().equalsIgnoreCase(studentId)) out.add(g);
        return out;
    }

    /** Grades for a student in a specific curriculum semester (e.g. "Semester I") */
    public static List<Grade> getGradesForStudentBySemester(String studentId, String semester) {
        List<Grade> out = new ArrayList<>();
        for (Grade g : getGradesForStudent(studentId))
            if (g.getSemester().equalsIgnoreCase(semester)) out.add(g);
        return out;
    }

    /** Credit-weighted CGPA across all grades */
    public static double calculateCGPA(String studentId) {
        List<Grade> grades = getGradesForStudent(studentId);
        if (grades.isEmpty()) return 0.0;
        double weightedSum = 0, totalCredits = 0;
        for (Grade g : grades) {
            Course c = findCourseById(g.getCourseId());
            int cr = (c != null) ? c.getCreditHours() : 3;
            weightedSum  += g.getGpaPoints() * cr;
            totalCredits += cr;
        }
        return totalCredits > 0 ? weightedSum / totalCredits : 0.0;
    }

    /** Credit-weighted GPA for a specific semester */
    public static double calculateSemesterGPA(String studentId, String semester) {
        List<Grade> grades = getGradesForStudentBySemester(studentId, semester);
        if (grades.isEmpty()) return 0.0;
        double weightedSum = 0, totalCredits = 0;
        for (Grade g : grades) {
            Course c = findCourseById(g.getCourseId());
            int cr = (c != null) ? c.getCreditHours() : 3;
            weightedSum  += g.getGpaPoints() * cr;
            totalCredits += cr;
        }
        return totalCredits > 0 ? weightedSum / totalCredits : 0.0;
    }

    public static void addGrade(Grade g) { List<Grade> l = loadGrades(); l.add(g); saveGrades(l); }
    public static void updateGrade(Grade updated) {
        List<Grade> l = loadGrades();
        for (int i = 0; i < l.size(); i++) if (l.get(i).getGradeId().equalsIgnoreCase(updated.getGradeId())) { l.set(i, updated); break; }
        saveGrades(l);
    }
    public static void deleteGrade(String gradeId) { List<Grade> l = loadGrades(); l.removeIf(g -> g.getGradeId().equalsIgnoreCase(gradeId)); saveGrades(l); }
    public static String generateGradeId() { return "GRD" + String.format("%03d", loadGrades().size() + 1); }

    // ─────────────────────────────────────────────
    //  ANNOUNCEMENTS
    // ─────────────────────────────────────────────
    public static List<Announcement> loadAnnouncements() {
        List<Announcement> list = new ArrayList<>();
        File f = new File(ANNOUNCEMENTS_FILE);
        if (!f.exists()) return list;
        try (BufferedReader br = new BufferedReader(new FileReader(f))) {
            String line;
            while ((line = br.readLine()) != null) {
                line = line.trim();
                if (!line.isEmpty()) { Announcement a = Announcement.fromCSV(line); if (a != null) list.add(a); }
            }
        } catch (IOException e) { e.printStackTrace(); }
        return list;
    }

    private static void saveAnnouncements(List<Announcement> list) {
        try (PrintWriter pw = new PrintWriter(new FileWriter(ANNOUNCEMENTS_FILE))) {
            for (Announcement a : list) pw.println(a.toCSV());
        } catch (IOException e) { e.printStackTrace(); }
    }

    public static void addAnnouncement(Announcement a) { List<Announcement> l = loadAnnouncements(); l.add(a); saveAnnouncements(l); }
    public static void updateAnnouncement(Announcement updated) {
        List<Announcement> l = loadAnnouncements();
        for (int i = 0; i < l.size(); i++) if (l.get(i).getAnnouncementId().equalsIgnoreCase(updated.getAnnouncementId())) { l.set(i, updated); break; }
        saveAnnouncements(l);
    }
    public static void deleteAnnouncement(String id) { List<Announcement> l = loadAnnouncements(); l.removeIf(a -> a.getAnnouncementId().equalsIgnoreCase(id)); saveAnnouncements(l); }
    public static String generateAnnouncementId() { return "ANN" + String.format("%03d", loadAnnouncements().size() + 1); }

    // ─────────────────────────────────────────────
    //  ASSIGNMENTS
    // ─────────────────────────────────────────────
    public static List<Assignment> loadAssignments() {
        List<Assignment> list = new ArrayList<>();
        File f = new File(ASSIGNMENTS_FILE);
        if (!f.exists()) return list;
        try (BufferedReader br = new BufferedReader(new FileReader(f))) {
            String line;
            while ((line = br.readLine()) != null) {
                line = line.trim();
                if (!line.isEmpty()) { Assignment a = Assignment.fromCSV(line); if (a != null) list.add(a); }
            }
        } catch (IOException e) { e.printStackTrace(); }
        return list;
    }

    private static void saveAssignments(List<Assignment> list) {
        try (PrintWriter pw = new PrintWriter(new FileWriter(ASSIGNMENTS_FILE))) {
            for (Assignment a : list) pw.println(a.toCSV());
        } catch (IOException e) { e.printStackTrace(); }
    }

    public static List<Assignment> getAssignmentsForStudent(String studentId) {
        List<String> enrolled = getEnrolledCourseIds(studentId);
        List<Assignment> out = new ArrayList<>();
        for (Assignment a : loadAssignments()) if (enrolled.contains(a.getCourseId())) out.add(a);
        return out;
    }

    public static List<Assignment> getAssignmentsForTeacher(String teacherId) {
        List<Assignment> out = new ArrayList<>();
        for (Assignment a : loadAssignments()) if (a.getTeacherId().equalsIgnoreCase(teacherId)) out.add(a);
        return out;
    }

    public static void addAssignment(Assignment a) { List<Assignment> l = loadAssignments(); l.add(a); saveAssignments(l); }
    public static void updateAssignment(Assignment updated) {
        List<Assignment> l = loadAssignments();
        for (int i = 0; i < l.size(); i++) if (l.get(i).getAssignmentId().equalsIgnoreCase(updated.getAssignmentId())) { l.set(i, updated); break; }
        saveAssignments(l);
    }
    public static void deleteAssignment(String id) { List<Assignment> l = loadAssignments(); l.removeIf(a -> a.getAssignmentId().equalsIgnoreCase(id)); saveAssignments(l); }

    // ─────────────────────────────────────────────
    //  FEE STRUCTURES
    // ─────────────────────────────────────────────
    private static final String FEE_STRUCTURES_FILE = DATA_DIR + "/fee_structures.csv";

    public static List<FeeStructure> loadFeeStructures() {
        List<FeeStructure> list = new ArrayList<>();
        File f = new File(FEE_STRUCTURES_FILE);
        if (!f.exists()) return list;
        try (BufferedReader br = new BufferedReader(new FileReader(f))) {
            String line;
            while ((line = br.readLine()) != null) {
                line = line.trim();
                if (!line.isEmpty()) { FeeStructure fs = FeeStructure.fromCSV(line); if (fs != null) list.add(fs); }
            }
        } catch (IOException e) { e.printStackTrace(); }
        return list;
    }

    private static void saveFeeStructures(List<FeeStructure> list) {
        try (PrintWriter pw = new PrintWriter(new FileWriter(FEE_STRUCTURES_FILE))) {
            for (FeeStructure fs : list) pw.println(fs.toCSV());
        } catch (IOException e) { e.printStackTrace(); }
    }

    public static void addFeeStructure(FeeStructure fs) { List<FeeStructure> l = loadFeeStructures(); l.add(fs); saveFeeStructures(l); }
    public static void updateFeeStructure(FeeStructure updated) {
        List<FeeStructure> l = loadFeeStructures();
        for (int i = 0; i < l.size(); i++) if (l.get(i).getId().equals(updated.getId())) { l.set(i, updated); break; }
        saveFeeStructures(l);
    }
    public static void deleteFeeStructure(String id) { List<FeeStructure> l = loadFeeStructures(); l.removeIf(fs -> fs.getId().equals(id)); saveFeeStructures(l); }
    public static FeeStructure findFeeStructure(String programme, String semester) {
        for (FeeStructure fs : loadFeeStructures())
            if (fs.getProgramme().equalsIgnoreCase(programme.trim()) && fs.getSemester().equalsIgnoreCase(semester.trim())) return fs;
        return null;
    }
    public static String generateFeeStructureId() { return "FS" + String.format("%03d", loadFeeStructures().size() + 1); }

    // ─────────────────────────────────────────────
    //  CHALLAN COUNTER
    // ─────────────────────────────────────────────
    private static final String CHALLAN_COUNTER_FILE = DATA_DIR + "/challan_counter.txt";

    public static int getNextChallanNumber() {
        File f = new File(CHALLAN_COUNTER_FILE);
        int num = 304572;
        if (f.exists()) {
            try (BufferedReader br = new BufferedReader(new FileReader(f))) {
                num = Integer.parseInt(br.readLine().trim());
            } catch (Exception e) {}
        }
        try (PrintWriter pw = new PrintWriter(new FileWriter(CHALLAN_COUNTER_FILE))) {
            pw.println(num + 1);
        } catch (IOException e) { e.printStackTrace(); }
        return num;
    }

    // ─────────────────────────────────────────────
    //  HELPERS
    // ─────────────────────────────────────────────
    private static boolean fileIsEmpty(String path) {
        File f = new File(path);
        if (!f.exists()) return true;
        try (BufferedReader br = new BufferedReader(new FileReader(f))) {
            String l;
            while ((l = br.readLine()) != null) if (!l.trim().isEmpty()) return false;
        } catch (IOException e) {}
        return true;
    }

    private static void writeLines(String path, List<String> lines) {
        try (PrintWriter pw = new PrintWriter(new FileWriter(path))) {
            for (String l : lines) pw.println(l);
        } catch (IOException e) { e.printStackTrace(); }
    }

    // ─── ADDITIONAL MISSING METHODS ─────────────────────────────────────────────

    public static List<String> getStudentsInCourse(String courseId) {
        List<String> ids = new ArrayList<>();
        File f = new File(ENROLLMENTS_FILE);
        if (!f.exists()) return ids;
        try (BufferedReader br = new BufferedReader(new FileReader(f))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] p = line.trim().split(",");
                if (p.length >= 2 && p[1].trim().equalsIgnoreCase(courseId)) ids.add(p[0].trim());
            }
        } catch (IOException e) { e.printStackTrace(); }
        return ids;
    }

    public static void addOrUpdateGrade(Grade grade) {
        List<Grade> list = loadGrades();
        boolean found = false;
        for (int i = 0; i < list.size(); i++) {
            Grade g = list.get(i);
            if (g.getStudentId().equalsIgnoreCase(grade.getStudentId())
                    && g.getCourseId().equalsIgnoreCase(grade.getCourseId())
                    && g.getSemester().equalsIgnoreCase(grade.getSemester())) {
                list.set(i, grade); found = true; break;
            }
        }
        if (!found) list.add(grade);
        saveGrades(list);
    }

    public static String generateAssignmentId() {
        return "ASN" + String.format("%03d", loadAssignments().size() + 1);
    }

    public static List<Assignment> getAssignmentsForCourse(String courseId) {
        List<Assignment> out = new ArrayList<>();
        for (Assignment a : loadAssignments()) if (a.getCourseId().equalsIgnoreCase(courseId)) out.add(a);
        return out;
    }

    public static User authenticate(String emailOrId, String password) {
        for (Admin a : loadAdmins())
            if ((a.getEmail().equalsIgnoreCase(emailOrId) || a.getId().equalsIgnoreCase(emailOrId))
                    && a.getPassword().equals(password)) return a;
        for (Teacher t : loadTeachers())
            if ((t.getEmail().equalsIgnoreCase(emailOrId) || t.getId().equalsIgnoreCase(emailOrId))
                    && t.getPassword().equals(password)) return t;
        for (Student s : loadStudents())
            if ((s.getEmail().equalsIgnoreCase(emailOrId) || s.getId().equalsIgnoreCase(emailOrId))
                    && s.getPassword().equals(password)) return s;
        return null;
    }

    // ─────────────────────────────────────────────
    //  PENDING STUDENT APPLICATIONS
    //  CSV format: appId,name,email,password,phone,address,major,appliedDate
    // ─────────────────────────────────────────────
    public static List<String[]> loadPendingApplications() {
        List<String[]> list = new ArrayList<>();
        File f = new File(PENDING_APPS_FILE);
        if (!f.exists()) return list;
        try (BufferedReader br = new BufferedReader(new FileReader(f))) {
            String line;
            while ((line = br.readLine()) != null) {
                line = line.trim();
                if (!line.isEmpty()) {
                    String[] parts = line.split(",", -1);
                    if (parts.length >= 8) list.add(parts);
                }
            }
        } catch (IOException e) { e.printStackTrace(); }
        return list;
    }

    private static void savePendingApplications(List<String[]> list) {
        try (PrintWriter pw = new PrintWriter(new FileWriter(PENDING_APPS_FILE))) {
            for (String[] r : list) pw.println(String.join(",", r));
        } catch (IOException e) { e.printStackTrace(); }
    }

    public static void addPendingApplication(String name, String email, String password,
                                              String phone, String address, String major) {
        List<String[]> list = loadPendingApplications();
        String appId = "APP" + String.format("%03d", list.size() + 1);
        String date  = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm").format(new java.util.Date());
        list.add(new String[]{appId, name, email, password, phone, address, major, date});
        savePendingApplications(list);
    }

    public static boolean isPendingApplicationEmail(String email) {
        for (String[] r : loadPendingApplications())
            if (r[2].equalsIgnoreCase(email)) return true;
        return false;
    }

    /** Approve: move from pending to active students */
    public static void approveApplication(String appId) {
        List<String[]> list = loadPendingApplications();
        list.removeIf(r -> {
            if (r[0].equalsIgnoreCase(appId)) {
                Student s = new Student(generateStudentId(), r[1], r[2], r[3],
                        r[4], r[5], r[6], 1, "Semester I");
                addStudent(s);
                return true;
            }
            return false;
        });
        savePendingApplications(list);
    }

    /** Reject: remove from pending without creating student */
    public static void rejectApplication(String appId) {
        List<String[]> list = loadPendingApplications();
        list.removeIf(r -> r[0].equalsIgnoreCase(appId));
        savePendingApplications(list);
    }

    // ─────────────────────────────────────────────
    //  ASSIGNMENT SUBMISSIONS
    // ─────────────────────────────────────────────

    public static List<models.AssignmentSubmission> loadSubmissions() {
        List<models.AssignmentSubmission> list = new ArrayList<>();
        File f = new File(SUBMISSIONS_FILE);
        if (!f.exists()) return list;
        try (BufferedReader br = new BufferedReader(new FileReader(f))) {
            String line;
            while ((line = br.readLine()) != null) {
                line = line.trim();
                if (!line.isEmpty()) {
                    models.AssignmentSubmission s = models.AssignmentSubmission.fromCSV(line);
                    if (s != null) list.add(s);
                }
            }
        } catch (IOException e) { e.printStackTrace(); }
        return list;
    }

    private static void saveSubmissions(List<models.AssignmentSubmission> list) {
        try (PrintWriter pw = new PrintWriter(new FileWriter(SUBMISSIONS_FILE))) {
            for (models.AssignmentSubmission s : list) pw.println(s.toCSV());
        } catch (IOException e) { e.printStackTrace(); }
    }

    public static void addSubmission(models.AssignmentSubmission sub) {
        List<models.AssignmentSubmission> list = loadSubmissions();
        list.add(sub);
        saveSubmissions(list);
    }

    public static void updateSubmission(models.AssignmentSubmission updated) {
        List<models.AssignmentSubmission> list = loadSubmissions();
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).getSubmissionId().equalsIgnoreCase(updated.getSubmissionId())) {
                list.set(i, updated);
                break;
            }
        }
        saveSubmissions(list);
    }

    /** Returns submission for a specific student + assignment, or null if none */
    public static models.AssignmentSubmission getSubmission(String studentId, String assignmentId) {
        for (models.AssignmentSubmission s : loadSubmissions())
            if (s.getStudentId().equalsIgnoreCase(studentId) &&
                s.getAssignmentId().equalsIgnoreCase(assignmentId))
                return s;
        return null;
    }

    /** All submissions for a given assignment (for teacher view) */
    public static List<models.AssignmentSubmission> getSubmissionsForAssignment(String assignmentId) {
        List<models.AssignmentSubmission> out = new ArrayList<>();
        for (models.AssignmentSubmission s : loadSubmissions())
            if (s.getAssignmentId().equalsIgnoreCase(assignmentId)) out.add(s);
        return out;
    }

    /** All submissions by a student */
    public static List<models.AssignmentSubmission> getSubmissionsForStudent(String studentId) {
        List<models.AssignmentSubmission> out = new ArrayList<>();
        for (models.AssignmentSubmission s : loadSubmissions())
            if (s.getStudentId().equalsIgnoreCase(studentId)) out.add(s);
        return out;
    }

    public static String generateSubmissionId() {
        List<models.AssignmentSubmission> list = loadSubmissions();
        return String.format("SUB%03d", list.size() + 1);
    }
}


