package models;

public class Admin extends User {
    private static final long serialVersionUID = 1L;

    private String adminLevel; 

    public Admin(String id, String name, String email, String password) {
        super(id, name, email, password, "ADMIN");
        this.adminLevel = "REGULAR";
    }

    public Admin(String id, String name, String email, String password,
                 String phone, String address, String adminLevel) {
        super(id, name, email, password, "ADMIN");
        this.phone = phone;
        this.address = address;
        this.adminLevel = adminLevel;
    }

    public Admin(String id, String name, String email, String password,
                 String phone, String address, String adminLevel, String profilePicturePath) {
        super(id, name, email, password, "ADMIN");
        this.phone = phone;
        this.address = address;
        this.adminLevel = adminLevel;
        this.profilePicturePath = profilePicturePath;
    }

    public String getAdminLevel() { return adminLevel; }
    public void setAdminLevel(String adminLevel) { this.adminLevel = adminLevel; }

    @Override
    public String toCSV() {
        return id + "," + name + "," + email + "," + password + ","
                + phone + "," + address + "," + adminLevel + ","
                + (profilePicturePath != null ? profilePicturePath : "");
    }

    public static Admin fromCSV(String csv) {
        String[] parts = csv.split(",", -1);
        if (parts.length < 7) return null;
        String pic = parts.length >= 8 ? parts[7].trim() : "";
        Admin a = new Admin(parts[0].trim(), parts[1].trim(), parts[2].trim(),
                parts[3].trim(), parts[4].trim(), parts[5].trim(), parts[6].trim(), pic);
        return a;
    }
}
