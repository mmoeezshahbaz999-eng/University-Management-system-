package models;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Announcement implements Serializable {
    private static final long serialVersionUID = 1L;

    private String announcementId;
    private String title;
    private String content;
    private String authorId;
    private String authorName;
    private String authorRole;
    private String courseId;   
    private String dateTime;
    private String priority;   

    public Announcement(String announcementId, String title, String content,
                        String authorId, String authorName, String authorRole,
                        String courseId, String priority) {
        this.announcementId = announcementId;
        this.title = title;
        this.content = content;
        this.authorId = authorId;
        this.authorName = authorName;
        this.authorRole = authorRole;
        this.courseId = courseId;
        this.priority = priority;
        this.dateTime = LocalDateTime.now()
                .format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm"));
    }

    public Announcement(String announcementId, String title, String content,
                        String authorId, String authorName, String authorRole,
                        String courseId, String priority, String dateTime) {
        this(announcementId, title, content, authorId, authorName, authorRole, courseId, priority);
        this.dateTime = dateTime;
    }

    
    public String getAnnouncementId() { return announcementId; }
    public String getTitle() { return title; }
    public String getContent() { return content; }
    public String getAuthorId() { return authorId; }
    public String getAuthorName() { return authorName; }
    public String getAuthorRole() { return authorRole; }
    public String getCourseId() { return courseId; }
    public String getDateTime() { return dateTime; }
    public String getPriority() { return priority; }

    public boolean isGlobal() { return courseId == null || courseId.isEmpty() || courseId.equals("GLOBAL"); }

    public String toCSV() {
        String cid = (courseId == null || courseId.isEmpty()) ? "GLOBAL" : courseId;
        
        String safeContent = content.replace(",", ";").replace("\n", " ").replace("\r", "");
        String safeTitle = title.replace(",", ";");
        return announcementId + "," + safeTitle + "," + safeContent + ","
                + authorId + "," + authorName + "," + authorRole + ","
                + cid + "," + priority + "," + dateTime;
    }

    public static Announcement fromCSV(String csv) {
        String[] parts = csv.split(",", 9);
        if (parts.length < 9) return null;
        return new Announcement(parts[0].trim(), parts[1].trim(), parts[2].trim(),
                parts[3].trim(), parts[4].trim(), parts[5].trim(),
                parts[6].trim(), parts[7].trim(), parts[8].trim());
    }
}
