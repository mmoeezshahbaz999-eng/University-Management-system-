package models;

import java.util.ArrayList;
import java.util.List;

public class Teacher extends User {
    private static final long serialVersionUID = 1L;

    private String department;
    private String designation;
    private List<String> assignedCourseIds;

    public Teacher(String id, String name, String email, String password) {
        super(id, name, email, password, "TEACHER");
        this.department = "General";
        this.designation = "Lecturer";
        this.assignedCourseIds = new ArrayList<>();
    }

    public Teacher(String id, String name, String email, String password,
                   String phone, String address, String department, String designation) {
        super(id, name, email, password, "TEACHER");
        this.phone = phone;
        this.address = address;
        this.department = department;
        this.designation = designation;
        this.assignedCourseIds = new ArrayList<>();
    }

    public Teacher(String id, String name, String email, String password,
                   String phone, String address, String department, String designation,
                   String profilePicturePath) {
        super(id, name, email, password, "TEACHER");
        this.phone = phone;
        this.address = address;
        this.department = department;
        this.designation = designation;
        this.profilePicturePath = profilePicturePath;
        this.assignedCourseIds = new ArrayList<>();
    }

    public String getDepartment() { return department; }
    public String getDesignation() { return designation; }
    public List<String> getAssignedCourseIds() { return assignedCourseIds; }

    public void setDepartment(String department) { this.department = department; }
    public void setDesignation(String designation) { this.designation = designation; }

    public void assignCourse(String courseId) {
        if (!assignedCourseIds.contains(courseId)) {
            assignedCourseIds.add(courseId);
        }
    }

    public void removeCourse(String courseId) {
        assignedCourseIds.remove(courseId);
    }

    @Override
    public String toCSV() {
        return id + "," + name + "," + email + "," + password + ","
                + phone + "," + address + "," + department + "," + designation + ","
                + (profilePicturePath != null ? profilePicturePath : "");
    }

    public static Teacher fromCSV(String csv) {
        String[] parts = csv.split(",", -1);
        if (parts.length < 8) return null;
        String pic = parts.length >= 9 ? parts[8].trim() : "";
        Teacher t = new Teacher(parts[0].trim(), parts[1].trim(), parts[2].trim(),
                parts[3].trim(), parts[4].trim(), parts[5].trim(),
                parts[6].trim(), parts[7].trim(), pic);
        return t;
    }
}
