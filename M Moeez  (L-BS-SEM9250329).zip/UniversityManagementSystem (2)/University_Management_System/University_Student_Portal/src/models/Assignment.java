package models;

import java.io.Serializable;

public class Assignment implements Serializable {
    private static final long serialVersionUID = 1L;

    private String assignmentId;
    private String courseId;
    private String courseName;
    private String teacherId;
    private String teacherName;
    private String title;
    private String description;
    private String dueDate;      
    private int    totalMarks;
    private String semester;
    private String postedDate;   

    public Assignment(String assignmentId, String courseId, String courseName,
                      String teacherId, String teacherName,
                      String title, String description,
                      String dueDate, int totalMarks,
                      String semester, String postedDate) {
        this.assignmentId = assignmentId;
        this.courseId     = courseId;
        this.courseName   = courseName;
        this.teacherId    = teacherId;
        this.teacherName  = teacherName;
        this.title        = title;
        this.description  = description;
        this.dueDate      = dueDate;
        this.totalMarks   = totalMarks;
        this.semester     = semester;
        this.postedDate   = postedDate;
    }

    
    public String getAssignmentId() { return assignmentId; }
    public String getCourseId()     { return courseId; }
    public String getCourseName()   { return courseName; }
    public String getTeacherId()    { return teacherId; }
    public String getTeacherName()  { return teacherName; }
    public String getTitle()        { return title; }
    public String getDescription()  { return description; }
    public String getDueDate()      { return dueDate; }
    public int    getTotalMarks()   { return totalMarks; }
    public String getSemester()     { return semester; }
    public String getPostedDate()   { return postedDate; }

    
    public void setTitle(String title)             { this.title = title; }
    public void setDescription(String description) { this.description = description; }
    public void setDueDate(String dueDate)         { this.dueDate = dueDate; }
    public void setTotalMarks(int totalMarks)      { this.totalMarks = totalMarks; }

    public String toCSV() {
        String safeTitle = title.replace(",", ";").replace("\n", " ");
        String safeDesc  = description.replace(",", ";").replace("\n", " ");
        return assignmentId + "," + courseId + "," + courseName + ","
             + teacherId + "," + teacherName + ","
             + safeTitle + "," + safeDesc + ","
             + dueDate + "," + totalMarks + ","
             + semester + "," + postedDate;
    }

    public static Assignment fromCSV(String csv) {
        String[] p = csv.split(",", 11);
        if (p.length < 11) return null;
        try {
            return new Assignment(
                p[0].trim(), p[1].trim(), p[2].trim(),
                p[3].trim(), p[4].trim(),
                p[5].trim(), p[6].trim(),
                p[7].trim(), Integer.parseInt(p[8].trim()),
                p[9].trim(), p[10].trim()
            );
        } catch (Exception e) { return null; }
    }
}
