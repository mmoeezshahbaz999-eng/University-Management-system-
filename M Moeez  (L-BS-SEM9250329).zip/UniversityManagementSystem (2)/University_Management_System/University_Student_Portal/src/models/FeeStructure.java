package models;

import java.io.Serializable;

/**
 * Holds the fee structure settings for a given programme/semester.
 * Admins configure this; the system uses it when generating challans.
 */
public class FeeStructure implements Serializable {
    private static final long serialVersionUID = 1L;

    private String id;
    private String programme;      
    private String semester;       
    private double admissionFee;
    private double registrationFee;
    private double librarySecurityFee;
    private double tuitionFee;
    private double examinationFee;
    private double maintenanceCharges;
    private double audioVideoFee;
    private double librarySubscription;
    private double computerLabFee;
    private double sportsFund;
    private double magazineFund;
    private double itServicesFee;
    private double researchFund;
    private double studyMaterial;
    private boolean feeGenerationEnabled; 

    public FeeStructure() {}

    public FeeStructure(String id, String programme, String semester) {
        this.id = id;
        this.programme = programme;
        this.semester = semester;
        this.feeGenerationEnabled = false;
    }

    
    public String getId()                  { return id; }
    public String getProgramme()           { return programme; }
    public String getSemester()            { return semester; }
    public double getAdmissionFee()        { return admissionFee; }
    public double getRegistrationFee()     { return registrationFee; }
    public double getLibrarySecurityFee()  { return librarySecurityFee; }
    public double getTuitionFee()          { return tuitionFee; }
    public double getExaminationFee()      { return examinationFee; }
    public double getMaintenanceCharges()  { return maintenanceCharges; }
    public double getAudioVideoFee()       { return audioVideoFee; }
    public double getLibrarySubscription() { return librarySubscription; }
    public double getComputerLabFee()      { return computerLabFee; }
    public double getSportsFund()          { return sportsFund; }
    public double getMagazineFund()        { return magazineFund; }
    public double getItServicesFee()       { return itServicesFee; }
    public double getResearchFund()        { return researchFund; }
    public double getStudyMaterial()       { return studyMaterial; }
    public boolean isFeeGenerationEnabled(){ return feeGenerationEnabled; }

    
    public void setId(String id)                          { this.id = id; }
    public void setProgramme(String p)                    { this.programme = p; }
    public void setSemester(String s)                     { this.semester = s; }
    public void setAdmissionFee(double v)                 { this.admissionFee = v; }
    public void setRegistrationFee(double v)              { this.registrationFee = v; }
    public void setLibrarySecurityFee(double v)           { this.librarySecurityFee = v; }
    public void setTuitionFee(double v)                   { this.tuitionFee = v; }
    public void setExaminationFee(double v)               { this.examinationFee = v; }
    public void setMaintenanceCharges(double v)           { this.maintenanceCharges = v; }
    public void setAudioVideoFee(double v)                { this.audioVideoFee = v; }
    public void setLibrarySubscription(double v)          { this.librarySubscription = v; }
    public void setComputerLabFee(double v)               { this.computerLabFee = v; }
    public void setSportsFund(double v)                   { this.sportsFund = v; }
    public void setMagazineFund(double v)                 { this.magazineFund = v; }
    public void setItServicesFee(double v)                { this.itServicesFee = v; }
    public void setResearchFund(double v)                 { this.researchFund = v; }
    public void setStudyMaterial(double v)                { this.studyMaterial = v; }
    public void setFeeGenerationEnabled(boolean b)        { this.feeGenerationEnabled = b; }

    public double getTotal() {
        return admissionFee + registrationFee + librarySecurityFee + tuitionFee
             + examinationFee + maintenanceCharges + audioVideoFee + librarySubscription
             + computerLabFee + sportsFund + magazineFund + itServicesFee
             + researchFund + studyMaterial;
    }

    public String toCSV() {
        return id + "," + programme + "," + semester + ","
             + admissionFee + "," + registrationFee + "," + librarySecurityFee + ","
             + tuitionFee + "," + examinationFee + "," + maintenanceCharges + ","
             + audioVideoFee + "," + librarySubscription + "," + computerLabFee + ","
             + sportsFund + "," + magazineFund + "," + itServicesFee + ","
             + researchFund + "," + studyMaterial + "," + feeGenerationEnabled;
    }

    public static FeeStructure fromCSV(String csv) {
        String[] p = csv.split(",", -1);
        if (p.length < 18) return null;
        FeeStructure f = new FeeStructure(p[0].trim(), p[1].trim(), p[2].trim());
        try {
            f.admissionFee        = Double.parseDouble(p[3].trim());
            f.registrationFee     = Double.parseDouble(p[4].trim());
            f.librarySecurityFee  = Double.parseDouble(p[5].trim());
            f.tuitionFee          = Double.parseDouble(p[6].trim());
            f.examinationFee      = Double.parseDouble(p[7].trim());
            f.maintenanceCharges  = Double.parseDouble(p[8].trim());
            f.audioVideoFee       = Double.parseDouble(p[9].trim());
            f.librarySubscription = Double.parseDouble(p[10].trim());
            f.computerLabFee      = Double.parseDouble(p[11].trim());
            f.sportsFund          = Double.parseDouble(p[12].trim());
            f.magazineFund        = Double.parseDouble(p[13].trim());
            f.itServicesFee       = Double.parseDouble(p[14].trim());
            f.researchFund        = Double.parseDouble(p[15].trim());
            f.studyMaterial       = Double.parseDouble(p[16].trim());
            f.feeGenerationEnabled = Boolean.parseBoolean(p[17].trim());
        } catch (NumberFormatException e) { return null; }
        return f;
    }

    @Override public String toString() { return programme + " - Semester " + semester; }
}
