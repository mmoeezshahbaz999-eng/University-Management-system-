package models;

import java.util.ArrayList;
import java.util.List;

public class Student extends User {
    private static final long serialVersionUID = 1L;

    private String major;
    private int year;          
    private String semester;
    private List<String> enrolledCourseIds;

    public Student(String id, String name, String email, String password) {
        super(id, name, email, password, "STUDENT");
        this.major = "Undeclared";
        this.year = 1;
        this.semester = "Fall 2024";
        this.enrolledCourseIds = new ArrayList<>();
    }

    
    public Student(String id, String name, String email, String password,
                   String phone, String address, String major, int year, String semester) {
        super(id, name, email, password, "STUDENT");
        this.phone = phone;
        this.address = address;
        this.major = major;
        this.year = year;
        this.semester = semester;
        this.enrolledCourseIds = new ArrayList<>();
    }

    
    public Student(String id, String name, String email, String password,
                   String phone, String address, String major, int year, String semester,
                   String profilePicturePath) {
        super(id, name, email, password, "STUDENT");
        this.phone = phone;
        this.address = address;
        this.major = major;
        this.year = year;
        this.semester = semester;
        this.profilePicturePath = profilePicturePath;
        this.enrolledCourseIds = new ArrayList<>();
    }

    public String getMajor() { return major; }
    public int getYear() { return year; }
    public String getSemester() { return semester; }
    public List<String> getEnrolledCourseIds() { return enrolledCourseIds; }

    public void setMajor(String major) { this.major = major; }
    public void setYear(int year) { this.year = year; }
    public void setSemester(String semester) { this.semester = semester; }

    public void enrollCourse(String courseId) {
        if (!enrolledCourseIds.contains(courseId)) {
            enrolledCourseIds.add(courseId);
        }
    }

    public void dropCourse(String courseId) {
        enrolledCourseIds.remove(courseId);
    }

    @Override
    public String toCSV() {
        return id + "," + name + "," + email + "," + password + ","
                + phone + "," + address + "," + major + "," + year + "," + semester + ","
                + (profilePicturePath != null ? profilePicturePath : "");
    }

    public static Student fromCSV(String csv) {
        String[] parts = csv.split(",", -1);
        if (parts.length < 9) return null;
        String pic = parts.length >= 10 ? parts[9].trim() : "";
        Student s = new Student(parts[0].trim(), parts[1].trim(), parts[2].trim(),
                parts[3].trim(), parts[4].trim(), parts[5].trim(),
                parts[6].trim(), Integer.parseInt(parts[7].trim()), parts[8].trim(), pic);
        return s;
    }
}
