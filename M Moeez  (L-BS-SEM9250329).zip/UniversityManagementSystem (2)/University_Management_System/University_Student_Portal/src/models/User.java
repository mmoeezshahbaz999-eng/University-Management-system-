package models;

import java.io.Serializable;

public abstract class User implements Serializable {
    private static final long serialVersionUID = 1L;

    protected String id;
    protected String name;
    protected String email;
    protected String password;
    protected String role; 
    protected String phone;
    protected String address;
    protected String profilePicturePath; 

    public User(String id, String name, String email, String password, String role) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.password = password;
        this.role = role;
        this.phone = "";
        this.address = "";
        this.profilePicturePath = "";
    }

    
    public String getId() { return id; }
    public String getName() { return name; }
    public String getEmail() { return email; }
    public String getPassword() { return password; }
    public String getRole() { return role; }
    public String getPhone() { return phone; }
    public String getAddress() { return address; }
    public String getProfilePicturePath() { return profilePicturePath != null ? profilePicturePath : ""; }

    
    public void setName(String name) { this.name = name; }
    public void setEmail(String email) { this.email = email; }
    public void setPassword(String password) { this.password = password; }
    public void setPhone(String phone) { this.phone = phone; }
    public void setAddress(String address) { this.address = address; }
    public void setProfilePicturePath(String path) { this.profilePicturePath = (path != null ? path : ""); }

    
    public abstract String toCSV();

    @Override
    public String toString() {
        return name + " (" + id + ")";
    }
}
