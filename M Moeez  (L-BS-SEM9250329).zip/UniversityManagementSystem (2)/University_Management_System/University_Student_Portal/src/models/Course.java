package models;

import java.io.Serializable;

public class Course implements Serializable {
    private static final long serialVersionUID = 1L;

    private String courseId;
    private String courseName;
    private String teacherId;
    private String teacherName;
    private int creditHours;
    private String semester;        // e.g. "Fall 2024"
    private String schedule;
    private String room;
    private int capacity;
    private int enrolled;
    private String description;
    private String department;
    private int semesterNumber;     // 1-8 (curriculum semester)
    private String courseOutline;   // detailed syllabus/outline

    public Course(String courseId, String courseName, String teacherId, String teacherName,
                  int creditHours, String semester, String schedule, String room,
                  int capacity, String description, String department) {
        this(courseId, courseName, teacherId, teacherName, creditHours, semester, schedule, room,
             capacity, description, department, 0, "");
    }

    public Course(String courseId, String courseName, String teacherId, String teacherName,
                  int creditHours, String semester, String schedule, String room,
                  int capacity, String description, String department,
                  int semesterNumber, String courseOutline) {
        this.courseId = courseId;
        this.courseName = courseName;
        this.teacherId = teacherId;
        this.teacherName = teacherName;
        this.creditHours = creditHours;
        this.semester = semester;
        this.schedule = schedule;
        this.room = room;
        this.capacity = capacity;
        this.enrolled = 0;
        this.description = description;
        this.department = department;
        this.semesterNumber = semesterNumber;
        this.courseOutline = (courseOutline == null) ? "" : courseOutline;
    }

    // Getters
    public String getCourseId()      { return courseId; }
    public String getCourseName()    { return courseName; }
    public String getTeacherId()     { return teacherId; }
    public String getTeacherName()   { return teacherName; }
    public int    getCreditHours()   { return creditHours; }
    public String getSemester()      { return semester; }
    public String getSchedule()      { return schedule; }
    public String getRoom()          { return room; }
    public int    getCapacity()      { return capacity; }
    public int    getEnrolled()      { return enrolled; }
    public String getDescription()   { return description; }
    public String getDepartment()    { return department; }
    public int    getSemesterNumber(){ return semesterNumber; }
    public String getCourseOutline() { return courseOutline; }

    // Setters
    public void setCourseId(String courseId)           { this.courseId = courseId; }
    public void setCourseName(String courseName)       { this.courseName = courseName; }
    public void setTeacherId(String teacherId)         { this.teacherId = teacherId; }
    public void setTeacherName(String teacherName)     { this.teacherName = teacherName; }
    public void setCreditHours(int creditHours)        { this.creditHours = creditHours; }
    public void setSemester(String semester)           { this.semester = semester; }
    public void setSchedule(String schedule)           { this.schedule = schedule; }
    public void setRoom(String room)                   { this.room = room; }
    public void setCapacity(int capacity)              { this.capacity = capacity; }
    public void setEnrolled(int enrolled)              { this.enrolled = enrolled; }
    public void setDescription(String description)     { this.description = description; }
    public void setDepartment(String department)       { this.department = department; }
    public void setSemesterNumber(int semesterNumber)  { this.semesterNumber = semesterNumber; }
    public void setCourseOutline(String courseOutline) { this.courseOutline = (courseOutline == null) ? "" : courseOutline; }

    public boolean isFull()      { return enrolled >= capacity; }
    public int getSpotsLeft()    { return capacity - enrolled; }

    // Escape/unescape pipe separator for outline field
    private static String esc(String s)  { return s == null ? "" : s.replace("|", "[[PIPE]]").replace("\n", "[[NL]]"); }
    private static String unesc(String s){ return s == null ? "" : s.replace("[[PIPE]]", "|").replace("[[NL]]", "\n"); }

    public String toCSV() {
        return courseId + "|" + courseName + "|" + teacherId + "|" + teacherName + "|"
                + creditHours + "|" + esc(semester) + "|" + esc(schedule) + "|" + esc(room) + "|"
                + capacity + "|" + enrolled + "|" + esc(description) + "|" + esc(department)
                + "|" + semesterNumber + "|" + esc(courseOutline);
    }

    public static Course fromCSV(String csv) {
        // Support both old comma-format (12 fields) and new pipe-format (14 fields)
        String[] parts;
        if (csv.contains("|")) {
            parts = csv.split("\\|", -1);
        } else {
            parts = csv.split(",", 12);
        }
        if (parts.length < 12) return null;
        Course c = new Course(
                parts[0].trim(), parts[1].trim(), parts[2].trim(), parts[3].trim(),
                parseInt(parts[4].trim()), unesc(parts[5].trim()), unesc(parts[6].trim()),
                unesc(parts[7].trim()), parseInt(parts[8].trim()),
                parts.length > 10 ? unesc(parts[10].trim()) : "",
                parts.length > 11 ? unesc(parts[11].trim()) : "",
                parts.length > 12 ? parseInt(parts[12].trim()) : 0,
                parts.length > 13 ? unesc(parts[13].trim()) : "");
        c.setEnrolled(parseInt(parts[9].trim()));
        return c;
    }

    private static int parseInt(String s) {
        try { return Integer.parseInt(s); } catch (Exception e) { return 0; }
    }

    @Override
    public String toString() { return courseId + " - " + courseName; }
}
