package models;

import java.io.Serializable;

public class AssignmentSubmission implements Serializable {
    private static final long serialVersionUID = 1L;

    private String submissionId;
    private String assignmentId;
    private String studentId;
    private String studentName;
    private String courseId;
    private String submittedText;   // inline text answer
    private String fileName;        // optional attached filename
    private String submittedOn;     // date string
    private String status;          // "Submitted" | "Late" | "Graded"
    private int    marksObtained;   // -1 = not graded yet

    public AssignmentSubmission(String submissionId, String assignmentId,
                                String studentId, String studentName,
                                String courseId, String submittedText,
                                String fileName, String submittedOn,
                                String status, int marksObtained) {
        this.submissionId   = submissionId;
        this.assignmentId   = assignmentId;
        this.studentId      = studentId;
        this.studentName    = studentName;
        this.courseId       = courseId;
        this.submittedText  = submittedText;
        this.fileName       = fileName;
        this.submittedOn    = submittedOn;
        this.status         = status;
        this.marksObtained  = marksObtained;
    }

    public String getSubmissionId()  { return submissionId; }
    public String getAssignmentId()  { return assignmentId; }
    public String getStudentId()     { return studentId; }
    public String getStudentName()   { return studentName; }
    public String getCourseId()      { return courseId; }
    public String getSubmittedText() { return submittedText; }
    public String getFileName()      { return fileName; }
    public String getSubmittedOn()   { return submittedOn; }
    public String getStatus()        { return status; }
    public int    getMarksObtained() { return marksObtained; }

    public void setStatus(String status)           { this.status = status; }
    public void setMarksObtained(int marks)        { this.marksObtained = marks; }
    public void setSubmittedText(String text)      { this.submittedText = text; }
    public void setFileName(String fileName)       { this.fileName = fileName; }

    public String toCSV() {
        String safeText = submittedText == null ? "" :
            submittedText.replace(",", ";").replace("\n", "\\n").replace("\r", "");
        String safeFile = fileName == null ? "" : fileName.replace(",", ";");
        return submissionId + "," + assignmentId + "," + studentId + "," +
               studentName.replace(",", ";") + "," + courseId + "," +
               safeText + "," + safeFile + "," + submittedOn + "," +
               status + "," + marksObtained;
    }

    public static AssignmentSubmission fromCSV(String csv) {
        String[] p = csv.split(",", 10);
        if (p.length < 10) return null;
        try {
            String text = p[5].trim().replace("\\n", "\n");
            return new AssignmentSubmission(
                p[0].trim(), p[1].trim(), p[2].trim(), p[3].trim(),
                p[4].trim(), text, p[6].trim(), p[7].trim(),
                p[8].trim(), Integer.parseInt(p[9].trim())
            );
        } catch (Exception e) { return null; }
    }
}
