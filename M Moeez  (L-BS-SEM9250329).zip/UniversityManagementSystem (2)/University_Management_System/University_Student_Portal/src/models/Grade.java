package models;

import java.io.Serializable;

public class Grade implements Serializable {
    private static final long serialVersionUID = 1L;

    private String gradeId;
    private String studentId;
    private String courseId;
    private String courseName;
    private double assignment1;
    private double midterm;
    private double finalProject;
    private double total;
    private String letterGrade;
    private String semester;

    public Grade(String gradeId, String studentId, String courseId, String courseName,
                 double assignment1, double midterm, double finalProject, String semester) {
        this.gradeId = gradeId;
        this.studentId = studentId;
        this.courseId = courseId;
        this.courseName = courseName;
        this.assignment1 = assignment1;
        this.midterm = midterm;
        this.finalProject = finalProject;
        this.semester = semester;
        calculateTotal();
    }

    public void calculateTotal() {
        
        this.total = (assignment1 * 0.20) + (midterm * 0.30) + (finalProject * 0.50);
        this.letterGrade = calculateLetterGrade(total);
    }

    private String calculateLetterGrade(double score) {
        if (score >= 90) return "A";
        if (score >= 85) return "A-";
        if (score >= 80) return "B+";
        if (score >= 75) return "B";
        if (score >= 70) return "B-";
        if (score >= 65) return "C+";
        if (score >= 60) return "C";
        if (score >= 55) return "C-";
        if (score >= 50) return "D";
        return "F";
    }

    public double getGpaPoints() {
        switch (letterGrade) {
            case "A":  return 4.0;
            case "A-": return 3.7;
            case "B+": return 3.3;
            case "B":  return 3.0;
            case "B-": return 2.7;
            case "C+": return 2.3;
            case "C":  return 2.0;
            case "C-": return 1.7;
            case "D":  return 1.0;
            default:   return 0.0;
        }
    }

    
    public String getGradeId() { return gradeId; }
    public String getStudentId() { return studentId; }
    public String getCourseId() { return courseId; }
    public String getCourseName() { return courseName; }
    public double getAssignment1() { return assignment1; }
    public double getMidterm() { return midterm; }
    public double getFinalProject() { return finalProject; }
    public double getTotal() { return total; }
    public String getLetterGrade() { return letterGrade; }
    public String getSemester() { return semester; }

    
    public void setAssignment1(double assignment1) { this.assignment1 = assignment1; calculateTotal(); }
    public void setMidterm(double midterm) { this.midterm = midterm; calculateTotal(); }
    public void setFinalProject(double finalProject) { this.finalProject = finalProject; calculateTotal(); }

    public String toCSV() {
        return gradeId + "," + studentId + "," + courseId + "," + courseName + ","
                + assignment1 + "," + midterm + "," + finalProject + "," + total + ","
                + letterGrade + "," + semester;
    }

    public static Grade fromCSV(String csv) {
        String[] parts = csv.split(",", 10);
        if (parts.length < 10) return null;
        return new Grade(parts[0].trim(), parts[1].trim(), parts[2].trim(), parts[3].trim(),
                Double.parseDouble(parts[4].trim()), Double.parseDouble(parts[5].trim()),
                Double.parseDouble(parts[6].trim()), parts[9].trim());
    }
}
