


import sys, json, os
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib import colors
from reportlab.lib.units import mm, cm
from reportlab.pdfgen import canvas
from reportlab.lib.styles import ParagraphStyle
from reportlab.platypus import Paragraph
from reportlab.lib.enums import TA_CENTER, TA_LEFT, TA_RIGHT
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
import textwrap


NAVY    = colors.HexColor("#0A2463")
GOLD    = colors.HexColor("#F59E0B")
TEAL    = colors.HexColor("#0D9488")
LIGHT   = colors.HexColor("#EFF6FF")
BORDER  = colors.HexColor("#CBD5E1")
WHITE   = colors.white
BLACK   = colors.black
GREY    = colors.HexColor("#64748B")
RED     = colors.HexColor("#DC2626")

PAGE_W, PAGE_H = landscape(A4)   
MARGIN = 6 * mm
COPY_LABELS = ["Accounts\nCopy", "Bank Copy", "University\nCopy", "Student\nCopy"]
COPY_COLORS = [
    colors.HexColor("#1E3A8A"),
    colors.HexColor("#0F5132"),
    colors.HexColor("#7C3AED"),
    colors.HexColor("#B45309"),
]

def fmt(v):
    """Format number as Rs. with commas."""
    if v == 0: return "0.00"
    return "{:,.2f}".format(v)

def draw_one_challan(c, data, x, y, w, h, label, label_color, logo_path):
    """Draw one challan copy inside the rect (x,y,w,h). y is bottom-left."""

    
    c.setStrokeColor(label_color)
    c.setLineWidth(1.5)
    c.rect(x, y, w, h)

    cur_y = y + h  

    
    strip_w = 7 * mm
    c.setFillColor(label_color)
    c.rect(x, y, strip_w, h, fill=1, stroke=0)
    c.saveState()
    c.setFillColor(WHITE)
    c.setFont("Helvetica-Bold", 6.5)
    c.translate(x + strip_w / 2, y + h / 2)
    c.rotate(90)
    lines = label.split("\n")
    for i, ln in enumerate(lines):
        c.drawCentredString(0, (i - len(lines)/2 + 0.5) * 8, ln)
    c.restoreState()

    content_x = x + strip_w + 2 * mm
    content_w = w - strip_w - 3 * mm

    
    header_h = 14 * mm
    c.setFillColor(NAVY)
    c.rect(content_x, cur_y - header_h, content_w, header_h, fill=1, stroke=0)

    
    logo_size = 10 * mm
    logo_y = cur_y - header_h + (header_h - logo_size) / 2
    logo_drawn = False
    if logo_path and os.path.exists(logo_path):
        try:
            c.drawImage(logo_path, content_x + 2*mm, logo_y,
                        width=logo_size, height=logo_size,
                        preserveAspectRatio=True, mask='auto')
            logo_drawn = True
        except Exception:
            pass

    if not logo_drawn:
        
        c.setFillColor(GOLD)
        c.roundRect(content_x + 2*mm, logo_y, logo_size, logo_size, 2*mm, fill=1, stroke=0)
        c.setFillColor(NAVY)
        c.setFont("Helvetica-Bold", 9)
        c.drawCentredString(content_x + 2*mm + logo_size/2,
                            logo_y + logo_size/2 - 3, "N")

    
    text_x = content_x + logo_size + 4 * mm
    c.setFillColor(WHITE)
    c.setFont("Helvetica-Bold", 9)
    c.drawString(text_x, cur_y - 6*mm, data.get("university_name", "NUML"))
    c.setFont("Helvetica", 6.5)
    c.drawString(text_x, cur_y - 10*mm, data.get("campus_name", "Lahore Campus"))
    c.drawString(text_x, cur_y - 13.5*mm, data.get("university_address", ""))

    
    rn_x = content_x + content_w - 38*mm
    c.setFont("Helvetica-Bold", 6)
    c.drawString(rn_x, cur_y - 5*mm,  "Roll No: " + data.get("roll_no", ""))
    c.drawString(rn_x, cur_y - 9*mm,  "Challan No: " + str(data.get("challan_no", "")))
    c.setFont("Helvetica", 5.5)
    c.drawString(rn_x, cur_y - 12.5*mm, "Issue: " + data.get("issue_date", ""))
    c.drawString(rn_x, cur_y - 15.5*mm, "Due: "   + data.get("due_date", ""))

    cur_y -= header_h

    
    notice_h = 10 * mm
    c.setFillColor(LIGHT)
    c.rect(content_x, cur_y - notice_h, content_w, notice_h, fill=1, stroke=0)
    c.setStrokeColor(BORDER)
    c.setLineWidth(0.4)
    c.rect(content_x, cur_y - notice_h, content_w, notice_h, fill=0)
    c.setFillColor(NAVY)
    c.setFont("Helvetica-Bold", 7.5)
    c.drawCentredString(content_x + content_w/2, cur_y - 5*mm, "ACMS")
    c.setFont("Helvetica", 5.2)
    c.setFillColor(GREY)
    c.drawCentredString(content_x + content_w/2, cur_y - 8.5*mm,
                        "Payable at any Askari Branch through Cash Management System")
    cur_y -= notice_h

    
    info_h = 18 * mm
    c.setFillColor(WHITE)
    
    col_w = content_w / 3
    labels_vals = [
        ("Shift:", data.get("shift", "Morning")),
        ("Course:", data.get("programme", "")),
        ("Semester:", data.get("semester", "")),
        ("Student Name:", data.get("student_name", "")),
        ("Father Name:", data.get("father_name", "")),
    ]
    lines_per_col = 3
    col_idx = 0
    row_idx = 0
    for lbl, val in labels_vals:
        cx = content_x + col_idx * col_w + 1*mm
        cy = cur_y - (row_idx + 1) * (info_h / 3) + 1*mm
        c.setFont("Helvetica-Bold", 5.5)
        c.setFillColor(GREY)
        c.drawString(cx, cy + 2.5, lbl)
        c.setFont("Helvetica", 5.5)
        c.setFillColor(BLACK)
        c.drawString(cx + 16*mm, cy + 2.5, val[:28])
        row_idx += 1
        if row_idx >= lines_per_col:
            row_idx = 0
            col_idx += 1

    
    c.setStrokeColor(BORDER)
    c.setLineWidth(0.3)
    for i in range(1, 3):
        lx = content_x + i * col_w
        c.line(lx, cur_y, lx, cur_y - info_h)
    for i in range(1, 3):
        ly = cur_y - i * (info_h / 3)
        c.line(content_x, ly, content_x + content_w, ly)
    c.line(content_x, cur_y - info_h, content_x + content_w, cur_y - info_h)
    cur_y -= info_h

    
    th = 5.5 * mm
    c.setFillColor(NAVY)
    c.rect(content_x, cur_y - th, content_w, th, fill=1, stroke=0)
    c.setFillColor(WHITE)
    c.setFont("Helvetica-Bold", 6)
    desc_w = content_w * 0.62
    amt_w  = content_w - desc_w
    c.drawString(content_x + 2*mm, cur_y - th + 1.8*mm, "Description")
    c.drawCentredString(content_x + desc_w + amt_w/2, cur_y - th + 1.8*mm, "Amount (Rs.)")
    cur_y -= th

    
    fee_items = [
        ("Admission Fee",        data.get("admission_fee",        0)),
        ("Registration",         data.get("registration_fee",     0)),
        ("Library Security",     data.get("library_security_fee", 0)),
        ("Tuition Fee",          data.get("tuition_fee",          0)),
        ("Examination Fee",      data.get("examination_fee",      0)),
        ("Maintenance Charges",  data.get("maintenance_charges",  0)),
        ("Audio/Video (AVS)",    data.get("audio_video_fee",      0)),
        ("Library Subscription", data.get("library_subscription", 0)),
        ("Computer Lab",         data.get("computer_lab_fee",     0)),
        ("Sports Fund",          data.get("sports_fund",          0)),
        ("Magazine Fund",        data.get("magazine_fund",        0)),
        ("IT Services",          data.get("it_services_fee",      0)),
        ("Research Fund",        data.get("research_fund",        0)),
        ("Study Material",       data.get("study_material",       0)),
        ("Fine",                 0),
        ("Discount",             0),
    ]

    row_h = 4.2 * mm
    for i, (desc, amt) in enumerate(fee_items):
        ry = cur_y - (i + 1) * row_h
        bg = LIGHT if i % 2 == 0 else WHITE
        c.setFillColor(bg)
        c.rect(content_x, ry, content_w, row_h, fill=1, stroke=0)
        c.setFillColor(BLACK if amt > 0 else GREY)
        c.setFont("Helvetica-Bold" if amt > 0 else "Helvetica", 5.5)
        c.drawString(content_x + 2*mm, ry + 1.2*mm, desc)
        c.setFillColor(BLACK if amt > 0 else GREY)
        c.setFont("Helvetica-Bold" if amt > 0 else "Helvetica", 5.5)
        c.drawRightString(content_x + desc_w + amt_w - 2*mm, ry + 1.2*mm, fmt(amt))
        
        c.setStrokeColor(BORDER)
        c.setLineWidth(0.2)
        c.line(content_x, ry, content_x + content_w, ry)

    table_bottom = cur_y - len(fee_items) * row_h
    
    c.setStrokeColor(BORDER)
    c.setLineWidth(0.4)
    c.line(content_x + desc_w, cur_y, content_x + desc_w, table_bottom)
    c.line(content_x, table_bottom, content_x + content_w, table_bottom)

    cur_y = table_bottom

    
    total = data.get("total", 0)
    tot_h = 5*mm
    for label_t, val_t, bg_t, bold in [
        ("Amount Before Due Date:", total, LIGHT,  True),
        ("Amount After Due Date:",  total, WHITE,  False),
    ]:
        c.setFillColor(bg_t)
        c.rect(content_x, cur_y - tot_h, content_w, tot_h, fill=1, stroke=0)
        c.setFillColor(NAVY if bold else GREY)
        font = "Helvetica-Bold" if bold else "Helvetica"
        c.setFont(font, 6)
        c.drawString(content_x + 2*mm, cur_y - tot_h + 1.5*mm, label_t)
        c.setFont("Helvetica-Bold", 6.5)
        c.setFillColor(RED if bold else GREY)
        c.drawRightString(content_x + desc_w + amt_w - 2*mm, cur_y - tot_h + 1.5*mm, fmt(val_t))
        c.setStrokeColor(NAVY if bold else BORDER)
        c.setLineWidth(0.5 if bold else 0.3)
        c.line(content_x, cur_y - tot_h, content_x + content_w, cur_y - tot_h)
        cur_y -= tot_h

    
    dep_h = 5*mm
    c.setFillColor(WHITE)
    c.setFont("Helvetica", 5.2)
    c.setFillColor(GREY)
    c.drawString(content_x + 2*mm, cur_y - dep_h + 1.5*mm,
                 "Depositor's Contact # _________________________")
    c.setStrokeColor(BORDER); c.setLineWidth(0.3)
    c.line(content_x, cur_y - dep_h, content_x + content_w, cur_y - dep_h)
    cur_y -= dep_h

    
    disc = ("Cash/cheque should always be deposited at the respective counter "
            "and electronic computer-generated receipt printed through flatbed "
            "printer on deposit slip/challan should be obtained before leaving "
            "the counter.")
    disc_h = cur_y - (y + 1*mm)
    c.setFillColor(colors.HexColor("#FEF9C3"))
    c.rect(content_x, y + 1*mm, content_w, disc_h, fill=1, stroke=0)
    c.setFillColor(BLACK)
    c.setFont("Helvetica-Bold", 5.2)
    c.drawString(content_x + 2*mm, y + disc_h - 1*mm, "Disclaimer")
    c.setFont("Helvetica", 4.8)
    c.setFillColor(GREY)
    
    words = disc.split()
    lines_d = []
    current = ""
    max_chars = int(content_w / (2.7))  
    for word in words:
        test = (current + " " + word).strip()
        if len(test) > max_chars:
            lines_d.append(current)
            current = word
        else:
            current = test
    if current:
        lines_d.append(current)
    for li, ln in enumerate(lines_d[:4]):
        c.drawString(content_x + 2*mm, y + disc_h - 4.5*mm - li*4*mm, ln)


def generate(data, output_path, logo_path=None):
    c = canvas.Canvas(output_path, pagesize=landscape(A4))
    c.setTitle("Fee Challan - " + data.get("student_name", ""))
    c.setAuthor(data.get("university_name", "University Portal"))

    total_w = PAGE_W - 2 * MARGIN
    total_h = PAGE_H - 2 * MARGIN
    challan_w = total_w / 4

    for i, (label, col) in enumerate(zip(COPY_LABELS, COPY_COLORS)):
        cx = MARGIN + i * challan_w
        cy = MARGIN
        draw_one_challan(c, data, cx, cy, challan_w, total_h, label, col, logo_path)

    
    c.setStrokeColor(GREY)
    c.setLineWidth(0.4)
    c.setDash([2, 3], 0)
    for i in range(1, 4):
        lx = MARGIN + i * challan_w
        c.line(lx, MARGIN, lx, MARGIN + total_h)

    c.save()
    print("PDF generated:", output_path)


if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("Usage: generate_challan.py <data.json> <output.pdf>")
        sys.exit(1)

    json_file   = sys.argv[1]
    output_file = sys.argv[2]
    logo_file   = sys.argv[3] if len(sys.argv) > 3 else None

    with open(json_file, "r") as f:
        data = json.load(f)

    generate(data, output_file, logo_file)
